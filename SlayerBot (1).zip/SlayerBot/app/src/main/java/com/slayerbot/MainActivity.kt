package com.slayerbot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        CrashLog.install(this)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        l.addView(TextView(this).apply {
            textSize = 15f
            text = "Slayer Bot\n\n" +
                "1) Настройки → Приложения → Slayer Bot → ⋮ → «Разрешить ограниченные настройки».\n" +
                "2) Кнопка ниже → Slayer Bot → включить.\n" +
                "3) Открой Idle Slayer в горизонтали — слева появится плавающее меню.\n" +
                "4) Сначала пройди «Калибровку», потом жми FULL AFK."
        })
        l.addView(Button(this).apply {
            text = "Открыть спец. возможности"
            setOnClickListener {
                try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                catch (t: Throwable) { CrashLog.save(this@MainActivity, t) }
            }
        })
        val log = CrashLog.read(this)
        if (log != null) {
            l.addView(TextView(this).apply { text = "Журнал ошибок (скопируй и пришли):"; textSize = 14f })
            val tv = TextView(this).apply { text = log.take(3500); textSize = 10f; setTextIsSelectable(true) }
            l.addView(ScrollView(this).apply { addView(tv) }, LinearLayout.LayoutParams(-1, 0, 1f))
            l.addView(Button(this).apply {
                text = "Очистить журнал"
                setOnClickListener { CrashLog.clear(this@MainActivity); tv.text = "" }
            })
        }
        setContentView(l)
    }
}
