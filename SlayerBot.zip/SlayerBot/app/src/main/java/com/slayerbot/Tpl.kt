package com.slayerbot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import java.io.ByteArrayOutputStream

/** Образец спрайта, уменьшенный в f раз для быстрого поиска. side — сторона исходного фрагмента в пикселях. */
class Tpl(val w: Int, val h: Int, val px: IntArray, val f: Int, val side: Int)

object TplStore {
    private fun prefs(c: Context) = c.getSharedPreferences("tpl", Context.MODE_PRIVATE)
    private val cache = HashMap<String, Tpl>()

    fun has(c: Context, key: String) = prefs(c).contains(key)

    fun save(c: Context, key: String, patch: Bitmap) {
        val bos = ByteArrayOutputStream()
        patch.compress(Bitmap.CompressFormat.PNG, 100, bos)
        prefs(c).edit().putString(key, Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)).apply()
        cache.remove(key)
    }

    fun clear(c: Context, key: String) { prefs(c).edit().remove(key).apply(); cache.remove(key) }

    @Synchronized
    fun load(c: Context, key: String): Tpl? {
        cache[key]?.let { return it }
        val s = prefs(c).getString(key, null) ?: return null
        val bytes = Base64.decode(s, Base64.NO_WRAP)
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        val f = 3
        val w = maxOf(8, bmp.width / f)
        val h = maxOf(8, bmp.height / f)
        val sc = Bitmap.createScaledBitmap(bmp, w, h, true)
        val px = IntArray(w * h)
        sc.getPixels(px, 0, w, 0, 0, w, h)
        val t = Tpl(w, h, px, f, bmp.width)
        cache[key] = t
        return t
    }
}
