package com.slayerbot

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout

/** Вики Idle Slayer внутри приложения: навигация, поиск и быстрые разделы. */
class WikiActivity : Activity() {
    private val base = "https://idleslayer.fandom.com"
    private lateinit var web: WebView
    private lateinit var pal: Ui.Pal
    private var neon = false

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun searchUrl(q: String) = "$base/wiki/Special:Search?query=" + Uri.encode(q)

    private fun tool(t: String, w: Int = 46, click: () -> Unit) = Button(this).apply {
        text = t; textSize = 17f; isAllCaps = false; setTextColor(Ui.CREAM); typeface = Ui.font
        background = Ui.btnBg(this@WikiActivity, pal, neon, 0)
        minWidth = dp(w); minimumWidth = dp(w); minHeight = dp(40); minimumHeight = dp(40)
        setPadding(dp(8), 0, dp(8), 0)
        setOnClickListener { click() }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        pal = Ui.pal(this, false); neon = Ui.neonOn(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pal.bg) }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(10), dp(8), dp(6))
        }
        val gap = { LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(5) } }
        top.addView(tool("‹") { if (web.canGoBack()) web.goBack() else finish() }, gap())
        top.addView(tool("›") { if (web.canGoForward()) web.goForward() }, gap())
        top.addView(tool("⌂") { web.loadUrl(base) }, gap())
        val input = EditText(this).apply {
            hint = "Поиск по вики"; setHintTextColor(Ui.MUTED); setTextColor(Ui.CREAM); typeface = Ui.font; textSize = 14f
            isSingleLine = true; imeOptions = EditorInfo.IME_ACTION_SEARCH
            background = Ui.bg(this@WikiActivity, Ui.mix(pal.bg, Color.WHITE, 0.05f), pal.edge, false)
            setPadding(dp(12), 0, dp(12), 0)
        }
        fun go() { val q = input.text.toString().trim(); if (q.isNotEmpty()) web.loadUrl(searchUrl(q)) }
        input.setOnEditorActionListener { _, id, e ->
            if (id == EditorInfo.IME_ACTION_SEARCH || (e != null && e.keyCode == KeyEvent.KEYCODE_ENTER)) { go(); true } else false
        }
        top.addView(input, LinearLayout.LayoutParams(0, dp(40), 1f).apply { rightMargin = dp(5) })
        top.addView(tool("Найти", 70) { go() }, gap())
        top.addView(tool("↻") { web.reload() })
        root.addView(top)

        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), 0, dp(8), dp(6)) }
        val topics = listOf(
            "Главная" to null, "Охота за сундуками" to "Chest Hunt", "Мимики" to "Mimic", "Бонус-уровни" to "Bonus Stage",
            "Перерождение" to "Ascension", "Оружие" to "Weapons", "Броня" to "Armor", "Божественность" to "Divinity", "Гайды" to "Guide"
        )
        for ((label, q) in topics) {
            chips.addView(Button(this).apply {
                text = label; textSize = 12f; isAllCaps = false; setTextColor(pal.accent); typeface = Ui.font
                background = Ui.btnBg(this@WikiActivity, pal, neon, 0)
                minHeight = dp(34); minimumHeight = dp(34); setPadding(dp(12), 0, dp(12), 0)
                setOnClickListener { web.loadUrl(if (q == null) base else searchUrl(q)) }
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        }
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) })

        val progress = View(this).apply { setBackgroundColor(pal.accent); pivotX = 0f; scaleX = 0f }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(2)))

        web = WebView(this)
        web.setBackgroundColor(pal.bg)
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            builtInZoomControls = true; displayZoomControls = false
            loadWithOverviewMode = true; useWideViewPort = true
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val host = r.url.host ?: ""
                if (host.endsWith("fandom.com")) return false
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, r.url)) }
                return true
            }
            override fun onPageStarted(v: WebView, url: String?, f: Bitmap?) { progress.scaleX = 0.05f }
            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                if (r.isForMainFrame) v.loadDataWithBaseURL(null,
                    "<html><body style='background:#111;color:#ccc;font-family:sans-serif;padding:32px'>" +
                        "<h3>Нет соединения</h3><p>Проверьте интернет и нажмите ↻.</p></body></html>",
                    "text/html", "utf-8", null)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                progress.scaleX = p / 100f
                progress.visibility = if (p >= 100) View.INVISIBLE else View.VISIBLE
            }
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val q = intent.getStringExtra("q")
        web.loadUrl(if (q.isNullOrEmpty()) base else searchUrl(q))
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
