package com.slayerbot

import android.content.Context

class Pt(val x: Float, val y: Float, val color: Int = 0)
class Area(val l: Float, val t: Float, val r: Float, val b: Float)

/** Координаты — ДОЛИ экрана (0..1), поэтому не зависят от разрешения.
 *  Точные значения задаются в меню: ⚙ Настройки → 🎯 Калибровка. */
object Cal {
    const val GAME_PKG = "com.pabloleban.IdleSlayer"
    const val TOL = 40   // допуск по цвету (на канал RGB)

    val COIN_AREA = Area(0.26f, 0.22f, 0.98f, 0.85f)
    // снизу оставляем место под панель охоты
    val CHEST_AREA = Area(0.03f, 0.10f, 0.97f, 0.88f)

    /** group 0 — общая калибровка, group 1 — калибровка охоты (в меню охоты). tpl — запоминается образец-картинка. */
    class Item(val key: String, val hint: String, val dx: Float, val dy: Float,
               val needColor: Boolean = false, val dc: Int = 0, val group: Int = 0, val tpl: Boolean = false)

    val items = listOf(
        Item("jump", "ТОЧКА ПРЫЖКА: куда бот будет тапать (справа от персонажа)", .40f, .60f),
        Item("player", "ПЕРСОНАЖ: тапни по самому Slayer", .20f, .62f),
        Item("boost", "КНОПКА УСКОРЕНИЯ В ИГРЕ: тапни по ней (лучше когда она готова — цвет запомнится)", .90f, .80f, true),
        Item("pandora", "ЦВЕТ ЯЩИКА ПАНДОРЫ: тапни по ящику", .50f, .30f, true),
        Item("coin", "ЦВЕТ МОНЕТЫ: тапни по монете", .60f, .45f, true, 0xFFFFC800.toInt()),
        Item("chest", "ОБРАЗЕЦ СУНДУКА: открой поле охоты и тапни по центру ЗАКРЫТОГО сундука", .50f, .50f, false, 0, 1, true),
        Item("huntClose", "КНОПКА «ЗАКРЫТЬ» на экране итогов охоты (победа или поражение). Если сейчас её нет — «Пропуск»", .50f, .80f, false, 0, 1, true),
        Item("bonusMark", "БОНУС-УРОВЕНЬ: на экране бонус-уровня тапни по неподвижному элементу интерфейса (например, таймер)", .50f, .10f, false, 0, 2, true),
        Item("orb", "БОНУС-УРОВЕНЬ: ЦВЕТ ГОЛУБОЙ СФЕРЫ — тапни по сфере", .60f, .45f, true, 0, 2),
        Item("pandoraP", "ФИОЛЕТОВЫЙ ЯЩИК ПАНДОРЫ (вход в бонус-уровень): тапни по ящику", .50f, .30f, true, 0, 2)
    )

    private fun prefs(c: Context) = c.getSharedPreferences("cal", Context.MODE_PRIVATE)

    fun isSet(c: Context, key: String) = prefs(c).contains(key)

    fun get(c: Context, key: String): Pt {
        val item = items.first { i -> i.key == key }
        val s = prefs(c).getString(key, null)?.split(",")
        return if (s != null && s.size == 3) Pt(s[0].toFloat(), s[1].toFloat(), s[2].toInt())
        else Pt(item.dx, item.dy, item.dc)
    }

    fun set(c: Context, key: String, p: Pt) {
        prefs(c).edit().putString(key, "${p.x},${p.y},${p.color}").apply()
    }
}
