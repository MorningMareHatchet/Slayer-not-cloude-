package com.slayerbot

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.hypot

object Vision {
    fun near(p: Int, c: Int, t: Int) =
        abs(Color.red(p) - Color.red(c)) < t &&
        abs(Color.green(p) - Color.green(c)) < t &&
        abs(Color.blue(p) - Color.blue(c)) < t

    /** Есть ли в окрестности точки p цвет p.color (для маркеров сцен). */
    fun has(b: Bitmap, p: Pt, tol: Int = Cal.TOL): Boolean {
        val cx = (p.x * b.width).toInt()
        val cy = (p.y * b.height).toInt()
        for (dy in -6..6 step 3) for (dx in -6..6 step 3) {
            val x = (cx + dx).coerceIn(0, b.width - 1)
            val y = (cy + dy).coerceIn(0, b.height - 1)
            if (near(b.getPixel(x, y), p.color, tol)) return true
        }
        return false
    }

    /** Центры скоплений пикселей заданного цвета в области (в пикселях экрана). */
    fun find(b: Bitmap, a: Area, color: Int, tol: Int, minHits: Int): List<Pair<Float, Float>> {
        val x0 = (a.l * b.width).toInt()
        val y0 = (a.t * b.height).toInt()
        val w = (a.r * b.width).toInt() - x0
        val h = (a.b * b.height).toInt() - y0
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, x0, y0, w, h)
        val cell = 64
        val cols = w / cell + 1
        val acc = HashMap<Int, IntArray>()
        for (y in 0 until h step 3) for (x in 0 until w step 3) {
            if (near(px[y * w + x], color, tol)) {
                val e = acc.getOrPut((y / cell) * cols + x / cell) { IntArray(3) }
                e[0]++; e[1] += x; e[2] += y
            }
        }
        return acc.values.filter { it[0] >= minHits }
            .map { Pair(x0 + it[1].toFloat() / it[0], y0 + it[2].toFloat() / it[0]) }
    }

    class Blob(var l: Int, var t: Int, var r: Int, var b: Int, var n: Int) {
        val cx get() = (l + r) / 2f
        val cy get() = (t + b) / 2f
        val w get() = r - l
        val h get() = b - t
    }

    /** Отдельные объекты заданного цвета (связные области, близкие части склеиваются). */
    fun components(b: Bitmap, a: Area, color: Int, tol: Int, minCells: Int, mergeGap: Int): List<Blob> {
        val step = 4
        val x0 = (a.l * b.width).toInt()
        val y0 = (a.t * b.height).toInt()
        val w = (a.r * b.width).toInt() - x0
        val h = (a.b * b.height).toInt() - y0
        if (w <= step * 2 || h <= step * 2) return emptyList()
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, x0, y0, w, h)
        val gw = w / step
        val gh = h / step
        val mask = BooleanArray(gw * gh)
        for (gy in 0 until gh) for (gx in 0 until gw) mask[gy * gw + gx] = near(px[gy * step * w + gx * step], color, tol)
        val seen = BooleanArray(gw * gh)
        val stack = IntArray(gw * gh)
        val out = ArrayList<Blob>()
        for (s in mask.indices) {
            if (!mask[s] || seen[s]) continue
            var sp = 0
            stack[sp++] = s; seen[s] = true
            var minx = gw; var maxx = 0; var miny = gh; var maxy = 0; var cnt = 0
            while (sp > 0) {
                val i = stack[--sp]
                val x = i % gw; val y = i / gw
                cnt++
                if (x < minx) minx = x; if (x > maxx) maxx = x
                if (y < miny) miny = y; if (y > maxy) maxy = y
                if (x > 0 && mask[i - 1] && !seen[i - 1]) { seen[i - 1] = true; stack[sp++] = i - 1 }
                if (x < gw - 1 && mask[i + 1] && !seen[i + 1]) { seen[i + 1] = true; stack[sp++] = i + 1 }
                if (y > 0 && mask[i - gw] && !seen[i - gw]) { seen[i - gw] = true; stack[sp++] = i - gw }
                if (y < gh - 1 && mask[i + gw] && !seen[i + gw]) { seen[i + gw] = true; stack[sp++] = i + gw }
            }
            if (cnt >= minCells) out.add(Blob(x0 + minx * step, y0 + miny * step, x0 + (maxx + 1) * step, y0 + (maxy + 1) * step, cnt))
        }
        var merged = true
        while (merged) {
            merged = false
            loop@ for (i in out.indices) for (j in i + 1 until out.size) {
                val p = out[i]; val q = out[j]
                if (p.l - mergeGap <= q.r && q.l - mergeGap <= p.r && p.t - mergeGap <= q.b && q.t - mergeGap <= p.b) {
                    p.l = minOf(p.l, q.l); p.t = minOf(p.t, q.t); p.r = maxOf(p.r, q.r); p.b = maxOf(p.b, q.b); p.n += q.n
                    out.removeAt(j); merged = true
                    break@loop
                }
            }
        }
        return out
    }

    class Match(val cx: Float, val cy: Float, val r: Float, val score: Float)

    /**
     * Поиск спрайтов по образцу (сумма абсолютных разностей). В отличие от поиска по цвету не путает
     * сундуки с монетами и мимиками: сравнивается именно картинка. Работает на уменьшенном в 3 раза кадре.
     */
    fun matchTpl(b: Bitmap, a: Area, t: Tpl, thr: Int): List<Match> {
        val f = t.f
        val sb = Bitmap.createScaledBitmap(b, b.width / f, b.height / f, true)
        val ax = (a.l * sb.width).toInt()
        val ay = (a.t * sb.height).toInt()
        val aw = (a.r * sb.width).toInt() - ax
        val ah = (a.b * sb.height).toInt() - ay
        if (aw < t.w || ah < t.h) { sb.recycle(); return emptyList() }
        val px = IntArray(aw * ah)
        sb.getPixels(px, 0, aw, ax, ay, aw, ah)
        sb.recycle()
        val tw = t.w; val th = t.h
        val st = 2
        val nSamples = ((tw + st - 1) / st) * ((th + st - 1) / st)
        val limit = thr * 3 * nSamples
        val cands = ArrayList<FloatArray>()
        var y = 0
        while (y <= ah - th) {
            var x = 0
            while (x <= aw - tw) {
                var sum = 0
                var ty = 0
                loop@ while (ty < th) {
                    var tx = 0
                    while (tx < tw) {
                        val p = px[(y + ty) * aw + x + tx]
                        val q = t.px[ty * tw + tx]
                        sum += abs(((p shr 16) and 255) - ((q shr 16) and 255)) +
                            abs(((p shr 8) and 255) - ((q shr 8) and 255)) +
                            abs((p and 255) - (q and 255))
                        if (sum > limit) break@loop
                        tx += st
                    }
                    ty += st
                }
                if (sum <= limit) cands.add(floatArrayOf(x.toFloat(), y.toFloat(), sum.toFloat() / (3f * nSamples)))
                x += st
            }
            y += st
        }
        cands.sortBy { it[2] }
        val minD = minOf(tw, th) * 0.8f
        val kept = ArrayList<FloatArray>()
        for (c in cands) {
            val cx = c[0] + tw / 2f; val cy = c[1] + th / 2f
            if (kept.none { hypot(it[0] - cx, it[1] - cy) < minD }) kept.add(floatArrayOf(cx, cy, c[2]))
        }
        return kept.map { Match((ax + it[0]) * f, (ay + it[1]) * f, t.side * 0.75f, it[2]) }
    }
}
