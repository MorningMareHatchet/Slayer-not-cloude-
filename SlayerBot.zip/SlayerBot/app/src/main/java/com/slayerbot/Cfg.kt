package com.slayerbot

import android.content.Context

/** Настройки скорости и режимов (меняются в плавающем меню → ⚙ Настройки). */
object Cfg {
    private fun p(c: Context) = c.getSharedPreferences("set", Context.MODE_PRIVATE)
    fun int(c: Context, k: String, d: Int) = p(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) = p(c).edit().putInt(k, v).apply()
    fun bool(c: Context, k: String, d: Boolean) = p(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = p(c).edit().putBoolean(k, v).apply()
}

class Snap(val hb: Long, val game: Boolean, val modes: String)

/** Сервис раз в секунду пишет «пульс», приложение по нему показывает статус. */
object Status {
    private fun p(c: Context) = c.getSharedPreferences("status", Context.MODE_PRIVATE)
    fun beat(c: Context, game: Boolean, modes: String) {
        p(c).edit().putLong("hb", System.currentTimeMillis())
            .putBoolean("game", game).putString("modes", modes).apply()
    }
    fun read(c: Context): Snap {
        val s = p(c)
        return Snap(s.getLong("hb", 0L), s.getBoolean("game", false), s.getString("modes", "") ?: "")
    }
}

/** Замеры «сколько мобов убито» (число берётся из игры) → скорость убийств в час. */
object Kills {
    class Reading(val t: Long, val k: Long)
    private fun p(c: Context) = c.getSharedPreferences("kills", Context.MODE_PRIVATE)

    fun all(c: Context): List<Reading> = (p(c).getString("r", "") ?: "").split(";").mapNotNull { s ->
        val a = s.split(",")
        if (a.size == 2) runCatching { Reading(a[0].toLong(), a[1].toLong()) }.getOrNull() else null
    }

    fun add(c: Context, k: Long) {
        val l = all(c).toMutableList()
        l.add(Reading(System.currentTimeMillis(), k))
        while (l.size > 60) l.removeAt(0)
        p(c).edit().putString("r", l.joinToString(";") { "${it.t},${it.k}" }).apply()
    }

    fun clear(c: Context) { p(c).edit().remove("r").apply() }

    /** Убийств в час по первому и последнему замеру (нужно ≥ 2 замеров с разницей во времени). */
    fun rate(c: Context): Double? {
        val l = all(c)
        if (l.size < 2) return null
        val a = l.first(); val b = l.last()
        val h = (b.t - a.t) / 3600000.0
        if (h < 0.01 || b.k <= a.k) return null
        return (b.k - a.k) / h
    }
}
