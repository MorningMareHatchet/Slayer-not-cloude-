package com.slayerbot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot

/** Сундук на поле: x,y — доли экрана, r — радиус в пикселях.
 *  state: 0 закрыт, 1 награда, 2 мимик, 3 открыт (ждём снимок исхода). */
class Slot(var x: Float, var y: Float, var r: Float) {
    var state = 0
    var p = 0f
    var tapAt = 0L
    var openedAt = 0L
    var sig: IntArray? = null
    var learned = false
}

/**
 * Память охоты.
 *  • по каждому месту на поле: сколько раз открывали и сколько раз там был мимик;
 *  • «подписи» исходов: как выглядит экран после мимика и после награды — по ним бот сам
 *    отличает мимика от обычных монет, не полагаясь на цвет.
 */
object HuntMem {
    class Stat(val x: Float, val y: Float, var n: Int, var m: Int)

    private val stats = ArrayList<Stat>()
    private val mimicSigs = ArrayList<IntArray>()
    private val rewardSigs = ArrayList<IntArray>()
    private var loaded = false
    var hunts = 0

    private fun prefs(c: Context) = c.getSharedPreferences("hunt", Context.MODE_PRIVATE)

    private fun enc(l: List<IntArray>) = l.joinToString(";") { a -> a.joinToString("") { "%02x".format(it.coerceIn(0, 255)) } }
    private fun dec(s: String?): List<IntArray> = (s ?: "").split(";").filter { it.length >= 6 }.map { h ->
        IntArray(h.length / 2) { i -> h.substring(i * 2, i * 2 + 2).toInt(16) }
    }

    @Synchronized fun load(c: Context) {
        if (loaded) return
        loaded = true
        hunts = prefs(c).getInt("hunts", 0)
        prefs(c).getString("stats", "")?.split(";")?.forEach { s ->
            val a = s.split(",")
            if (a.size == 4) runCatching { stats.add(Stat(a[0].toFloat(), a[1].toFloat(), a[2].toInt(), a[3].toInt())) }
        }
        mimicSigs.addAll(dec(prefs(c).getString("mSigs", "")))
        rewardSigs.addAll(dec(prefs(c).getString("rSigs", "")))
    }

    @Synchronized fun save(c: Context) {
        prefs(c).edit().putInt("hunts", hunts)
            .putString("stats", stats.joinToString(";") { "${it.x},${it.y},${it.n},${it.m}" })
            .putString("mSigs", enc(mimicSigs)).putString("rSigs", enc(rewardSigs)).apply()
    }

    private fun find(x: Float, y: Float): Stat? =
        stats.minByOrNull { hypot(it.x - x, it.y - y) }?.takeIf { hypot(it.x - x, it.y - y) < 0.03f }

    @Synchronized fun record(c: Context, x: Float, y: Float, mimic: Boolean) {
        val s = find(x, y) ?: Stat(x, y, 0, 0).also { stats.add(it) }
        s.n++; if (mimic) s.m++
        save(c)
    }

    @Synchronized fun fix(c: Context, x: Float, y: Float, toMimic: Boolean) {
        val s = find(x, y) ?: return
        if (toMimic && s.m < s.n) s.m++ else if (!toMimic && s.m > 0) s.m--
        save(c)
    }

    @Synchronized fun addSig(c: Context, mimic: Boolean, sig: IntArray) {
        val l = if (mimic) mimicSigs else rewardSigs
        l.add(sig)
        while (l.size > 14) l.removeAt(0)
        save(c)
    }

    private fun dist(a: IntArray, b: IntArray): Float {
        var s = 0
        val n = minOf(a.size, b.size)
        for (i in 0 until n) s += abs(a[i] - b[i])
        return s.toFloat() / n
    }

    /** true — похоже на мимика, false — на награду, null — образцов пока мало. */
    @Synchronized fun classify(sig: IntArray): Boolean? {
        if (mimicSigs.size < 2 || rewardSigs.size < 3) return null
        val dm = mimicSigs.minOf { dist(it, sig) }
        val dr = rewardSigs.minOf { dist(it, sig) }
        return dm < dr * 0.8f
    }

    @Synchronized fun sigCounts() = Pair(mimicSigs.size, rewardSigs.size)
    @Synchronized fun resetLearning(c: Context) { mimicSigs.clear(); rewardSigs.clear(); save(c) }
    @Synchronized fun reset(c: Context) { stats.clear(); mimicSigs.clear(); rewardSigs.clear(); hunts = 0; save(c) }
    @Synchronized fun opens() = stats.sumOf { it.n }
    @Synchronized fun informative(closed: List<Slot>) = closed.any { (find(it.x, it.y)?.n ?: 0) >= 10 }

    /**
     * База = мимиков осталось / закрытых сундуков. Затем шанс слегка сдвигается по накопленной
     * статистике места (сглаживание к среднему), сумма вероятностей сохраняется.
     */
    @Synchronized fun compute(closed: List<Slot>, mimicsLeft: Int): Float {
        if (closed.isEmpty()) return 0f
        val tn = stats.sumOf { it.n }
        val tm = stats.sumOf { it.m }
        val ref = (tm + 4f) / (tn + 30f)
        val k = 20f
        val base = (mimicsLeft.toFloat() / closed.size).coerceIn(0f, 1f)
        val rates = closed.map { s -> val st = find(s.x, s.y); ((st?.m ?: 0) + k * ref) / ((st?.n ?: 0) + k) }
        val mean = rates.average().toFloat()
        closed.forEachIndexed { i, s -> s.p = (base * rates[i] / mean).coerceIn(0f, 1f) }
        return base
    }
}

/** Слой поверх игры: кольцо вокруг сундука и шанс над ним. Ничего не рисуется в центре сундука,
 *  чтобы не мешать поиску по образцу. Касания пропускает. */
class MarkView(c: Context) : View(c) {
    class Mark(val x: Float, val y: Float, val r: Float, val color: Int, val label: String)

    @Volatile var marks: List<Mark> = emptyList()
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true; textSize = 26f
        setShadowLayer(5f, 0f, 0f, Color.BLACK)
    }

    override fun onDraw(c: Canvas) {
        for (m in marks) {
            ring.color = m.color; ring.alpha = 235
            c.drawRoundRect(RectF(m.x - m.r, m.y - m.r, m.x + m.r, m.y + m.r), 12f, 12f, ring)
            c.drawText(m.label, m.x, m.y - m.r - 8f, txt)
        }
    }
}
