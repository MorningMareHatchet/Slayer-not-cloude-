package com.slayerbot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.hypot

/** Один сундук на поле: x,y — доли экрана, r — радиус в пикселях. state: 0 закрыт, 1 награда, 2 мимик. */
class Slot(var x: Float, var y: Float, var r: Float) {
    var state = 0
    var p = 0f
    var tapAt = 0L
}

/** Память охоты: по каждому месту на поле — сколько раз открывали и сколько раз там был мимик. */
object HuntMem {
    class Stat(val x: Float, val y: Float, var n: Int, var m: Int)

    private val stats = ArrayList<Stat>()
    private var loaded = false
    var hunts = 0

    private fun prefs(c: Context) = c.getSharedPreferences("hunt", Context.MODE_PRIVATE)

    @Synchronized fun load(c: Context) {
        if (loaded) return
        loaded = true
        hunts = prefs(c).getInt("hunts", 0)
        prefs(c).getString("stats", "")?.split(";")?.forEach { s ->
            val a = s.split(",")
            if (a.size == 4) runCatching { stats.add(Stat(a[0].toFloat(), a[1].toFloat(), a[2].toInt(), a[3].toInt())) }
        }
    }

    @Synchronized fun save(c: Context) {
        prefs(c).edit().putInt("hunts", hunts)
            .putString("stats", stats.joinToString(";") { "${it.x},${it.y},${it.n},${it.m}" }).apply()
    }

    private fun find(x: Float, y: Float): Stat? =
        stats.minByOrNull { hypot(it.x - x, it.y - y) }?.takeIf { hypot(it.x - x, it.y - y) < 0.03f }

    @Synchronized fun record(c: Context, x: Float, y: Float, mimic: Boolean) {
        val s = find(x, y) ?: Stat(x, y, 0, 0).also { stats.add(it) }
        s.n++; if (mimic) s.m++
        save(c)
    }

    /** Исправление результата последнего открытого сундука. */
    @Synchronized fun fix(c: Context, x: Float, y: Float, toMimic: Boolean) {
        val s = find(x, y) ?: return
        if (toMimic && s.m < s.n) s.m++ else if (!toMimic && s.m > 0) s.m--
        save(c)
    }

    @Synchronized fun reset(c: Context) { stats.clear(); hunts = 0; save(c) }
    @Synchronized fun opens() = stats.sumOf { it.n }
    @Synchronized fun informative(closed: List<Slot>) = closed.any { (find(it.x, it.y)?.n ?: 0) >= 10 }

    /**
     * Базовый шанс = мимиков осталось / закрытых сундуков (одинаков для всех, если мест не различать).
     * Дальше шанс слегка сдвигается по накопленной статистике места (сглаживание к общему среднему),
     * сумма вероятностей сохраняется. Пока данных мало — все сундуки получают почти одинаковый шанс.
     */
    @Synchronized fun compute(closed: List<Slot>, mimicsLeft: Int): Float {
        if (closed.isEmpty()) return 0f
        val tn = stats.sumOf { it.n }
        val tm = stats.sumOf { it.m }
        val ref = (tm + 4f) / (tn + 30f)
        val k = 20f
        val base = (mimicsLeft.toFloat() / closed.size).coerceIn(0f, 1f)
        val rates = closed.map { s -> val st = find(s.x, s.y); ((st?.m ?: 0) + k * ref) / ((st?.n ?: 0) + k) }
        val mean = rates.average().toFloat()
        closed.forEachIndexed { i, s -> s.p = (base * rates[i] / mean).coerceIn(0f, 1f) }
        return base
    }
}

/** Прозрачный слой поверх игры: красит сундуки и подписывает шанс. Касания пропускает. */
class MarkView(c: Context) : View(c) {
    class Mark(val x: Float, val y: Float, val r: Float, val color: Int, val label: String)

    @Volatile var marks: List<Mark> = emptyList()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 6f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true; textSize = 34f
        setShadowLayer(5f, 0f, 0f, Color.BLACK)
    }

    override fun onDraw(c: Canvas) {
        for (m in marks) {
            val rect = RectF(m.x - m.r, m.y - m.r, m.x + m.r, m.y + m.r)
            fill.color = m.color; fill.alpha = 45          // лёгкий тон, чтобы не искажать цвет сундука
            ring.color = m.color; ring.alpha = 235
            c.drawRoundRect(rect, 12f, 12f, fill)
            c.drawRoundRect(rect, 12f, 12f, ring)
            c.drawText(m.label, m.x, m.y + 12f, txt)
        }
    }
}
