package com.slayerbot

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var pal: Ui.Pal
    private var neon = true
    private lateinit var big: TextView
    private lateinit var l1: TextView
    private lateinit var l2: TextView
    private lateinit var l3: TextView
    private lateinit var card: LinearLayout
    private var hideBtn: Button? = null
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun tv(t: String, size: Float, color: Int = Ui.CREAM) = Ui.text(this, t, size, color)
    private fun lp() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.bg(this@MainActivity, Ui.mix(pal.bg, Color.WHITE, 0.07f), pal.edge, neon)
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }
    private fun btn(t: String, fill: Int, click: () -> Unit) = Button(this).apply {
        text = t; textSize = 14f; isAllCaps = false; setTextColor(Ui.CREAM); typeface = Ui.font
        background = Ui.bg(this@MainActivity, fill, pal.accent, neon)
        minHeight = dp(52); minimumHeight = dp(52)
        setOnClickListener { try { click() } catch (e: Throwable) { CrashLog.save(this@MainActivity, e) } }
    }
    private fun fillBtn() = Ui.alpha(Ui.mix(pal.panel, Color.WHITE, 0.14f), 0xEE)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        CrashLog.install(this)
        pal = Ui.pal(this, false)
        neon = Ui.neonOn(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(28), dp(18), dp(24))
            setBackgroundColor(pal.bg)
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(FrameLayout(this).apply {
            addView(PortalView(this@MainActivity).apply { frame = pal.accent }, FrameLayout.LayoutParams(-1, -1))
            addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_sword_fg) }, FrameLayout.LayoutParams(-1, -1))
        }, LinearLayout.LayoutParams(dp(76), dp(76)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
        titles.addView(tv("idle ULTIMA", 26f, pal.accent))
        titles.addView(tv("автопомощник для Idle Slayer", 12f, Ui.MUTED))
        head.addView(titles)
        root.addView(head)

        card = card()
        big = tv("", 22f)
        l1 = tv("", 13f, Ui.MUTED); l2 = tv("", 13f, Ui.MUTED); l3 = tv("", 13f, Ui.MUTED)
        card.addView(tv("СТАТУС", 11f, Ui.MUTED))
        card.addView(big)
        for (v in listOf(l1, l2, l3)) card.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(card, lp())

        root.addView(btn("⚙  Открыть спец. возможности", Ui.BTN_BLUE) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, lp())
        root.addView(btn("🔓  Ограниченные настройки (сведения)", fillBtn()) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, lp())
        hideBtn = btn("", fillBtn()) {
            Cfg.setBool(this, "menuHidden", !Cfg.bool(this, "menuHidden", false)); paintHide()
        }
        paintHide()
        root.addView(hideBtn, lp())

        // ───── оформление ─────
        val style = card()
        style.addView(tv("ОФОРМЛЕНИЕ", 13f, pal.accent))
        style.addView(tv("Тема приложения", 12f, Ui.MUTED), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        style.addView(swatches("appTheme"))
        style.addView(tv("Тема плавающего меню", 12f, Ui.MUTED), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        style.addView(swatches("menuTheme"))
        style.addView(Ui.stepper(this, "Размер меню", "menuScale", 100, 60, 200, 10, " %", pal), lp())
        style.addView(Ui.stepper(this, "Прозрачность меню", "menuAlpha", 80, 30, 100, 5, " %", pal), lp())
        var nb: Button? = null
        fun nt() = if (Cfg.bool(this, "neon", true)) "✨ Неоновые обводки: ВКЛ" else "✨ Неоновые обводки: выкл"
        nb = btn(nt(), fillBtn()) { Cfg.setBool(this, "neon", !Cfg.bool(this, "neon", true)); recreate() }
        style.addView(nb, lp())
        root.addView(style, lp())

        val info = card()
        info.addView(tv("КАК ПОЛЬЗОВАТЬСЯ", 13f, pal.accent))
        info.addView(tv(
            "1. «Сведения» → ⋮ → «Разрешить ограниченные настройки».\n" +
            "2. «Спец. возможности» → idle ULTIMA → включить.\n" +
            "3. Открой Idle Slayer в горизонтали: появится меню с порталом.\n" +
            "4. ⚙ Настройки → 🎯 Калибровка (точка прыжка, кнопка ускорения, цвета).\n" +
            "5. 🔥 ULTIMA — максимальная частота тапов: прыжки, монеты, ускорение.\n" +
            "6. Громкость вниз = мгновенный СТОП, громкость вверх = показать/скрыть меню.", 12f, Ui.CREAM),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(info, lp())

        val log = CrashLog.read(this)
        if (log != null) {
            val box = card().apply { background = Ui.bg(this@MainActivity, 0xFF2A1B1B.toInt(), 0xFFFF8A65.toInt(), false) }
            box.addView(tv("Журнал (скопируй и пришли, если что-то сломалось)", 12f, 0xFFFFAB91.toInt()))
            val t = tv(log.takeLast(3000), 10f).apply { setTextIsSelectable(true) }
            box.addView(t)
            box.addView(btn("Очистить журнал", Ui.BTN_RED) { CrashLog.clear(this); t.text = ""; box.visibility = View.GONE }, lp())
            root.addView(box, lp())
        }

        val frame = FrameLayout(this)
        frame.addView(ScrollView(this).apply { setBackgroundColor(pal.bg); addView(root) })
        if (s == null) frame.addView(splash())
        setContentView(frame)
    }

    private fun paintHide() {
        hideBtn?.text = if (Cfg.bool(this, "menuHidden", false)) "👁  Показать плавающее меню" else "🙈  Скрыть плавающее меню"
    }

    /** Ряд цветных квадратиков-тем. */
    private fun swatches(key: String): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val cur = Cfg.int(this, key, 0)
        Ui.pals.forEachIndexed { i, p ->
            val v = View(this)
            val g = GradientDrawable().apply {
                cornerRadius = dp(4).toFloat()
                if (p.rainbow) {
                    colors = intArrayOf(0xFFFF3D3D.toInt(), 0xFFFFD23D.toInt(), 0xFF3DFF9A.toInt(), 0xFF3DA5FF.toInt(), 0xFFB23DFF.toInt())
                    orientation = GradientDrawable.Orientation.LEFT_RIGHT
                } else setColor(p.accent)
                setStroke(dp(if (i == cur) 3 else 1), if (i == cur) Color.WHITE else p.edge)
            }
            v.background = g
            v.setOnClickListener { Cfg.setInt(this, key, i); recreate() }
            row.addView(v, LinearLayout.LayoutParams(0, dp(42), 1f).apply { rightMargin = dp(6); topMargin = dp(6) })
        }
        return row
    }

    /** Заставка при запуске: портал с мечами и полоса загрузки. */
    private fun splash(): View {
        val sp = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(pal.bg); isClickable = true
        }
        sp.addView(FrameLayout(this).apply {
            addView(PortalView(this@MainActivity).apply { frame = pal.accent }, FrameLayout.LayoutParams(-1, -1))
            addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_sword_fg) }, FrameLayout.LayoutParams(-1, -1))
        }, LinearLayout.LayoutParams(dp(170), dp(170)))
        sp.addView(tv("idle ULTIMA", 32f, pal.accent).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(22) })
        sp.addView(tv("ЗАГРУЗКА…", 12f, Ui.MUTED), LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })
        val bar = View(this).apply {
            background = Ui.bg(this@MainActivity, pal.accent, pal.accent, neon, 3)
            pivotX = 0f; scaleX = 0f
        }
        sp.addView(bar, LinearLayout.LayoutParams(dp(220), dp(10)).apply { topMargin = dp(18) })
        bar.animate().scaleX(1f).setDuration(1300).start()
        sp.postDelayed({ sp.animate().alpha(0f).setDuration(350).withEndAction { sp.visibility = View.GONE }.start() }, 1500)
        return sp
    }

    override fun onResume() { super.onResume(); h.post(tick); paintHide() }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun enabled(): Boolean {
        val cn = ComponentName(this, BotService::class.java)
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.split(':').any { ComponentName.unflattenFromString(it) == cn }
    }

    private fun refresh() {
        val en = enabled()
        val st = Status.read(this)
        val alive = en && System.currentTimeMillis() - st.hb < 6000
        val (txt, col) = when {
            alive -> "●  АКТИВНА" to Ui.GREEN
            en -> "●  ВКЛЮЧЕНА, НЕТ ОТВЕТА" to Ui.AMBER
            else -> "●  НЕ АКТИВНА" to Ui.RED
        }
        big.text = txt; big.setTextColor(col)
        card.background = Ui.bg(this, Ui.mix(pal.bg, Color.WHITE, 0.07f), col, neon)
        l1.text = "Служба спец. возможностей: " + if (en) "включена ✔" else "выключена ✖"
        l2.text = "Режимы: " + if (!alive) "—" else if (st.modes.isEmpty()) "не выбраны" else st.modes
        l3.text = "Idle Slayer на экране: " + if (!alive) "—" else if (st.game) "да" else "нет (бот на паузе)"
    }
}
