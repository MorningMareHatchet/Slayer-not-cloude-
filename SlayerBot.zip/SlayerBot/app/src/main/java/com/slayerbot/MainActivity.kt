package com.slayerbot

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var pal: Ui.Pal
    private var neon = false
    private lateinit var big: TextView
    private lateinit var l1: TextView
    private lateinit var l2: TextView
    private lateinit var l3: TextView
    private lateinit var card: LinearLayout
    private var hideBtn: Button? = null
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun tv(t: String, size: Float, color: Int = Ui.CREAM) = Ui.text(this, t, size, color)
    private fun lp() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    private fun cardBg(edge: Int = pal.edge) = Ui.bg(this, Ui.mix(pal.bg, Color.WHITE, 0.05f), edge, neon)
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = cardBg()
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }
    private fun btn(t: String, kind: Int, click: () -> Unit) = Button(this).apply {
        text = t; textSize = 14f; isAllCaps = false; typeface = Ui.font
        setTextColor(if (kind == 1) pal.accent else Ui.CREAM)
        background = Ui.btnBg(this@MainActivity, pal, neon, kind)
        minHeight = dp(50); minimumHeight = dp(50)
        setOnClickListener { try { click() } catch (e: Throwable) { CrashLog.save(this@MainActivity, e) } }
    }
    /** Логотип: фон иконки + скрещённые мечи, скруглённые края. */
    private fun logo(sizeDp: Int): View = FrameLayout(this).apply {
        addView(ImageView(this@MainActivity).apply {
            setImageResource(R.drawable.ic_launcher_bg); scaleType = ImageView.ScaleType.FIT_XY
        }, FrameLayout.LayoutParams(-1, -1))
        addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_sword_fg) }, FrameLayout.LayoutParams(-1, -1))
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, v.width * 0.24f) }
        }
        clipToOutline = true
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        CrashLog.install(this)
        pal = Ui.pal(this, false)
        neon = Ui.neonOn(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(28), dp(18), dp(24))
            setBackgroundColor(pal.bg)
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(logo(64))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
        titles.addView(tv("IDLE ULTIMA", 22f).apply { letterSpacing = 0.14f })
        titles.addView(tv("автопомощник для Idle Slayer", 12f, Ui.MUTED))
        head.addView(titles)
        root.addView(head)

        card = card()
        big = tv("", 20f)
        l1 = tv("", 13f, Ui.MUTED); l2 = tv("", 13f, Ui.MUTED); l3 = tv("", 13f, Ui.MUTED)
        card.addView(tv("СТАТУС", 11f, Ui.MUTED).apply { letterSpacing = 0.12f })
        card.addView(big)
        for (v in listOf(l1, l2, l3)) card.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(card, lp())

        root.addView(btn("Открыть спец. возможности", 1) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, lp())
        root.addView(btn("Ограниченные настройки (сведения)", 0) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, lp())
        root.addView(btn("Вики Idle Slayer", 0) { startActivity(Intent(this, WikiActivity::class.java)) }, lp())
        hideBtn = btn("", 0) {
            Cfg.setBool(this, "menuHidden", !Cfg.bool(this, "menuHidden", false)); paintHide()
        }
        paintHide()
        root.addView(hideBtn, lp())

        // ───── оформление ─────
        val style = card()
        style.addView(tv("ОФОРМЛЕНИЕ", 11f, Ui.MUTED).apply { letterSpacing = 0.12f })
        style.addView(tv("Тема приложения", 12f), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        style.addView(swatches("appTheme"))
        style.addView(tv("Тема плавающего меню", 12f), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        style.addView(swatches("menuTheme"))
        style.addView(Ui.slider(this, "Размер меню", "menuScale", 100, 60, 200, 5, " %", pal, true), lp())
        style.addView(Ui.slider(this, "Прозрачность меню", "menuAlpha", 85, 30, 100, 1, " %", pal, true), lp())
        fun nt() = if (Cfg.bool(this, "neon", false)) "Подсветка рамок: вкл" else "Подсветка рамок: выкл"
        style.addView(btn(nt(), 0) { Cfg.setBool(this, "neon", !Cfg.bool(this, "neon", false)); recreate() }, lp())
        root.addView(style, lp())

        val info = card()
        info.addView(tv("КАК ПОЛЬЗОВАТЬСЯ", 11f, Ui.MUTED).apply { letterSpacing = 0.12f })
        info.addView(tv(
            "1. «Сведения» → ⋮ → «Разрешить ограниченные настройки».\n" +
            "2. «Спец. возможности» → idle ULTIMA → включить.\n" +
            "3. Откройте Idle Slayer в горизонтали: меню появится только в игре.\n" +
            "4. Настройки → Калибровка: точка прыжка, кнопка ускорения, цвета.\n" +
            "5. Охота → Образец сундука: калибровка охоты (один раз, на экране с сундуками).\n" +
            "6. ULTIMA — максимальная частота тапов. Когда вы берёте ключ и появляется поле с сундуками, бот сам покажет объявление и нижнюю панель охоты.\n" +
            "7. Громкость вниз — мгновенный стоп, громкость вверх — показать или скрыть меню.", 12f),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(info, lp())

        val log = CrashLog.read(this)
        if (log != null) {
            val box = card().apply { background = cardBg(0xFF7A4A4A.toInt()) }
            box.addView(tv("Журнал (скопируйте и пришлите, если что-то сломалось)", 12f, Ui.RED))
            val t = tv(log.takeLast(3000), 10f).apply { setTextIsSelectable(true) }
            box.addView(t)
            box.addView(btn("Очистить журнал", 2) { CrashLog.clear(this); t.text = ""; box.visibility = View.GONE }, lp())
            root.addView(box, lp())
        }

        val frame = FrameLayout(this)
        frame.addView(ScrollView(this).apply { setBackgroundColor(pal.bg); addView(root) })
        if (s == null) frame.addView(splash())
        setContentView(frame)
    }

    private fun paintHide() {
        hideBtn?.text = if (Cfg.bool(this, "menuHidden", false)) "Показать плавающее меню" else "Скрыть плавающее меню"
    }

    /** Ряд квадратиков-тем. */
    private fun swatches(key: String): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val cur = Cfg.int(this, key, 0)
        Ui.pals.forEachIndexed { i, p ->
            val v = View(this)
            v.background = GradientDrawable().apply {
                cornerRadius = dp(6).toFloat(); setColor(Ui.mix(p.panel, p.accent, 0.55f))
                setStroke(dp(if (i == cur) 2 else 1), if (i == cur) Color.WHITE else p.edge)
            }
            v.setOnClickListener { Cfg.setInt(this, key, i); recreate() }
            row.addView(v, LinearLayout.LayoutParams(0, dp(40), 1f).apply { rightMargin = dp(6); topMargin = dp(6) })
        }
        return row
    }

    /** Заставка: мягкое свечение, логотип, название и тонкая полоса загрузки. */
    private fun splash(): View {
        val sp = FrameLayout(this).apply {
            isClickable = true
            background = GradientDrawable().apply {
                gradientType = GradientDrawable.RADIAL_GRADIENT
                gradientRadius = dp(430).toFloat()
                setGradientCenter(0.5f, 0.42f)
                colors = intArrayOf(Ui.mix(pal.bg, pal.accent, 0.14f), pal.bg)
            }
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val lg = logo(120)
        val title = tv("IDLE ULTIMA", 26f).apply { letterSpacing = 0.3f; gravity = Gravity.CENTER }
        val sub = tv("автопомощник для Idle Slayer", 12f, Ui.MUTED).apply { letterSpacing = 0.08f; gravity = Gravity.CENTER }
        val track = View(this).apply { setBackgroundColor(Ui.alpha(pal.edge, 170)) }
        val bar = View(this).apply { setBackgroundColor(pal.accent); pivotX = 0f; scaleX = 0f }
        val barBox = FrameLayout(this).apply {
            addView(track, FrameLayout.LayoutParams(-1, -1)); addView(bar, FrameLayout.LayoutParams(-1, -1))
        }
        col.addView(lg)
        col.addView(title, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(26) })
        col.addView(sub, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        col.addView(barBox, LinearLayout.LayoutParams(dp(180), dp(2)).apply { topMargin = dp(40) })
        sp.addView(col, FrameLayout.LayoutParams(-1, -1))

        lg.alpha = 0f; lg.scaleX = 0.92f; lg.scaleY = 0.92f
        lg.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).setInterpolator(DecelerateInterpolator()).start()
        title.alpha = 0f; title.animate().alpha(1f).setStartDelay(300).setDuration(600).start()
        sub.alpha = 0f; sub.animate().alpha(1f).setStartDelay(500).setDuration(600).start()
        bar.animate().scaleX(1f).setDuration(1500).setInterpolator(DecelerateInterpolator()).start()
        sp.postDelayed({ sp.animate().alpha(0f).setDuration(450).withEndAction { sp.visibility = View.GONE }.start() }, 1900)
        return sp
    }

    override fun onResume() { super.onResume(); h.post(tick); paintHide() }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun enabled(): Boolean {
        val cn = ComponentName(this, BotService::class.java)
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.split(':').any { ComponentName.unflattenFromString(it) == cn }
    }

    private fun refresh() {
        val en = enabled()
        val st = Status.read(this)
        val alive = en && System.currentTimeMillis() - st.hb < 6000
        val (txt, col) = when {
            alive -> "●  Активна" to Ui.GREEN
            en -> "●  Включена, нет ответа" to Ui.AMBER
            else -> "●  Не активна" to Ui.RED
        }
        big.text = txt; big.setTextColor(col)
        card.background = cardBg(col)
        l1.text = "Служба спец. возможностей: " + if (en) "включена" else "выключена"
        l2.text = "Режимы: " + if (!alive) "—" else if (st.modes.isEmpty()) "не выбраны" else st.modes
        l3.text = "Idle Slayer на экране: " + if (!alive) "—" else if (st.game) "да" else "нет (меню скрыто, бот на паузе)"
    }
}
