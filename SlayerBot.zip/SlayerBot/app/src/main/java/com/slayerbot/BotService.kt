package com.slayerbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.random.Random

class BotService : AccessibilityService() {
    private class Step(val key: String, val label: String, val def: Int, val min: Int,
                       val max: Int, val step: Int, val unit: String, val rel: Boolean = false)

    private val stepsJ = listOf(
        Step("taps", "Тапов за прыжок", 3, 1, 8, 1, ""),
        Step("tapHold", "Длительность тапа", 30, 10, 100, 1, " мс"),
        Step("tapMs", "Интервал тапов", 140, 5, 600, 1, " мс"),
        Step("pause", "Пауза между прыжками", 700, 0, 3000, 5, " мс")
    )
    private val stepsB = listOf(Step("bInt", "Нажимать ускорение раз в", 5, 1, 120, 1, " с"))
    private val stepsU = listOf(
        Step("uHold", "Длительность тапа", 20, 10, 100, 1, " мс"),
        Step("uGap", "Интервал тапов", 8, 0, 200, 1, " мс")
    )
    private val stepsC = listOf(Step("coinMax", "Макс. размер монеты", 110, 40, 300, 5, " px"))
    private val stepsP = listOf(Step("pDist", "Дистанция до ящика", 12, 3, 40, 1, " %"))
    private val stepsBn = listOf(
        Step("bDelay", "Задержка перед стартом", 900, 0, 3000, 50, " мс"),
        Step("bSwipeMs", "Длительность свайпа", 380, 150, 1200, 10, " мс"),
        Step("bLead", "Опережение прыжка", 12, 2, 40, 1, " %"),
        Step("bMinHold", "Мин. удержание прыжка", 90, 30, 400, 5, " мс"),
        Step("bGain", "Прибавка удержания на высоту", 700, 100, 2000, 10, " мс"),
        Step("bCd", "Пауза между прыжками", 450, 100, 1500, 10, " мс"),
        Step("bPer", "Прыжок против ям каждые (0 — выкл)", 1300, 0, 3000, 100, " мс")
    )
    private val stepsM = listOf(
        Step("menuScale", "Размер меню", 100, 60, 200, 5, " %", true),
        Step("menuAlpha", "Прозрачность меню", 85, 30, 100, 1, " %", true)
    )
    private val stepsH = listOf(
        Step("tplSize", "Размер образца сундука", 7, 3, 15, 1, " %"),
        Step("tplThr", "Допуск поиска сундуков", 28, 10, 70, 1, "")
    )
    private val mods = linkedMapOf("jump" to "Прыжки", "coin" to "Монеты", "pandora" to "Пандора", "boost" to "Ускорение", "bonus" to "Бонус")

    private val on = ConcurrentHashMap<String, Boolean>()
    private val btns = HashMap<String, Button>()
    private val labelOf = HashMap<String, String>()
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val rects = ConcurrentHashMap<String, Rect>()   // места наших окон — туда бот не тапает

    private var menu: View? = null
    private var menuX = 0
    private var menuY = 0
    private var menuExpanded = true
    private var settingsView: View? = null
    private var panel: LinearLayout? = null
    private var panelTxt: TextView? = null
    private var capView: View? = null
    private var frozen: Bitmap? = null
    private var calList: List<Cal.Item> = emptyList()

    // охота за сундуками
    private var huntTab: View? = null
    private var huntInfo: TextView? = null
    private var huntBar: View? = null
    private var huntBarInfo: TextView? = null
    private var huntBarAuto: Button? = null
    private var banner: View? = null
    private var markView: MarkView? = null
    private val session = ArrayList<Slot>()
    @Volatile private var mimicsLeft = 4
    @Volatile private var lastOpened: Slot? = null
    @Volatile private var lastDone: Slot? = null
    @Volatile private var markShown = true
    @Volatile private var huntBusy = false
    @Volatile private var huntScene = false
    @Volatile private var huntSuppressed = false
    @Volatile private var huntMiss = 0
    @Volatile private var closeWatchUntil = 0L
    @Volatile private var nextCloseAt = 0L
    @Volatile private var bonusScene = false
    @Volatile private var bonusMiss = 0
    @Volatile private var bonusSwiped = false
    @Volatile private var bonusStart = 0L
    @Volatile private var lastBonusJump = 0L
    @Volatile private var nextOpenAt = 0L
    @Volatile private var bannerUntil = 0L
    @Volatile private var huntStatus = "Охота не обнаружена"

    @Volatile private var fingerDown = false
    @Volatile private var userTouch = 0L
    @Volatile private var calIdx = -1
    @Volatile private var calBusy = false
    @Volatile private var alive = true
    @Volatile private var inGame = false
    @Volatile private var nextJump = 0L
    @Volatile private var pandoraUntil = 0L
    @Volatile private var nextBoost = 0L
    @Volatile private var asyncBmp: Bitmap? = null
    @Volatile private var asyncBusy = false
    @Volatile private var asyncStart = 0L
    @Volatile private var coinTargets: List<Pair<Float, Float>> = emptyList()
    @Volatile private var lastW = 0
    @Volatile private var lastH = 0
    private var lastShot = 0L

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            "menuTheme", "menuAlpha", "menuScale", "neon" -> ui.post { buildMenu() }
            "menuHidden" -> ui.post { applyVisibility() }
        }
    }

    // ───────── жизненный цикл ─────────
    override fun onServiceConnected() {
        CrashLog.install(this)
        HuntMem.load(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        menuX = dp(4); menuY = dp(12)
        getSharedPreferences("set", MODE_PRIVATE).registerOnSharedPreferenceChangeListener(prefListener)
        buildMenu()
        thread(isDaemon = true) { loop() }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        setInGame(pkg == Cal.GAME_PKG)
    }

    private fun setInGame(v: Boolean) {
        if (inGame != v) { inGame = v; ui.post { applyVisibility() } }
    }

    /** Громкость вниз — аварийный СТОП, громкость вверх — показать/скрыть меню. */
    override fun onKeyEvent(event: KeyEvent): Boolean {
        val k = event.keyCode
        if (k != KeyEvent.KEYCODE_VOLUME_DOWN && k != KeyEvent.KEYCODE_VOLUME_UP) return false
        if (event.action == KeyEvent.ACTION_DOWN) ui.post {
            if (k == KeyEvent.KEYCODE_VOLUME_DOWN) {
                for (m in mods.keys) on[m] = false
                on["ultima"] = false
                paint(); toast("СТОП: все режимы выключены")
            } else setHidden(!Cfg.bool(this, "menuHidden", false))
        }
        return true
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        alive = false
        getSharedPreferences("set", MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(prefListener)
        for (v in listOf(menu, settingsView, huntTab, huntBar, banner, markView, panel)) v?.let { runCatching { wm.removeView(it) } }
        closeCapture()
        super.onDestroy()
    }

    // ───────── общие помощники ─────────
    private fun dp(v: Int) = Ui.dp(this, v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun row() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) }
    private fun text(s: String, size: Float = 13f, color: Int = Ui.CREAM) = Ui.text(this, s, size, color)

    private fun pal() = Ui.pal(this, true)
    private fun neon() = Ui.neonOn(this)
    private fun sc() = Cfg.int(this, "menuScale", 100) / 100f
    private fun md(v: Int) = (dp(v) * sc()).toInt()
    private fun panelFill() = Ui.alpha(pal().panel, Cfg.int(this, "menuAlpha", 85) * 255 / 100)

    private fun touchCb(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { fingerDown = true; userTouch = SystemClock.uptimeMillis() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { fingerDown = false; userTouch = SystemClock.uptimeMillis() }
        }
    }

    /** kind: 0 обычная, 1 главная/включённая, 2 осторожная. */
    private fun mkBtn(label: String, size: Float = 14f, kind: Int = 0, click: () -> Unit): Button {
        val p = pal()
        return Button(this).apply {
            text = label; textSize = size; isAllCaps = false; typeface = Ui.font
            setTextColor(if (kind == 1) p.accent else Ui.CREAM)
            minHeight = dp(40); minimumHeight = dp(40)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            background = Ui.btnBg(this@BotService, p, neon(), kind)
            setOnClickListener {
                CrashLog.note(this@BotService, "click: $label")
                try { click() } catch (t: Throwable) {
                    CrashLog.save(this@BotService, t); toast("Ошибка: $t")
                }
            }
        }
    }

    private fun small(t: String, c: () -> Unit) = mkBtn(t, 18f, 0, c).apply {
        gravity = Gravity.CENTER; minWidth = dp(46); minimumWidth = dp(46); setPadding(0, 0, 0, 0)
    }

    private fun pair(a: View, b: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(3) })
        addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(3) })
    }

    private fun panelBox() = WatchLinear(this) { touchCb(it) }.apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.bg(this@BotService, panelFill(), pal().edge, neon())
        setPadding(dp(12), dp(10), dp(12), dp(12))
    }

    private fun wlp(w: Int, h: Int, full: Boolean) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            (if (full) WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS else 0),
        PixelFormat.TRANSLUCENT
    ).apply {
        if (full) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(8) }
    }

    private fun panelLp(x: Int, y: Int, w: Int) = WindowManager.LayoutParams(
        w, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun markLp() = WindowManager.LayoutParams(
        -1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS }

    private fun refreshRect(v: View, key: String) {
        val loc = IntArray(2); v.getLocationOnScreen(loc)
        rects[key] = Rect(loc[0], loc[1], loc[0] + v.width, loc[1] + v.height)
    }

    private fun track(v: View, key: String) {
        v.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> if (v.visibility == View.VISIBLE) refreshRect(v, key) }
    }

    private fun untrack(key: String) { rects.remove(key) }

    private fun blocked(x: Float, y: Float): Rect? {
        val m = dp(14)
        for (r in rects.values) if (x >= r.left - m && x <= r.right + m && y >= r.top - m && y <= r.bottom + m) return r
        return null
    }

    private fun safePt(px: Float, py: Float): Pair<Float, Float> {
        var x = px
        repeat(4) { val r = blocked(x, py) ?: return Pair(x, py); x = r.right + dp(30).toFloat() }
        return Pair(x.coerceAtMost(sw() - 2f), py)
    }

    private fun drag(handle: View, win: View, lp: WindowManager.LayoutParams, key: String,
                     onMove: ((Int, Int) -> Unit)? = null, onClick: (() -> Unit)? = null) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) + abs(dy) > 12) moved = true
                    lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt()
                    wm.updateViewLayout(win, lp)
                    onMove?.invoke(lp.x, lp.y)
                    win.postDelayed({ refreshRect(win, key) }, 120)
                }
                MotionEvent.ACTION_UP -> if (!moved) onClick?.invoke()
            }
            true
        }
    }

    /** Меню и окна — только в игре и не во время охоты (там остаётся одна нижняя панель). */
    private fun applyVisibility() {
        val show = inGame && !Cfg.bool(this, "menuHidden", false) && !huntScene
        val vis = if (show) View.VISIBLE else View.GONE
        val all = mapOf("menu" to menu, "set" to settingsView, "hunt" to huntTab, "cal" to panel)
        for ((k, v) in all) {
            v?.visibility = vis
            if (!show) untrack(k) else v?.let { vv -> vv.postDelayed({ refreshRect(vv, k) }, 150) }
        }
        val barShow = inGame && huntScene && !huntSuppressed
        huntBar?.visibility = if (barShow) View.VISIBLE else View.GONE
        if (!barShow) untrack("bar") else huntBar?.let { vv -> vv.postDelayed({ refreshRect(vv, "bar") }, 150) }
        markView?.visibility = if (inGame && markShown && !huntSuppressed) View.VISIBLE else View.INVISIBLE
    }

    // ───────── плавающее меню ─────────
    private fun menuBtn(label: String, kind: Int = 0, click: () -> Unit) =
        mkBtn(label, 12f * sc(), kind, click).apply {
            minHeight = md(36); minimumHeight = md(36); setPadding(md(6), md(2), md(6), md(2)); gravity = Gravity.CENTER
        }

    private fun sizeBtn(t: String, d: Int) = mkBtn(t, 14f * sc(), 0) {
        Cfg.setInt(this, "menuScale", (Cfg.int(this, "menuScale", 100) + d).coerceIn(60, 200))
    }.apply { minWidth = md(30); minimumWidth = md(30); minHeight = md(30); minimumHeight = md(30); setPadding(0, 0, 0, 0); gravity = Gravity.CENTER }

    private fun buildMenu() {
        menu?.let { runCatching { wm.removeView(it) } }
        untrack("menu"); btns.clear(); labelOf.clear()
        val p = pal()
        val box = WatchLinear(this) { touchCb(it) }.apply { orientation = LinearLayout.VERTICAL; setPadding(md(6), md(4), md(6), md(6)) }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val extras = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val lp = panelLp(menuX, menuY, md(230))

        fun restyle() {
            body.visibility = if (menuExpanded) View.VISIBLE else View.GONE
            extras.visibility = body.visibility
            box.background = if (menuExpanded) Ui.bg(this, panelFill(), p.edge, neon()) else null
            lp.width = if (menuExpanded) md(230) else WindowManager.LayoutParams.WRAP_CONTENT
        }
        restyle()

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(PortalView(this).apply { frame = p.accent }, LinearLayout.LayoutParams(md(44), md(44)))
        extras.addView(text("IDLE ULTIMA", 11f * sc(), Ui.MUTED).apply { letterSpacing = 0.12f; setPadding(md(10), 0, md(4), 0) },
            LinearLayout.LayoutParams(0, -2, 1f))
        extras.addView(sizeBtn("−", -10)); extras.addView(sizeBtn("+", 10))
        head.addView(extras, LinearLayout.LayoutParams(0, -2, 1f))
        drag(head, box, lp, "menu", onMove = { x, y -> menuX = x; menuY = y }, onClick = {
            menuExpanded = !menuExpanded
            restyle(); wm.updateViewLayout(box, lp)
            box.postDelayed({ refreshRect(box, "menu") }, 120)
        })
        box.addView(head); box.addView(body)

        fun reg(k: String, label: String): Button {
            val b = menuBtn(label) { setOn(k, on[k] != true); paint() }
            btns[k] = b; labelOf[k] = label
            return b
        }
        body.addView(reg("ultima", "ULTIMA"), row())
        body.addView(pair(reg("jump", mods["jump"]!!), reg("coin", mods["coin"]!!)), row())
        body.addView(pair(reg("pandora", mods["pandora"]!!), reg("boost", mods["boost"]!!)), row())
        body.addView(pair(reg("bonus", mods["bonus"]!!), menuBtn("Охота") { openHuntTab() }), row())
        body.addView(pair(menuBtn("Настройки") { openSettings() }, menuBtn("Скрыть") { setHidden(true); toast("Меню скрыто. Показать: громкость + или кнопка в приложении") }), row())
        body.addView(text("Громкость −: стоп   +: меню", 9f * sc(), Ui.MUTED).apply { gravity = Gravity.CENTER }, row())
        wm.addView(box, lp)
        menu = box; track(box, "menu")
        paint()
        applyVisibility()
    }

    private fun setHidden(v: Boolean) { Cfg.setBool(this, "menuHidden", v); applyVisibility() }

    /** ULTIMA и остальные режимы взаимоисключающие: оба шлют жесты и перебивали бы друг друга. */
    private fun setOn(k: String, v: Boolean) {
        if (v) {
            if (k == "ultima") mods.keys.forEach { on[it] = false } else on["ultima"] = false
            if ((k == "boost" || k == "ultima") && !Cal.isSet(this, "boost"))
                toast("Ускорение: откалибруй кнопку в игре (Настройки → Калибровка)")
            if (k == "pandora" && Cal.get(this, "pandora").color == 0)
                toast("Пандора: откалибруй цвет ящика (Настройки → Калибровка)")
            if (k == "bonus" && !TplStore.has(this, "bonusMark"))
                toast("Бонус-уровень: откалибруй (Настройки → Калибровка бонус-уровня)")
            if (Cfg.bool(this, "autoHunt", true) && !TplStore.has(this, "chest"))
                toast("Охота: сначала откалибруй образец сундука (Охота → Калибровка охоты)")
        }
        on[k] = v
    }

    private fun paint() {
        val p = pal()
        for ((k, b) in btns) {
            val a = on[k] == true
            b.background = Ui.btnBg(this, p, neon(), if (a) 1 else 0)
            b.setTextColor(if (a) p.accent else Ui.CREAM)
            val base = labelOf[k] ?: ""
            b.text = if (k == "ultima") (if (a) "ULTIMA  ·  СТОП" else "ULTIMA") else (if (a) "●  $base" else "○  $base")
        }
    }

    // ───────── настройки ─────────
    private fun sliderRow(st: Step): View = Ui.slider(this, st.label, st.key, st.def, st.min, st.max, st.step, st.unit, pal(), st.rel)

    private fun toggleBtn(key: String, def: Boolean, onText: String, offText: String): Button {
        var b: Button? = null
        fun t() = if (Cfg.bool(this, key, def)) onText else offText
        b = mkBtn(t(), 13f) { Cfg.setBool(this, key, !Cfg.bool(this, key, def)); b?.text = t() }
        return b!!
    }

    private fun openSettings() {
        if (settingsView != null) { closeSettings(); return }
        val col = panelBox()
        col.addView(text("НАСТРОЙКИ", 14f, pal().accent))
        fun section(t: String) = col.addView(text(t, 11f, Ui.MUTED), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        section("ПРЫЖКИ И ЛУК")
        for (st in stepsJ) col.addView(sliderRow(st), row())
        section("УСКОРЕНИЕ (КНОПКА В ИГРЕ)")
        for (st in stepsB) col.addView(sliderRow(st), row())
        col.addView(toggleBtn("bCol", false, "Жать, только когда кнопка готова (по цвету)", "Жать по таймеру (без проверки цвета)"), row())
        section("ULTIMA — МИНИМАЛЬНЫЙ ИНТЕРВАЛ")
        for (st in stepsU) col.addView(sliderRow(st), row())
        section("МОНЕТЫ")
        for (st in stepsC) col.addView(sliderRow(st), row())
        section("БОНУС-УРОВЕНЬ (ФИОЛЕТОВЫЙ ПОРТАЛ)")
        for (st in stepsBn) col.addView(sliderRow(st), row())
        col.addView(toggleBtn("bSwipe", true, "Свайп слева направо на старте: вкл", "Свайп на старте: выкл"), row())
        col.addView(mkBtn("Калибровка бонус-уровня", 13f, 1) { closeSettings(); startCal(2) }, row())
        section("ПАНДОРА")
        for (st in stepsP) col.addView(sliderRow(st), row())
        col.addView(toggleBtn("pUp", false, "Ящик: с прокачкой (тап 2 с)", "Ящик: обычный (тап 0,5 с)"), row())
        section("ВИД МЕНЮ")
        for (st in stepsM) col.addView(sliderRow(st), row())
        col.addView(toggleBtn("neon", false, "Подсветка рамок: вкл", "Подсветка рамок: выкл"), row())
        col.addView(mkBtn("Калибровка точек и цветов", 13f, 1) { closeSettings(); startCal(0) }, row())
        col.addView(mkBtn("Закрыть", 13f) { closeSettings() }, row())
        val sv = WatchScroll(this) { touchCb(it) }.apply { addView(col) }
        settingsView = sv
        wm.addView(sv, panelLp(dp(240), dp(8), dp(390)))
        track(sv, "set")
    }

    private fun closeSettings() {
        settingsView?.let { runCatching { wm.removeView(it) } }
        settingsView = null; untrack("set")
    }

    // ───────── калибровка: снимок экрана → тап по снимку ─────────
    /** group 0 — общая (в настройках), group 1 — охота (в меню охоты). */
    private fun startCal(group: Int) {
        if (panel != null) { toast("Калибровка уже идёт"); return }
        calList = Cal.items.filter { it.group == group }
        if (calList.isEmpty()) return
        calIdx = 0
        val p = panelBox()
        val t = text("", 13f)
        p.addView(t)
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val m = { LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6); topMargin = dp(8) } }
        r.addView(mkBtn("Выбрать точку", 13f, 1) { beginPick() }, m())
        r.addView(mkBtn("Пропуск", 13f) { nextCal() }, m())
        r.addView(mkBtn("Выход", 13f) { stopCal() }, m())
        p.addView(r)
        panel = p; panelTxt = t
        wm.addView(p, wlp(-2, -2, false))
        track(p, "cal")
        showHint()
    }

    private fun showHint() {
        val it = calList[calIdx]
        panelTxt?.text = "(${calIdx + 1}/${calList.size}) ${it.hint}\nОткрой в игре нужный экран → «Выбрать точку»"
    }

    private fun nextCal() {
        closeCapture()
        calIdx++
        if (calIdx >= calList.size) stopCal() else showHint()
    }

    private fun beginPick() {
        if (capView != null) { closeCapture(); showHint(); return }
        if (calBusy) return
        calBusy = true
        panel?.visibility = View.INVISIBLE
        menu?.visibility = View.INVISIBLE
        huntTab?.visibility = View.INVISIBLE
        thread {
            Thread.sleep(250)
            val b = shot()
            ui.post {
                panel?.visibility = View.VISIBLE
                menu?.visibility = View.VISIBLE
                huntTab?.visibility = View.VISIBLE
                calBusy = false
                if (b == null) toast("Снимок экрана не получился, попробуй ещё раз") else showCapture(b)
            }
        }
    }

    private fun showCapture(b: Bitmap) {
        frozen = b
        val iv = ImageView(this).apply { setImageBitmap(b); scaleType = ImageView.ScaleType.FIT_XY }
        iv.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP && calIdx >= 0) {
                val fx = (e.x / v.width).coerceIn(0f, 1f)
                val fy = (e.y / v.height).coerceIn(0f, 1f)
                val item = calList[calIdx]
                if (item.tpl) saveTemplate(b, item.key, fx, fy)
                else {
                    val col = if (item.needColor) b.getPixel((fx * (b.width - 1)).toInt(), (fy * (b.height - 1)).toInt()) else 0
                    Cal.set(this@BotService, item.key, Pt(fx, fy, col))
                    toast("Сохранено")
                }
                nextCal()
            }
            true
        }
        capView = iv
        wm.addView(iv, wlp(-1, -1, true))
        panel?.let { runCatching { wm.removeView(it) }; wm.addView(it, wlp(-2, -2, false)) }
        panelTxt?.text = "Тапни точно по нужному месту на снимке.\n(«Выбрать точку» ещё раз — отмена)"
    }

    /** Запоминаем фрагмент снимка вокруг тапа как образец и сразу показываем, сколько таких нашлось. */
    private fun saveTemplate(b: Bitmap, key: String, fx: Float, fy: Float) {
        val side = (Cfg.int(this, "tplSize", 7) / 100f * b.height).toInt().coerceIn(24, minOf(b.width, b.height) - 2)
        val x0 = ((fx * b.width).toInt() - side / 2).coerceIn(0, b.width - side)
        val y0 = ((fy * b.height).toInt() - side / 2).coerceIn(0, b.height - side)
        TplStore.save(this, key, Bitmap.createBitmap(b, x0, y0, side, side))
        if (key == "huntClose") {
            Cfg.setInt(this, "closeX", (fx * 10000).toInt()); Cfg.setInt(this, "closeY", (fy * 10000).toInt())
            toast("Кнопка «Закрыть» запомнена"); return
        }
        if (key != "chest") { toast("Образец сохранён"); return }
        val t = TplStore.load(this, key)
        val n = if (t != null) Vision.matchTpl(b, Cal.CHEST_AREA, t, Cfg.int(this, "tplThr", 28)).size else 0
        toast("Образец сохранён. На этом снимке найдено сундуков: $n" + if (n < 8) " (нужно ≥ 8 — подстрой размер и допуск)" else "")
    }

    private fun closeCapture() {
        capView?.let { runCatching { wm.removeView(it) } }
        capView = null
        frozen?.recycle(); frozen = null
    }

    private fun stopCal() {
        closeCapture()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null; panelTxt = null; calIdx = -1; untrack("cal")
        toast("Калибровка завершена")
    }

    // ───────── охота за сундуками: оформление ─────────
    private fun ensureMarks() {
        if (markView == null) markView = MarkView(this).also { wm.addView(it, markLp()) }
        applyVisibility()
    }

    private fun removeMarks() {
        markView?.let { runCatching { wm.removeView(it) } }
        markView = null
    }

    /** Плавное объявление сверху: появляется, держится пару секунд и растворяется. */
    private fun showBanner(title: String, sub: String) {
        banner?.let { runCatching { wm.removeView(it) } }
        val p = pal()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(26), dp(12), dp(26), dp(12))
            background = Ui.bg(this@BotService, Ui.alpha(p.panel, 0xF0), p.accent, neon(), 10)
        }
        box.addView(text(title, 16f, Ui.CREAM).apply { letterSpacing = 0.06f; gravity = Gravity.CENTER })
        box.addView(text(sub, 12f, Ui.MUTED).apply { gravity = Gravity.CENTER })
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(16) }
        box.alpha = 0f; box.translationY = -dp(18).toFloat()
        wm.addView(box, lp); banner = box
        box.animate().alpha(1f).translationY(0f).setDuration(450).setInterpolator(DecelerateInterpolator()).start()
        box.postDelayed({
            box.animate().alpha(0f).translationY(-dp(10).toFloat()).setDuration(550).withEndAction {
                runCatching { wm.removeView(box) }
                if (banner === box) banner = null
            }.start()
        }, 2300)
    }

    /** Единственная панель на время охоты — тонкая полоса внизу экрана. */
    private fun showHuntBar() {
        if (huntBar != null) return
        val p = pal()
        val bar = WatchLinear(this) { touchCb(it) }.apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = Ui.bg(this@BotService, Ui.alpha(p.panel, 0xEB), p.edge, neon(), 8)
            setPadding(dp(12), dp(4), dp(8), dp(4))
        }
        huntBarInfo = text("", 11f).also { bar.addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        fun b(label: String, kind: Int = 0, c: () -> Unit) = mkBtn(label, 11f, kind, c).apply {
            minHeight = dp(34); minimumHeight = dp(34); setPadding(dp(10), 0, dp(10), 0); gravity = Gravity.CENTER
        }
        fun add(v: View) = bar.addView(v, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(6) })
        add(b("Открыть лучший", 1) { openBestOnce() })
        huntBarAuto = b("") { Cfg.setBool(this, "huntAuto", !Cfg.bool(this, "huntAuto", true)); paintBar() }
        add(huntBarAuto!!)
        add(b("Это мимик") { fixLast(true) })
        add(b("Это награда") { fixLast(false) })
        add(b("Выйти") { huntSuppressed = true; applyVisibility(); toast("Бот не трогает охоту до её конца") })
        val lp = WindowManager.LayoutParams(
            (sw() - dp(24)).coerceAtLeast(dp(300)), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(6) }
        bar.alpha = 0f
        wm.addView(bar, lp); huntBar = bar; track(bar, "bar")
        bar.animate().alpha(1f).setDuration(500).start()
        paintBar()
    }

    private fun paintBar() {
        val a = Cfg.bool(this, "huntAuto", true)
        huntBarAuto?.apply {
            text = if (a) "Авто: вкл" else "Авто: выкл"
            background = Ui.btnBg(this@BotService, pal(), neon(), if (a) 1 else 0)
            setTextColor(if (a) pal().accent else Ui.CREAM)
        }
    }

    private fun removeHuntBar() {
        huntBar?.let { runCatching { wm.removeView(it) } }
        huntBar = null; huntBarInfo = null; huntBarAuto = null; untrack("bar")
    }

    private fun onHuntStart() {
        closeSettings(); closeHuntTab()
        bannerUntil = SystemClock.uptimeMillis() + 2800   // пока висит объявление, поле не анализируем
        showBanner("Охота за сундуками", "Бот взял управление")
        showHuntBar(); ensureMarks()
        applyVisibility()
    }

    private fun onHuntEnd() {
        removeHuntBar(); removeMarks()
        applyVisibility()
        showBanner("Охота завершена", "Результат записан в память")
    }

    // ───────── вкладка «Охота» (вне самой охоты): калибровка, обучение, справка ─────────
    private fun openHuntTab() {
        if (huntTab != null) { closeHuntTab(); return }
        closeSettings()
        val col = panelBox()
        val head = text("ОХОТА ЗА СУНДУКАМИ", 13f, pal().accent).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, dp(6)) }
        col.addView(head)
        huntInfo = text("", 12f).also { col.addView(it) }
        fun section(t: String) = col.addView(text(t, 11f, Ui.MUTED), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        section("КАЛИБРОВКА ОХОТЫ")
        col.addView(mkBtn("Калибровка охоты: сундук и «Закрыть»", 13f, 1) { closeHuntTab(); startCal(1) }, row())
        for (st in stepsH) col.addView(sliderRow(st), row())
        col.addView(mkBtn("Проверить поиск на экране", 13f) { runScan() }, row())
        section("ПОВЕДЕНИЕ")
        col.addView(toggleBtn("autoHunt", true, "Реагировать на охоту: вкл", "Реагировать на охоту: выкл"), row())
        col.addView(toggleBtn("huntAuto", true, "Открывать сундуки самому: вкл", "Открывать сундуки самому: выкл"), row())
        section("ОБУЧЕНИЕ")
        col.addView(pair(mkBtn("Сброс обучения", 12f, 2) { HuntMem.resetLearning(this); toast("Обучение исходов сброшено") },
            mkBtn("Сброс памяти", 12f, 2) { HuntMem.reset(this); recompute(); refreshHuntUi(); toast("Вся память охоты очищена") }), row())
        col.addView(pair(mkBtn("Справка (вики)", 12f) { openWiki("Chest Hunt") }, mkBtn("Закрыть", 13f) { closeHuntTab() }), row())

        val sv = WatchScroll(this) { touchCb(it) }.apply { addView(col) }
        val w = dp(340)
        val lp = panelLp(resources.displayMetrics.widthPixels - w - dp(8), dp(8), w)
        drag(head, sv, lp, "hunt")
        wm.addView(sv, lp)
        huntTab = sv; track(sv, "hunt")
        applyVisibility()
        refreshHuntUi()
    }

    private fun closeHuntTab() {
        huntTab?.let { runCatching { wm.removeView(it) } }
        huntTab = null; huntInfo = null; untrack("hunt")
    }

    private fun openWiki(q: String) {
        startActivity(Intent(this, WikiActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("q", q))
    }

    private fun recompute() {
        synchronized(session) { HuntMem.compute(session.filter { it.state == 0 }, mimicsLeft) }
    }

    private fun status(s: String) { huntStatus = s; ui.post { refreshHuntUi() } }

    /** Подсветка: красный — шанс выше среднего, зелёный — ниже, жёлтый — как у всех. Всё пересчитывается заново. */
    private fun refreshHuntUi() {
        val W = sw().toFloat(); val H = sh().toFloat()
        val marks = ArrayList<MarkView.Mark>()
        var closedN = 0
        var base = 0f
        var informative = false
        synchronized(session) {
            val closed = session.filter { it.state == 0 }
            closedN = closed.size
            base = if (closedN > 0) (mimicsLeft.toFloat() / closedN).coerceIn(0f, 1f) else 0f
            informative = HuntMem.informative(closed)
            for (s in session) {
                if (s.state == 0) {
                    val ratio = if (base > 0f) s.p / base else 1f
                    val col = when { ratio > 1.25f -> Ui.MK_RED; ratio < 0.8f -> Ui.MK_GREEN; else -> Ui.MK_AMBER }
                    marks.add(MarkView.Mark(s.x * W, s.y * H, s.r, col, "${(s.p * 100).toInt()}%"))
                } else if (s.state == 2) marks.add(MarkView.Mark(s.x * W, s.y * H, s.r, Ui.MK_RED, "мимик"))
            }
        }
        markView?.marks = marks
        markView?.invalidate()
        val (mn, rn) = HuntMem.sigCounts()
        val learn = if (mn >= 2 && rn >= 3) "исходы распознаёт" else "исходы обучаются ($mn/$rn)"
        huntBarInfo?.text = "Закрыто $closedN · мимиков $mimicsLeft · шанс ${(base * 100).toInt()}% · $learn"
        huntInfo?.text = "$huntStatus\n" +
            "Закрыто: $closedN   Мимиков осталось: $mimicsLeft\n" +
            "Шанс мимика: ${(base * 100).toInt()}%" + (if (informative) " (с учётом статистики)" else " (у всех одинаков)") + "\n" +
            "Память: ${HuntMem.hunts} охот, ${HuntMem.opens()} открытий\n" +
            "Образец сундука: " + (if (TplStore.has(this, "chest")) "задан" else "НЕ задан") + "\n" +
            "Распознавание исходов: $learn"
    }

    // ───────── охота: ядро ─────────
    private fun chestMatches(b: Bitmap, t: Tpl) =
        Vision.matchTpl(b, Cal.CHEST_AREA, t, Cfg.int(this, "tplThr", 28)).filter { blocked(it.cx, it.cy) == null }

    /** «Подпись» области вокруг сундука: сетка 8×8 средних цветов. Мимик и награда выглядят по-разному. */
    private fun sigAt(b: Bitmap, cx: Float, cy: Float, side: Float): IntArray {
        val n = 8
        val out = IntArray(n * n * 3)
        for (j in 0 until n) for (i in 0 until n) {
            val x = (cx - side / 2 + (i + 0.5f) * side / n).toInt().coerceIn(1, b.width - 2)
            val y = (cy - side / 2 + (j + 0.5f) * side / n).toInt().coerceIn(1, b.height - 2)
            var r = 0; var g = 0; var bl = 0
            for (dy in -1..1) for (dx in -1..1) {
                val p = b.getPixel(x + dx, y + dy); r += Color.red(p); g += Color.green(p); bl += Color.blue(p)
            }
            val k = (j * n + i) * 3
            out[k] = r / 9; out[k + 1] = g / 9; out[k + 2] = bl / 9
        }
        return out
    }

    /** Исходы: через ~0.45 с после открытия снимаем подпись и классифицируем (вызывать внутри synchronized(session)). */
    private fun samplePendingLocked(b: Bitmap) {
        val now = SystemClock.uptimeMillis()
        val W = b.width.toFloat(); val H = b.height.toFloat()
        for (s in session.filter { it.state == 3 && now - it.openedAt >= 450 }) {
            val sig = sigAt(b, s.x * W, s.y * H, s.r * 2.2f)
            s.sig = sig
            // охота продолжилась → предыдущая «награда» подтверждена, запоминаем как выглядит награда
            lastDone?.let { prev ->
                val ps = prev.sig
                if (prev.state == 1 && !prev.learned && ps != null) { HuntMem.addSig(this, false, ps); prev.learned = true }
            }
            val mimic = HuntMem.classify(sig) == true
            s.state = if (mimic) 2 else 1
            if (mimic) mimicsLeft = maxOf(0, mimicsLeft - 1)
            HuntMem.record(this, s.x, s.y, mimic)
            lastDone = s
        }
    }

    /** Завершение охоты (вызывать внутри synchronized(session)). */
    private fun finishHuntLocked(heuristic: Boolean) {
        val closed = session.count { it.state == 0 }
        val opened = session.count { it.state != 0 }
        // охота оборвалась при закрытых сундуках → скорее всего последний открытый был мимиком
        if (heuristic && closed >= 2 && session.none { it.state == 2 }) {
            val s = session.filter { it.state == 3 || it.state == 1 }.maxByOrNull { it.openedAt }
            if (s != null) {
                if (s.state == 1) HuntMem.fix(this, s.x, s.y, true) else HuntMem.record(this, s.x, s.y, true)
                s.state = 2; mimicsLeft = maxOf(0, mimicsLeft - 1)
                s.sig?.let { HuntMem.addSig(this, true, it) }
            }
        }
        for (s in session) if (s.state == 3) { s.state = 1; HuntMem.record(this, s.x, s.y, false) }
        if (opened > 0) { HuntMem.hunts++; HuntMem.save(this) }
    }

    /** Сопоставляет найденные сундуки с полем: исчезнувшие считаются открытыми. Метки пересчитываются, а не накладываются. */
    private fun updateSession(dets: List<Vision.Match>, b: Bitmap) {
        val W = b.width.toFloat(); val H = b.height.toFloat()
        val now = SystemClock.uptimeMillis()
        val det = dets.map { Triple(it.cx / W, it.cy / H, it.r) }
        synchronized(session) {
            val closedS = session.filter { it.state == 0 }
            if (session.isEmpty() || det.size > closedS.size + 3) {          // новое поле
                if (session.isNotEmpty()) finishHuntLocked(false)
                session.clear(); mimicsLeft = 4; lastOpened = null; lastDone = null
                det.forEach { session.add(Slot(it.first, it.second, it.third)) }
            } else {
                for (s in closedS) {
                    val d = det.minByOrNull { hypot(it.first - s.x, it.second - s.y) }
                    if (d != null && hypot(d.first - s.x, d.second - s.y) < 0.03f) s.r = d.third
                    else { s.state = 3; s.openedAt = now; lastOpened = s }
                }
            }
            samplePendingLocked(b)
            HuntMem.compute(session.filter { it.state == 0 }, mimicsLeft)
        }
    }

    /**
     * Вызывается циклом на каждом новом кадре. true — на экране охота: обычные тапы не нужны.
     * Принцип: сундуки ищутся по образцу-картинке (а не по цвету), поэтому монеты и мимики не путаются.
     */
    private fun huntTick(bmp: Bitmap): Boolean {
        if (!Cfg.bool(this, "autoHunt", true)) return false
        if (closeCheck(bmp)) return true
        val tpl = TplStore.load(this, "chest") ?: return false
        val dets = chestMatches(bmp, tpl)
        if (dets.size < 3 || (!huntScene && dets.size < 8)) {
            if (huntScene) {
                if (!huntSuppressed && SystemClock.uptimeMillis() >= bannerUntil) synchronized(session) { samplePendingLocked(bmp) }
                if (++huntMiss >= 4) endHunt(true)
            }
            return huntScene
        }
        huntMiss = 0
        if (!huntScene) {
            huntScene = true; huntSuppressed = false; huntStatus = "Идёт охота"
            ui.post { onHuntStart() }
        }
        if (huntSuppressed || SystemClock.uptimeMillis() < bannerUntil) return true
        updateSession(dets, bmp)
        ui.post { refreshHuntUi() }
        if (Cfg.bool(this, "huntAuto", true) && SystemClock.uptimeMillis() >= nextOpenAt && openBest())
            nextOpenAt = SystemClock.uptimeMillis() + rnd(1100, 1700)
        return true
    }

    /** Экран итогов (победа или поражение): находим кнопку «Закрыть», жмём и продолжаем игру. */
    private fun closeCheck(bmp: Bitmap): Boolean {
        val t = TplStore.load(this, "huntClose") ?: return false
        val now = SystemClock.uptimeMillis()
        if ((!huntScene && now > closeWatchUntil) || now < nextCloseAt) return false
        val m = Vision.matchTpl(bmp, Area(0f, 0f, 1f, 1f), t, Cfg.int(this, "tplThr", 28))
            .firstOrNull { blocked(it.cx, it.cy) == null } ?: return false
        tapPx(m.cx, m.cy, jit = 6)
        nextCloseAt = SystemClock.uptimeMillis() + 1500
        closeWatchUntil = 0
        huntStatus = "Итоги охоты закрыты, продолжаю игру"
        if (huntScene) endHunt(true)
        return true
    }

    private fun endHunt(heuristic: Boolean) {
        synchronized(session) { if (!huntSuppressed) finishHuntLocked(heuristic); session.clear() }
        huntScene = false; huntSuppressed = false; huntMiss = 0
        huntStatus = "Охота завершена, результат записан в память"
        closeWatchUntil = SystemClock.uptimeMillis() + 12000   // «Закрыть» может появиться чуть позже
        ui.post { onHuntEnd() }
    }

    /** Сундук с минимальным шансом мимика (при равных — случайный). */
    private fun openBest(): Boolean {
        val now = SystemClock.uptimeMillis()
        val cand = synchronized(session) {
            session.filter { it.state == 0 && now - it.tapAt > 3500 && blocked(it.x * sw(), it.y * sh()) == null }
        }
        if (cand.isEmpty()) return false
        val minP = cand.minOf { it.p }
        // при равных шансах начинаем слева (колонка за колонкой), в колонке — сверху вниз
        val tie = cand.filter { it.p <= minP * 1.15f + 0.003f }
        val s = tie.minWithOrNull(compareBy<Slot>({ (it.x / 0.03f).toInt() }, { it.y }))!!
        s.tapAt = now
        tapPx(s.x * sw(), s.y * sh(), jit = 10)
        return true
    }

    private fun runScan() {
        if (huntBusy) return
        huntBusy = true
        thread { try { scanManual() } catch (t: Throwable) { CrashLog.save(this, t) } finally { huntBusy = false } }
    }

    private fun scanManual() {
        val tpl = TplStore.load(this, "chest")
        if (tpl == null) { status("Сначала задай образец сундука"); return }
        val b = shot() ?: run { status("Снимок экрана не получился"); return }
        val dets = chestMatches(b, tpl)
        if (dets.size < 3) { b.recycle(); status("Найдено сундуков: ${dets.size}. Нужен образец на экране охоты"); return }
        updateSession(dets, b)
        b.recycle()
        status("Проверка: найдено сундуков — ${dets.size}")
    }

    private fun openBestOnce() {
        if (huntBusy) return
        huntBusy = true
        thread {
            try {
                if (synchronized(session) { session.none { it.state == 0 } }) scanManual()
                if (!openBest()) status("Нет доступных сундуков")
                else status("Открываю сундук…")
            } catch (t: Throwable) { CrashLog.save(this, t) } finally { huntBusy = false }
        }
    }

    /** Ручная правка исхода последнего открытого сундука; заодно это обучает распознавание. */
    private fun fixLast(toMimic: Boolean) {
        val s = lastOpened ?: run { toast("Пока нет открытых сундуков"); return }
        synchronized(session) {
            if (toMimic && s.state != 2) {
                if (s.state == 1) HuntMem.fix(this, s.x, s.y, true) else if (s.state == 3) HuntMem.record(this, s.x, s.y, true)
                s.state = 2; mimicsLeft = maxOf(0, mimicsLeft - 1)
                s.sig?.let { HuntMem.addSig(this, true, it) }
            } else if (!toMimic && s.state == 2) {
                HuntMem.fix(this, s.x, s.y, false)
                s.state = 1; mimicsLeft = minOf(4, mimicsLeft + 1); s.learned = true
                s.sig?.let { HuntMem.addSig(this, false, it) }
            }
            HuntMem.compute(session.filter { it.state == 0 }, mimicsLeft)
        }
        refreshHuntUi()
    }

    // ───────── ввод и экран ─────────
    private fun rnd(a: Int, b: Int) = Random.nextLong(a.toLong(), b.toLong())
    private fun sw() = if (lastW > 0) lastW else resources.displayMetrics.widthPixels
    private fun sh() = if (lastH > 0) lastH else resources.displayMetrics.heightPixels

    private fun send(g: GestureDescription, waitMs: Long) {
        val latch = CountDownLatch(1)
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        latch.await(waitMs + 1500, TimeUnit.MILLISECONDS)
    }

    private fun stroke(x: Float, y: Float, start: Long, hold: Long, jit: Int): GestureDescription.StrokeDescription {
        val px = (x + Random.nextInt(-jit, jit + 1)).coerceIn(1f, sw() - 1f)
        val py = (y + Random.nextInt(-jit, jit + 1)).coerceIn(1f, sh() - 1f)
        return GestureDescription.StrokeDescription(Path().apply { moveTo(px, py) }, start, hold)
    }

    private fun tapPx(x: Float, y: Float, hold: Long = rnd(35, 90), jit: Int = 9) {
        send(GestureDescription.Builder().addStroke(stroke(x, y, 0, hold, jit)).build(), hold)
    }

    /** Серия тапов ОДНИМ жестом: интервалы точные и не зависят от задержек Android. */
    private fun burst(x: Float, y: Float, taps: Int, gapMs: Int, hold0: Long) {
        val n = minOf(taps.coerceIn(1, 8), GestureDescription.getMaxStrokeCount())
        val g = GestureDescription.Builder()
        var t = 0L
        for (i in 0 until n) {
            val hold = hold0 + rnd(0, 8)
            g.addStroke(stroke(x, y, t, hold, 8))
            t += hold + (gapMs * Random.nextDouble(0.9, 1.1)).toLong().coerceAtLeast(5L)
        }
        send(g.build(), t)
    }

    private fun jumpPoint(): Pair<Float, Float> {
        val p = Cal.get(this, "jump")
        return safePt(p.x * sw(), p.y * sh())
    }

    private fun jumpTap(hold: Long) { val (x, y) = jumpPoint(); tapPx(x, y, hold) }

    private fun jumpCycle() {
        val (x, y) = jumpPoint()
        burst(x, y, Cfg.int(this, "taps", 3), Cfg.int(this, "tapMs", 140), Cfg.int(this, "tapHold", 30).toLong())
    }

    // ───────── монеты: по форме и размеру, а не только по цвету ─────────
    /** Монета — маленькое примерно круглое пятно. Крупные и вытянутые объекты (мимики, сундуки) отбрасываются. */
    private fun coinHits(b: Bitmap): List<Pair<Float, Float>> {
        val c = Cal.get(this, "coin")
        val maxS = Cfg.int(this, "coinMax", 110)
        return Vision.components(b, Cal.COIN_AREA, c.color, Cal.TOL, 3, 6).filter {
            val w = it.w; val h = it.h
            w in 10..maxS && h in 10..maxS && w.toFloat() / h in 0.6f..1.7f &&
                it.n * 16f / (w * h) >= 0.40f && blocked(it.cx, it.cy) == null
        }.map { Pair(it.cx, it.cy) }
    }

    // ───────── кнопка ускорения в игре ─────────
    private fun boostPt(): Pair<Float, Float>? {
        if (!Cal.isSet(this, "boost")) return null
        val p = Cal.get(this, "boost")
        val x = p.x * sw(); val y = p.y * sh()
        return if (blocked(x, y) != null) null else Pair(x, y)
    }

    private fun boostReady(): Boolean {
        if (boostPt() == null) return false
        val p = Cal.get(this, "boost")
        if (!Cfg.bool(this, "bCol", false) || p.color == 0) return true
        val b = shot() ?: return false
        val ok = Vision.has(b, p)
        b.recycle()
        return ok
    }

    private fun scheduleBoost(now: Long) {
        nextBoost = now + (Cfg.int(this, "bInt", 5) * 1000L * Random.nextDouble(0.95, 1.05)).toLong()
    }

    // ───────── ULTIMA: прыжки + монеты + ускорение одним потоком жестов ─────────
    private fun ultimaStep(bmp: Bitmap?) {
        if (bmp != null) coinTargets = coinHits(bmp)
        val hold = Cfg.int(this, "uHold", 20).toLong()
        val gap = Cfg.int(this, "uGap", 8).toLong()
        val (x, y) = jumpPoint()
        val maxS = minOf(GestureDescription.getMaxStrokeCount(), 10)
        val g = GestureDescription.Builder()
        var t = 0L
        var n = 0
        val now = SystemClock.uptimeMillis()
        if (now >= nextBoost) {
            if (boostReady()) {
                boostPt()?.let { g.addStroke(stroke(it.first, it.second, t, 45, 6)); t += 45 + gap; n++ }
                scheduleBoost(now)
            } else nextBoost = now + 600
        }
        val coins = coinTargets
        coinTargets = emptyList()
        for ((cx, cy) in coins.take(3)) {
            if (n >= maxS - 2) break
            g.addStroke(stroke(cx, cy, t, hold, 8)); t += hold + gap; n++
        }
        while (n < maxS) { g.addStroke(stroke(x, y, t, hold, 6)); t += hold + gap; n++ }
        send(g.build(), t)
    }

    // ───────── скриншоты ─────────
    @Synchronized
    private fun shot(): Bitmap? {
        val wait = 360 - (SystemClock.uptimeMillis() - lastShot)
        if (wait > 0) Thread.sleep(wait)
        lastShot = SystemClock.uptimeMillis()
        val latch = CountDownLatch(1)
        var out: Bitmap? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                out = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                latch.countDown()
            }
            override fun onFailure(errorCode: Int) { latch.countDown() }
        })
        latch.await(2, TimeUnit.SECONDS)
        out?.let { lastW = it.width; lastH = it.height }
        return out
    }

    private fun shotAsync() {
        val now = SystemClock.uptimeMillis()
        if (asyncBusy && now - asyncStart < 3000) return
        asyncBusy = true; asyncStart = now; lastShot = now
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                val bm = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                if (bm != null) { lastW = bm.width; lastH = bm.height }
                asyncBmp = bm
                asyncBusy = false
            }
            override fun onFailure(errorCode: Int) { asyncBusy = false }
        })
    }

    // ───────── бонус-уровень ─────────
    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long) {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        send(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build(), dur)
    }

    /**
     * Бонус-уровень (фиолетовый портал, платформер, 30 с на секцию): на старте бот проводит пальцем слева направо,
     * дальше ищет голубые сферы и прыгает так, чтобы до них дотянуться: момент — по расстоянию до сферы,
     * удержание — по её высоте. Точной «идеальной» таблицы таймингов в открытых источниках нет,
     * поэтому все величины настраиваются ползунками. true — бонус-уровень на экране.
     */
    private fun bonusTick(bmp: Bitmap): Boolean {
        val t = TplStore.load(this, "bonusMark") ?: return false
        val found = Vision.matchTpl(bmp, Area(0f, 0f, 1f, 1f), t, Cfg.int(this, "tplThr", 28)).isNotEmpty()
        val now = SystemClock.uptimeMillis()
        if (!found) {
            if (bonusScene && ++bonusMiss >= 6) { bonusScene = false; bonusSwiped = false; ui.post { toast("Бонус-уровень закончен") } }
            return bonusScene
        }
        bonusMiss = 0
        if (!bonusScene) {
            bonusScene = true; bonusSwiped = false; bonusStart = now; lastBonusJump = now
            ui.post { toast("Бонус-уровень: стартую") }
        }
        val W = bmp.width.toFloat(); val H = bmp.height.toFloat()
        val jp = Cal.get(this, "jump")
        if (!bonusSwiped) {
            if (now - bonusStart < Cfg.int(this, "bDelay", 900)) return true
            if (Cfg.bool(this, "bSwipe", true)) swipe(W * 0.15f, jp.y * H, W * 0.75f, jp.y * H, Cfg.int(this, "bSwipeMs", 380).toLong())
            bonusSwiped = true; lastBonusJump = SystemClock.uptimeMillis()
            return true
        }
        val orb = Cal.get(this, "orb")
        val pl = Cal.get(this, "player")
        if (orb.color != 0 && now - lastBonusJump >= Cfg.int(this, "bCd", 450)) {
            val lead = Cfg.int(this, "bLead", 12) / 100f * W
            val px = pl.x * W; val py = pl.y * H
            val target = Vision.components(bmp, Area(0.05f, 0.12f, 0.97f, 0.92f), orb.color, Cal.TOL, 2, 4)
                .filter { it.w in 8..110 && it.h in 8..110 && blocked(it.cx, it.cy) == null && it.cx > px && it.cx - px < lead * 2.5f }
                .minByOrNull { abs((it.cx - px) - lead) }
            if (target != null && abs((target.cx - px) - lead) < lead * 0.6f) {
                val dy = (py - target.cy) / H            // > 0 — сфера выше персонажа
                if (dy > 0.05f) {
                    val hold = (Cfg.int(this, "bMinHold", 90) + dy * Cfg.int(this, "bGain", 700)).toLong().coerceIn(40L, 1200L)
                    jumpTap(hold); lastBonusJump = SystemClock.uptimeMillis()
                    return true
                }
            }
        }
        val per = Cfg.int(this, "bPer", 1300)
        if (per > 0 && now - lastBonusJump >= per) { jumpTap(rnd(90, 160)); lastBonusJump = SystemClock.uptimeMillis() }
        return true
    }

    // ───────── основной цикл бота ─────────
    private fun loop() {
        var lastBeat = 0L
        var lastPoll = 0L
        while (alive) {
            try {
                val wall = System.currentTimeMillis()
                if (wall - lastPoll > 500) {
                    lastPoll = wall
                    rootInActiveWindow?.packageName?.let { setInGame(it.toString() == Cal.GAME_PKG) }
                }
                if (wall - lastBeat > 1000) {
                    lastBeat = wall
                    val m = mods.filter { on[it.key] == true }.values.toMutableList()
                    if (on["ultima"] == true) m.add(0, "ULTIMA")
                    if (huntScene) m.add("Охота")
                    Status.beat(this, inGame, m.joinToString(", "))
                }
                if (!inGame && huntScene) endHunt(false)   // вышли из игры посреди охоты
                val ultima = on["ultima"] == true
                if (calIdx >= 0 || !inGame || (!ultima && mods.keys.none { on[it] == true })) { Thread.sleep(300); continue }
                if (fingerDown || SystemClock.uptimeMillis() - userTouch < 700) { Thread.sleep(15); continue }

                val chestWatch = Cfg.bool(this, "autoHunt", true) && TplStore.has(this, "chest")
                val bonusWatch = (on["bonus"] == true || ultima) && TplStore.has(this, "bonusMark")
                val needVision = ultima || on["coin"] == true || on["pandora"] == true || chestWatch || bonusWatch
                var bmp: Bitmap? = null
                if (needVision) {
                    bmp = asyncBmp
                    if (bmp != null) asyncBmp = null
                    else if (SystemClock.uptimeMillis() - lastShot > 380) shotAsync()
                }
                if (bmp != null && huntTick(bmp)) { bmp.recycle(); Thread.sleep(30); continue }
                if (huntScene) { bmp?.recycle(); Thread.sleep(30); continue }
                if (bonusWatch && bmp != null && bonusTick(bmp)) { bmp.recycle(); Thread.sleep(20); continue }
                if (bonusScene) { bmp?.recycle(); Thread.sleep(15); continue }

                if (ultima) { ultimaStep(bmp); bmp?.recycle(); continue }

                val now = SystemClock.uptimeMillis()
                if (on["boost"] == true && now >= nextBoost) {
                    if (boostReady()) {
                        boostPt()?.let { tapPx(it.first, it.second, rnd(40, 80), 6) }
                        scheduleBoost(SystemClock.uptimeMillis())
                    } else nextBoost = now + 600
                }
                if (on["jump"] == true && SystemClock.uptimeMillis() >= nextJump) {
                    jumpCycle()
                    val p = Cfg.int(this, "pause", 700)
                    var d = if (p >= 100) (p * Random.nextDouble(0.9, 1.1)).toLong() else p.toLong()
                    if (p >= 300 && Random.nextInt(100) < 2) d += rnd(1500, 4000)
                    nextJump = SystemClock.uptimeMillis() + d
                }
                if (bmp != null) {
                    if (!(on["pandora"] == true && pandora(bmp)) && on["coin"] == true) coins(bmp)
                    bmp.recycle()
                }
                Thread.sleep(2)
            } catch (e: InterruptedException) {
                return
            } catch (e: Throwable) {
                CrashLog.save(this, e)
                Thread.sleep(1000)
            }
        }
    }

    private fun pandora(b: Bitmap): Boolean {
        if (SystemClock.uptimeMillis() < pandoraUntil) return false
        val pl = Cal.get(this, "player")
        val dist = Cfg.int(this, "pDist", 12) / 100f
        val area = Area((pl.x - 0.02f).coerceAtLeast(0f), 0.03f, (pl.x + dist).coerceAtMost(0.99f), pl.y.coerceAtLeast(0.2f))
        for (key in listOf("pandora", "pandoraP")) {      // обычный и фиолетовый (вход в бонус-уровень) ящики
            val c = Cal.get(this, key)
            if (c.color == 0 || Vision.find(b, area, c.color, Cal.TOL, 10).isEmpty()) continue
            val ms = if (Cfg.bool(this, "pUp", false)) 2000L else 500L
            jumpTap((ms * Random.nextDouble(0.96, 1.04)).toLong())
            val now = SystemClock.uptimeMillis()
            pandoraUntil = now + 700
            nextJump = now + 500
            return true
        }
        return false
    }

    private fun coins(b: Bitmap) {
        for ((x, y) in coinHits(b).shuffled().take(2)) { tapPx(x, y); Thread.sleep(rnd(40, 100)) }
    }
}
