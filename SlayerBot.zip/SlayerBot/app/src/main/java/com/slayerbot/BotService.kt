package com.slayerbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.random.Random

class BotService : AccessibilityService() {
    private class Step(val key: String, val label: String, val def: Int, val min: Int,
                       val max: Int, val step: Int, val unit: String)

    private val stepsJ = listOf(
        Step("taps", "Тапов за прыжок", 3, 1, 8, 1, ""),
        Step("tapHold", "Длительность тапа", 30, 10, 100, 5, " мс"),
        Step("tapMs", "Интервал тапов", 140, 5, 600, 5, " мс"),
        Step("pause", "Пауза между прыжками", 700, 0, 3000, 10, " мс")
    )
    private val stepsB = listOf(Step("bInt", "Нажимать ускорение раз в", 5, 1, 120, 1, " с"))
    private val stepsU = listOf(
        Step("uHold", "Длительность тапа", 20, 10, 100, 5, " мс"),
        Step("uGap", "Интервал тапов", 8, 0, 200, 2, " мс")
    )
    private val stepsP = listOf(Step("pDist", "Дистанция до ящика", 12, 3, 40, 1, " %"))
    private val stepsM = listOf(
        Step("menuScale", "Размер меню", 100, 60, 200, 10, " %"),
        Step("menuAlpha", "Прозрачность меню", 85, 30, 100, 5, " %")
    )
    private val mods = linkedMapOf("jump" to "Прыжки", "coin" to "Монеты", "pandora" to "Пандора", "boost" to "Ускорение")

    private val on = ConcurrentHashMap<String, Boolean>()
    private val btns = HashMap<String, Button>()
    private val labelOf = HashMap<String, String>()
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val rects = ConcurrentHashMap<String, Rect>()   // места наших окон — туда бот не тапает

    private var menu: View? = null
    private var menuX = 0
    private var menuY = 0
    private var menuExpanded = true
    private var settingsView: View? = null
    private var panel: LinearLayout? = null
    private var panelTxt: TextView? = null
    private var capView: View? = null
    private var frozen: Bitmap? = null

    private var huntPanel: View? = null
    private var huntInfo: TextView? = null
    private var markView: MarkView? = null
    private val session = ArrayList<Slot>()
    @Volatile private var mimicsLeft = 4
    @Volatile private var lastOpened: Slot? = null
    @Volatile private var markShown = true
    @Volatile private var huntBusy = false
    @Volatile private var huntScene = false
    @Volatile private var huntMiss = 0
    @Volatile private var nextOpenAt = 0L
    @Volatile private var huntStatus = "Охота не обнаружена"

    @Volatile private var fingerDown = false
    @Volatile private var userTouch = 0L
    @Volatile private var calIdx = -1
    @Volatile private var calBusy = false
    @Volatile private var alive = true
    @Volatile private var inGame = false
    @Volatile private var nextJump = 0L
    @Volatile private var pandoraUntil = 0L
    @Volatile private var nextBoost = 0L
    @Volatile private var asyncBmp: Bitmap? = null
    @Volatile private var asyncBusy = false
    @Volatile private var asyncStart = 0L
    @Volatile private var coinTargets: List<Pair<Float, Float>> = emptyList()
    @Volatile private var lastW = 0
    @Volatile private var lastH = 0
    private var lastShot = 0L

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            "menuTheme", "menuAlpha", "menuScale", "neon" -> ui.post { buildMenu() }
            "menuHidden" -> ui.post { applyVisibility() }
        }
    }

    // ───────── жизненный цикл ─────────
    override fun onServiceConnected() {
        CrashLog.install(this)
        HuntMem.load(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        menuX = dp(4); menuY = dp(12)
        getSharedPreferences("set", MODE_PRIVATE).registerOnSharedPreferenceChangeListener(prefListener)
        buildMenu()
        thread(isDaemon = true) { loop() }
    }

    /** Быстро ловим переход в игру / из игры (поверх этого цикл раз в 0,5 с сверяет активное окно). */
    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        setInGame(pkg == Cal.GAME_PKG)
    }

    private fun setInGame(v: Boolean) {
        if (inGame != v) { inGame = v; ui.post { applyVisibility() } }
    }

    /** Громкость вниз — аварийный СТОП, громкость вверх — показать/скрыть меню. */
    override fun onKeyEvent(event: KeyEvent): Boolean {
        val k = event.keyCode
        if (k != KeyEvent.KEYCODE_VOLUME_DOWN && k != KeyEvent.KEYCODE_VOLUME_UP) return false
        if (event.action == KeyEvent.ACTION_DOWN) ui.post {
            if (k == KeyEvent.KEYCODE_VOLUME_DOWN) {
                for (m in mods.keys) on[m] = false
                on["ultima"] = false
                paint(); toast("СТОП: все режимы выключены")
            } else setHidden(!Cfg.bool(this, "menuHidden", false))
        }
        return true
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        alive = false
        getSharedPreferences("set", MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(prefListener)
        for (v in listOf(menu, settingsView, huntPanel, markView, panel)) v?.let { runCatching { wm.removeView(it) } }
        closeCapture()
        super.onDestroy()
    }

    // ───────── общие помощники ─────────
    private fun dp(v: Int) = Ui.dp(this, v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun row() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) }
    private fun text(s: String, size: Float = 13f, color: Int = Ui.CREAM) = Ui.text(this, s, size, color)

    private fun pal() = Ui.pal(this, true)
    private fun neon() = Ui.neonOn(this)
    private fun sc() = Cfg.int(this, "menuScale", 100) / 100f
    private fun md(v: Int) = (dp(v) * sc()).toInt()
    private fun panelFill() = Ui.alpha(pal().panel, Cfg.int(this, "menuAlpha", 85) * 255 / 100)

    private fun touchCb(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { fingerDown = true; userTouch = SystemClock.uptimeMillis() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { fingerDown = false; userTouch = SystemClock.uptimeMillis() }
        }
    }

    /** kind: 0 обычная, 1 главная/включённая, 2 осторожная. */
    private fun mkBtn(label: String, size: Float = 14f, kind: Int = 0, click: () -> Unit): Button {
        val p = pal()
        return Button(this).apply {
            text = label; textSize = size; isAllCaps = false; typeface = Ui.font
            setTextColor(if (kind == 1) p.accent else Ui.CREAM)
            minHeight = dp(40); minimumHeight = dp(40)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            background = Ui.btnBg(this@BotService, p, neon(), kind)
            setOnClickListener {
                CrashLog.note(this@BotService, "click: $label")
                try { click() } catch (t: Throwable) {
                    CrashLog.save(this@BotService, t); toast("Ошибка: $t")
                }
            }
        }
    }

    private fun small(t: String, c: () -> Unit) = mkBtn(t, 18f, 0, c).apply {
        gravity = Gravity.CENTER; minWidth = dp(46); minimumWidth = dp(46); setPadding(0, 0, 0, 0)
    }

    private fun pair(a: View, b: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(3) })
        addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(3) })
    }

    private fun panelBox() = WatchLinear(this) { touchCb(it) }.apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.bg(this@BotService, panelFill(), pal().edge, neon())
        setPadding(dp(12), dp(10), dp(12), dp(12))
    }

    private fun wlp(w: Int, h: Int, full: Boolean) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            (if (full) WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS else 0),
        PixelFormat.TRANSLUCENT
    ).apply {
        if (full) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(8) }
    }

    private fun panelLp(x: Int, y: Int, w: Int) = WindowManager.LayoutParams(
        w, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun markLp() = WindowManager.LayoutParams(
        -1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS }

    private fun refreshRect(v: View, key: String) {
        val loc = IntArray(2); v.getLocationOnScreen(loc)
        rects[key] = Rect(loc[0], loc[1], loc[0] + v.width, loc[1] + v.height)
    }

    private fun track(v: View, key: String) {
        v.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> if (v.visibility == View.VISIBLE) refreshRect(v, key) }
    }

    private fun untrack(key: String) { rects.remove(key) }

    private fun blocked(x: Float, y: Float): Rect? {
        val m = dp(14)
        for (r in rects.values) if (x >= r.left - m && x <= r.right + m && y >= r.top - m && y <= r.bottom + m) return r
        return null
    }

    private fun safePt(px: Float, py: Float): Pair<Float, Float> {
        var x = px
        repeat(4) { val r = blocked(x, py) ?: return Pair(x, py); x = r.right + dp(30).toFloat() }
        return Pair(x.coerceAtMost(sw() - 2f), py)
    }

    private fun drag(handle: View, win: View, lp: WindowManager.LayoutParams, key: String,
                     onMove: ((Int, Int) -> Unit)? = null, onClick: (() -> Unit)? = null) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) + abs(dy) > 12) moved = true
                    lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt()
                    wm.updateViewLayout(win, lp)
                    onMove?.invoke(lp.x, lp.y)
                    win.postDelayed({ refreshRect(win, key) }, 120)
                }
                MotionEvent.ACTION_UP -> if (!moved) onClick?.invoke()
            }
            true
        }
    }

    /** Меню и окна видны только когда на экране игра (и меню не скрыто вручную). */
    private fun applyVisibility() {
        val show = inGame && !Cfg.bool(this, "menuHidden", false)
        val vis = if (show) View.VISIBLE else View.GONE
        val all = mapOf("menu" to menu, "set" to settingsView, "hunt" to huntPanel, "cal" to panel)
        for ((k, v) in all) {
            v?.visibility = vis
            if (!show) untrack(k) else v?.let { vv -> vv.postDelayed({ refreshRect(vv, k) }, 150) }
        }
        markView?.visibility = if (inGame && markShown) View.VISIBLE else View.INVISIBLE
    }

    // ───────── плавающее меню ─────────
    private fun menuBtn(label: String, kind: Int = 0, click: () -> Unit) =
        mkBtn(label, 12f * sc(), kind, click).apply {
            minHeight = md(36); minimumHeight = md(36); setPadding(md(6), md(2), md(6), md(2)); gravity = Gravity.CENTER
        }

    private fun sizeBtn(t: String, d: Int) = mkBtn(t, 14f * sc(), 0) {
        Cfg.setInt(this, "menuScale", (Cfg.int(this, "menuScale", 100) + d).coerceIn(60, 200))
    }.apply { minWidth = md(30); minimumWidth = md(30); minHeight = md(30); minimumHeight = md(30); setPadding(0, 0, 0, 0); gravity = Gravity.CENTER }

    private fun buildMenu() {
        menu?.let { runCatching { wm.removeView(it) } }
        untrack("menu"); btns.clear(); labelOf.clear()
        val p = pal()
        val box = WatchLinear(this) { touchCb(it) }.apply { orientation = LinearLayout.VERTICAL; setPadding(md(6), md(4), md(6), md(6)) }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val extras = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val lp = panelLp(menuX, menuY, md(230))

        fun restyle() {
            body.visibility = if (menuExpanded) View.VISIBLE else View.GONE
            extras.visibility = body.visibility
            box.background = if (menuExpanded) Ui.bg(this, panelFill(), p.edge, neon()) else null
            lp.width = if (menuExpanded) md(230) else WindowManager.LayoutParams.WRAP_CONTENT
        }
        restyle()

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(PortalView(this).apply { frame = p.accent }, LinearLayout.LayoutParams(md(44), md(44)))
        extras.addView(text("IDLE ULTIMA", 11f * sc(), Ui.MUTED).apply { letterSpacing = 0.12f; setPadding(md(10), 0, md(4), 0) },
            LinearLayout.LayoutParams(0, -2, 1f))
        extras.addView(sizeBtn("−", -10)); extras.addView(sizeBtn("+", 10))
        head.addView(extras, LinearLayout.LayoutParams(0, -2, 1f))
        drag(head, box, lp, "menu", onMove = { x, y -> menuX = x; menuY = y }, onClick = {
            menuExpanded = !menuExpanded
            restyle(); wm.updateViewLayout(box, lp)
            box.postDelayed({ refreshRect(box, "menu") }, 120)
        })
        box.addView(head); box.addView(body)

        fun reg(k: String, label: String): Button {
            val b = menuBtn(label) { setOn(k, on[k] != true); paint() }
            btns[k] = b; labelOf[k] = label
            return b
        }
        body.addView(reg("ultima", "ULTIMA"), row())
        body.addView(pair(reg("jump", mods["jump"]!!), reg("coin", mods["coin"]!!)), row())
        body.addView(pair(reg("pandora", mods["pandora"]!!), reg("boost", mods["boost"]!!)), row())
        body.addView(pair(menuBtn("Охота") { openHunt() }, menuBtn("Настройки") { openSettings() }), row())
        body.addView(menuBtn("Скрыть меню") { setHidden(true); toast("Меню скрыто. Показать: громкость + или кнопка в приложении") }, row())
        body.addView(text("Громкость −: стоп   +: меню", 9f * sc(), Ui.MUTED).apply { gravity = Gravity.CENTER }, row())
        wm.addView(box, lp)
        menu = box; track(box, "menu")
        paint()
        applyVisibility()
    }

    private fun setHidden(v: Boolean) { Cfg.setBool(this, "menuHidden", v); applyVisibility() }

    /** ULTIMA и остальные режимы взаимоисключающие: оба шлют жесты и перебивали бы друг друга. */
    private fun setOn(k: String, v: Boolean) {
        if (v) {
            if (k == "ultima") mods.keys.forEach { on[it] = false } else on["ultima"] = false
            if ((k == "boost" || k == "ultima") && !Cal.isSet(this, "boost"))
                toast("Ускорение: откалибруй кнопку в игре (Настройки → Калибровка)")
            if (k == "pandora" && Cal.get(this, "pandora").color == 0)
                toast("Пандора: откалибруй цвет ящика (Настройки → Калибровка)")
            if (Cfg.bool(this, "autoHunt", true) && Cal.get(this, "chest").color == 0)
                toast("Авто-охота выключена: откалибруй цвет сундука")
        }
        on[k] = v
    }

    private fun paint() {
        val p = pal()
        for ((k, b) in btns) {
            val a = on[k] == true
            b.background = Ui.btnBg(this, p, neon(), if (a) 1 else 0)
            b.setTextColor(if (a) p.accent else Ui.CREAM)
            val base = labelOf[k] ?: ""
            b.text = if (k == "ultima") (if (a) "ULTIMA  ·  СТОП" else "ULTIMA") else (if (a) "●  $base" else "○  $base")
        }
    }

    // ───────── настройки ─────────
    private fun stepperRow(st: Step): View {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val name = text(st.label, 13f, Ui.CREAM)
        val value = text("", 14f, pal().accent).apply { gravity = Gravity.CENTER; minWidth = dp(76) }
        fun upd() { value.text = "${Cfg.int(this, st.key, st.def)}${st.unit}" }
        fun chg(d: Int) {
            Cfg.setInt(this, st.key, (Cfg.int(this, st.key, st.def) + d).coerceIn(st.min, st.max)); upd()
        }
        upd()
        r.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(small("−") { chg(-st.step) })
        r.addView(value)
        r.addView(small("+") { chg(st.step) })
        return r
    }

    private fun toggleBtn(key: String, def: Boolean, onText: String, offText: String): Button {
        var b: Button? = null
        fun t() = if (Cfg.bool(this, key, def)) onText else offText
        b = mkBtn(t(), 13f) { Cfg.setBool(this, key, !Cfg.bool(this, key, def)); b?.text = t() }
        return b!!
    }

    private fun openSettings() {
        if (settingsView != null) { closeSettings(); return }
        val col = panelBox()
        col.addView(text("НАСТРОЙКИ", 14f, pal().accent))
        fun section(t: String) = col.addView(text(t, 11f, Ui.MUTED), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        section("ПРЫЖКИ И ЛУК")
        for (st in stepsJ) col.addView(stepperRow(st), row())
        section("УСКОРЕНИЕ (КНОПКА В ИГРЕ)")
        for (st in stepsB) col.addView(stepperRow(st), row())
        col.addView(toggleBtn("bCol", false, "Жать, только когда кнопка готова (по цвету)", "Жать по таймеру (без проверки цвета)"), row())
        section("ULTIMA — МИНИМАЛЬНЫЙ ИНТЕРВАЛ")
        for (st in stepsU) col.addView(stepperRow(st), row())
        section("ПАНДОРА")
        for (st in stepsP) col.addView(stepperRow(st), row())
        col.addView(toggleBtn("pUp", false, "Ящик: с прокачкой (тап 2 с)", "Ящик: обычный (тап 0,5 с)"), row())
        section("ОХОТА ЗА СУНДУКАМИ")
        col.addView(toggleBtn("autoHunt", true, "Авто-охота при ключе: вкл", "Авто-охота при ключе: выкл"), row())
        section("ВИД МЕНЮ")
        for (st in stepsM) col.addView(stepperRow(st), row())
        col.addView(toggleBtn("neon", false, "Подсветка рамок: вкл", "Подсветка рамок: выкл"), row())
        col.addView(mkBtn("Калибровка точек и цветов", 13f, 1) { closeSettings(); startCal() }, row())
        col.addView(mkBtn("Закрыть", 13f) { closeSettings() }, row())
        val sv = WatchScroll(this) { touchCb(it) }.apply { addView(col) }
        settingsView = sv
        wm.addView(sv, panelLp(dp(240), dp(8), dp(390)))
        track(sv, "set")
    }

    private fun closeSettings() {
        settingsView?.let { runCatching { wm.removeView(it) } }
        settingsView = null; untrack("set")
    }

    // ───────── калибровка: снимок экрана → тап по снимку ─────────
    private fun startCal() {
        if (panel != null) { toast("Калибровка уже идёт"); return }
        calIdx = 0
        val p = panelBox()
        val t = text("", 13f)
        p.addView(t)
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val m = { LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6); topMargin = dp(8) } }
        r.addView(mkBtn("Выбрать точку", 13f, 1) { beginPick() }, m())
        r.addView(mkBtn("Пропуск", 13f) { nextCal() }, m())
        r.addView(mkBtn("Выход", 13f) { stopCal() }, m())
        p.addView(r)
        panel = p; panelTxt = t
        wm.addView(p, wlp(-2, -2, false))
        track(p, "cal")
        showHint()
    }

    private fun showHint() {
        val it = Cal.items[calIdx]
        panelTxt?.text = "(${calIdx + 1}/${Cal.items.size}) ${it.hint}\nОткрой в игре нужный экран → «Выбрать точку»"
    }

    private fun nextCal() {
        closeCapture()
        calIdx++
        if (calIdx >= Cal.items.size) stopCal() else showHint()
    }

    private fun beginPick() {
        if (capView != null) { closeCapture(); showHint(); return }
        if (calBusy) return
        calBusy = true
        panel?.visibility = View.INVISIBLE
        menu?.visibility = View.INVISIBLE
        thread {
            Thread.sleep(250)
            val b = shot()
            ui.post {
                panel?.visibility = View.VISIBLE
                menu?.visibility = View.VISIBLE
                calBusy = false
                if (b == null) toast("Снимок экрана не получился, попробуй ещё раз") else showCapture(b)
            }
        }
    }

    private fun showCapture(b: Bitmap) {
        frozen = b
        val iv = ImageView(this).apply { setImageBitmap(b); scaleType = ImageView.ScaleType.FIT_XY }
        iv.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP && calIdx >= 0) {
                val fx = (e.x / v.width).coerceIn(0f, 1f)
                val fy = (e.y / v.height).coerceIn(0f, 1f)
                val item = Cal.items[calIdx]
                val col = if (item.needColor) b.getPixel((fx * (b.width - 1)).toInt(), (fy * (b.height - 1)).toInt()) else 0
                Cal.set(this@BotService, item.key, Pt(fx, fy, col))
                toast("Сохранено")
                nextCal()
            }
            true
        }
        capView = iv
        wm.addView(iv, wlp(-1, -1, true))
        panel?.let { runCatching { wm.removeView(it) }; wm.addView(it, wlp(-2, -2, false)) }
        panelTxt?.text = "Тапни точно по нужному месту на снимке.\n(«Выбрать точку» ещё раз — отмена)"
    }

    private fun closeCapture() {
        capView?.let { runCatching { wm.removeView(it) } }
        capView = null
        frozen?.recycle(); frozen = null
    }

    private fun stopCal() {
        closeCapture()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null; panelTxt = null; calIdx = -1; untrack("cal")
        toast("Калибровка завершена")
    }

    // ───────── охота за сундуками ─────────
    private fun ensureMarks() {
        if (markView == null) markView = MarkView(this).also { wm.addView(it, markLp()) }
        markView?.visibility = if (inGame && markShown) View.VISIBLE else View.INVISIBLE
    }

    private fun removeMarks() {
        markView?.let { runCatching { wm.removeView(it) } }
        markView = null
    }

    private fun openHunt() {
        if (huntPanel != null) { closeHunt(); return }
        closeSettings()
        ensureMarks()
        val col = panelBox()
        val head = text("ОХОТА ЗА СУНДУКАМИ", 13f, pal().accent).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, dp(6)) }
        col.addView(head)
        huntInfo = text("", 12f).also { col.addView(it) }
        col.addView(toggleBtn("autoHunt", true, "Авто-охота при ключе: вкл", "Авто-охота при ключе: выкл"), row())
        col.addView(pair(mkBtn("Скан", 13f) { runScan() }, mkBtn("Цвета: вкл/выкл", 12f) { toggleMarks() }), row())
        col.addView(pair(mkBtn("Открыть лучший", 12f) { openBestOnce() }, mkBtn("Новая охота", 12f) { newHunt() }), row())
        col.addView(pair(mkBtn("Это награда", 13f) { fixLast(false) }, mkBtn("Это мимик", 13f) { fixLast(true) }), row())

        val mr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val mv = text("", 14f, pal().accent).apply { gravity = Gravity.CENTER; minWidth = dp(50) }
        fun upd() { mv.text = "$mimicsLeft" }
        fun chg(d: Int) { mimicsLeft = (mimicsLeft + d).coerceIn(0, 4); upd(); recompute(); refreshHuntUi() }
        upd()
        mr.addView(text("Мимиков осталось", 12f), LinearLayout.LayoutParams(0, -2, 1f))
        mr.addView(small("−") { chg(-1) }); mr.addView(mv); mr.addView(small("+") { chg(1) })
        col.addView(mr, row())

        col.addView(pair(mkBtn("Сброс памяти", 12f, 2) { HuntMem.reset(this); recompute(); refreshHuntUi(); toast("Память охоты очищена") },
            mkBtn("Закрыть", 13f) { closeHunt() }), row())

        val sv = WatchScroll(this) { touchCb(it) }.apply { addView(col) }
        val w = dp(340)
        val lp = panelLp(resources.displayMetrics.widthPixels - w - dp(8), dp(8), w)
        drag(head, sv, lp, "hunt")
        wm.addView(sv, lp)
        huntPanel = sv; track(sv, "hunt")
        applyVisibility()
        refreshHuntUi()
    }

    private fun closeHunt() {
        huntPanel?.let { runCatching { wm.removeView(it) } }
        huntPanel = null; huntInfo = null; untrack("hunt")
        if (!huntScene) removeMarks()
    }

    private fun toggleMarks() {
        markShown = !markShown
        markView?.visibility = if (inGame && markShown) View.VISIBLE else View.INVISIBLE
    }

    private fun recompute() {
        synchronized(session) { HuntMem.compute(session.filter { it.state == 0 }, mimicsLeft) }
    }

    private fun status(s: String) { huntStatus = s; ui.post { refreshHuntUi() } }

    /** Подсветка: красный — шанс выше среднего, зелёный — ниже, жёлтый — как у всех. */
    private fun refreshHuntUi() {
        val W = sw().toFloat(); val H = sh().toFloat()
        val marks = ArrayList<MarkView.Mark>()
        var closedN = 0
        var base = 0f
        var informative = false
        synchronized(session) {
            val closed = session.filter { it.state == 0 }
            closedN = closed.size
            base = if (closedN > 0) (mimicsLeft.toFloat() / closedN).coerceIn(0f, 1f) else 0f
            informative = HuntMem.informative(closed)
            for (s in session) {
                if (s.state == 0) {
                    val ratio = if (base > 0f) s.p / base else 1f
                    val col = when { ratio > 1.25f -> Ui.MK_RED; ratio < 0.8f -> Ui.MK_GREEN; else -> Ui.MK_AMBER }
                    marks.add(MarkView.Mark(s.x * W, s.y * H, s.r * 1.05f, col, "${(s.p * 100).toInt()}%"))
                } else if (s.state == 2) marks.add(MarkView.Mark(s.x * W, s.y * H, s.r * 1.05f, Ui.MK_RED, "мимик"))
            }
        }
        markView?.marks = marks
        markView?.invalidate()
        huntInfo?.text = "$huntStatus\n" +
            "Закрыто: $closedN   Мимиков осталось: $mimicsLeft\n" +
            "Шанс мимика: ${(base * 100).toInt()}%" + (if (informative) " (с учётом статистики)" else " (у всех одинаков)") + "\n" +
            "Память: ${HuntMem.hunts} охот, ${HuntMem.opens()} открытий"
    }

    private fun chestBlobs(b: Bitmap, color: Int): List<Vision.Blob> {
        var blobs = Vision.components(b, Cal.CHEST_AREA, color, Cal.TOL, 6, 14)
        val areas = blobs.map { it.w.toLong() * it.h }.sorted()
        val med = if (areas.isEmpty()) 0L else areas[areas.size / 2]
        blobs = blobs.filter { it.w.toLong() * it.h >= med * 0.35 }
        return blobs.filter { blocked(it.cx, it.cy) == null }
    }

    /** Завершение охоты (вызывать внутри synchronized(session)). */
    private fun finishHuntLocked(heuristic: Boolean) {
        val opened = session.count { it.state != 0 }
        val closed = session.count { it.state == 0 }
        // охота оборвалась при закрытых сундуках → скорее всего последний открытый был мимиком
        if (heuristic && opened > 0 && closed >= 2 && session.none { it.state == 2 }) {
            val s = lastOpened
            if (s != null && s.state == 1 && mimicsLeft > 0) {
                s.state = 2; mimicsLeft--; HuntMem.fix(this, s.x, s.y, true)
            }
        }
        if (opened > 0) { HuntMem.hunts++; HuntMem.save(this) }
    }

    /** Сопоставляет найденные сундуки с полем: исчезнувшие считаются открытыми и пишутся в память. */
    private fun updateSession(blobs: List<Vision.Blob>, mimics: List<Vision.Blob>, W: Float, H: Float) {
        val det = blobs.map { Triple(it.cx / W, it.cy / H, maxOf(it.w, it.h) / 2f) }
        synchronized(session) {
            val still = session.filter { it.state == 0 }
            if (session.isEmpty() || det.size > still.size + 3) {          // новое поле
                if (session.isNotEmpty()) finishHuntLocked(false)
                session.clear(); mimicsLeft = 4; lastOpened = null
                det.forEach { session.add(Slot(it.first, it.second, it.third)) }
            } else {
                for (s in still) {
                    val d = det.minByOrNull { hypot(it.first - s.x, it.second - s.y) }
                    if (d != null && hypot(d.first - s.x, d.second - s.y) < 0.03f) s.r = d.third
                    else {                                                   // сундук открыт
                        val isMimic = mimics.any { hypot(it.cx / W - s.x, it.cy / H - s.y) < 0.08f }
                        s.state = if (isMimic) 2 else 1
                        if (isMimic) mimicsLeft = maxOf(0, mimicsLeft - 1)
                        HuntMem.record(this, s.x, s.y, isMimic)
                        lastOpened = s
                    }
                }
            }
            HuntMem.compute(session.filter { it.state == 0 }, mimicsLeft)
        }
    }

    /**
     * Вызывается циклом бота на каждом новом кадре. true — на экране охота за сундуками:
     * бот сам открывает наименее рискованный сундук, обычные тапы в это время не нужны.
     */
    private fun huntTick(bmp: Bitmap): Boolean {
        val c = Cal.get(this, "chest")
        if (c.color == 0 || !Cfg.bool(this, "autoHunt", true)) return false
        val blobs = chestBlobs(bmp, c.color)
        if (blobs.size < 3 || (!huntScene && blobs.size < 8)) {
            if (huntScene && ++huntMiss >= 4) {
                synchronized(session) { finishHuntLocked(true); session.clear() }
                huntScene = false
                huntStatus = "Охота завершена, результат записан в память"
                ui.post { refreshHuntUi(); if (huntPanel == null) removeMarks() }
            }
            return huntScene
        }
        huntMiss = 0
        if (!huntScene) { huntScene = true; huntStatus = "Идёт охота: открываю сундуки"; ui.post { ensureMarks() } }
        val mc = Cal.get(this, "mimic")
        val mimics = if (mc.color != 0) Vision.components(bmp, Cal.CHEST_AREA, mc.color, Cal.TOL, 4, 14) else emptyList()
        updateSession(blobs, mimics, bmp.width.toFloat(), bmp.height.toFloat())
        ui.post { refreshHuntUi() }
        if (SystemClock.uptimeMillis() >= nextOpenAt && openBest()) nextOpenAt = SystemClock.uptimeMillis() + rnd(1100, 1700)
        return true
    }

    /** Открывает сундук с минимальным шансом мимика (при равных — случайный). */
    private fun openBest(): Boolean {
        val now = SystemClock.uptimeMillis()
        val cand = synchronized(session) {
            session.filter { it.state == 0 && now - it.tapAt > 3500 && blocked(it.x * sw(), it.y * sh()) == null }
        }
        if (cand.isEmpty()) return false
        val minP = cand.minOf { it.p }
        val s = cand.filter { it.p <= minP + 0.005f }.random()
        s.tapAt = now
        tapPx(s.x * sw(), s.y * sh(), jit = 12)
        return true
    }

    private fun runScan() {
        if (huntBusy) return
        huntBusy = true
        thread { try { scanManual() } catch (t: Throwable) { CrashLog.save(this, t) } finally { huntBusy = false } }
    }

    private fun scanManual() {
        val c = Cal.get(this, "chest")
        if (c.color == 0) { status("Сначала откалибруй цвет сундука"); return }
        val b = shot() ?: run { status("Снимок экрана не получился"); return }
        val blobs = chestBlobs(b, c.color)
        val mc = Cal.get(this, "mimic")
        val mimics = if (mc.color != 0) Vision.components(b, Cal.CHEST_AREA, mc.color, Cal.TOL, 4, 14) else emptyList()
        val W = b.width.toFloat(); val H = b.height.toFloat()
        b.recycle()
        if (blobs.size < 3) { status("Сундуки не найдены. Проверь цвет в калибровке"); return }
        updateSession(blobs, mimics, W, H)
        status("Скан: найдено сундуков — ${blobs.size}")
    }

    private fun openBestOnce() {
        if (huntBusy) return
        huntBusy = true
        thread {
            try {
                scanManual()
                if (!openBest()) status("Нет доступных сундуков")
                else { status("Открываю сундук…"); Thread.sleep(rnd(1100, 1600)); scanManual() }
            } catch (t: Throwable) { CrashLog.save(this, t) } finally { huntBusy = false }
        }
    }

    private fun fixLast(toMimic: Boolean) {
        val s = lastOpened ?: run { toast("Пока нет открытых сундуков"); return }
        synchronized(session) {
            if (toMimic && s.state == 1) { s.state = 2; mimicsLeft = maxOf(0, mimicsLeft - 1); HuntMem.fix(this, s.x, s.y, true) }
            else if (!toMimic && s.state == 2) { s.state = 1; mimicsLeft = minOf(4, mimicsLeft + 1); HuntMem.fix(this, s.x, s.y, false) }
            HuntMem.compute(session.filter { it.state == 0 }, mimicsLeft)
        }
        refreshHuntUi()
    }

    private fun newHunt() {
        synchronized(session) { finishHuntLocked(false); session.clear() }
        mimicsLeft = 4; lastOpened = null; huntScene = false
        status("Новая охота: нажми «Скан» или дождись авто-охоты")
    }

    // ───────── ввод и экран ─────────
    private fun rnd(a: Int, b: Int) = Random.nextLong(a.toLong(), b.toLong())
    private fun sw() = if (lastW > 0) lastW else resources.displayMetrics.widthPixels
    private fun sh() = if (lastH > 0) lastH else resources.displayMetrics.heightPixels

    private fun send(g: GestureDescription, waitMs: Long) {
        val latch = CountDownLatch(1)
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        latch.await(waitMs + 1500, TimeUnit.MILLISECONDS)
    }

    private fun stroke(x: Float, y: Float, start: Long, hold: Long, jit: Int): GestureDescription.StrokeDescription {
        val px = (x + Random.nextInt(-jit, jit + 1)).coerceIn(1f, sw() - 1f)
        val py = (y + Random.nextInt(-jit, jit + 1)).coerceIn(1f, sh() - 1f)
        return GestureDescription.StrokeDescription(Path().apply { moveTo(px, py) }, start, hold)
    }

    private fun tapPx(x: Float, y: Float, hold: Long = rnd(35, 90), jit: Int = 9) {
        send(GestureDescription.Builder().addStroke(stroke(x, y, 0, hold, jit)).build(), hold)
    }

    /** Серия тапов ОДНИМ жестом: интервалы точные и не зависят от задержек Android. */
    private fun burst(x: Float, y: Float, taps: Int, gapMs: Int, hold0: Long) {
        val n = minOf(taps.coerceIn(1, 8), GestureDescription.getMaxStrokeCount())
        val g = GestureDescription.Builder()
        var t = 0L
        for (i in 0 until n) {
            val hold = hold0 + rnd(0, 8)
            g.addStroke(stroke(x, y, t, hold, 8))
            t += hold + (gapMs * Random.nextDouble(0.9, 1.1)).toLong().coerceAtLeast(5L)
        }
        send(g.build(), t)
    }

    private fun jumpPoint(): Pair<Float, Float> {
        val p = Cal.get(this, "jump")
        return safePt(p.x * sw(), p.y * sh())
    }

    private fun jumpTap(hold: Long) { val (x, y) = jumpPoint(); tapPx(x, y, hold) }

    private fun jumpCycle() {
        val (x, y) = jumpPoint()
        burst(x, y, Cfg.int(this, "taps", 3), Cfg.int(this, "tapMs", 140), Cfg.int(this, "tapHold", 30).toLong())
    }

    // ───────── кнопка ускорения в игре ─────────
    private fun boostPt(): Pair<Float, Float>? {
        if (!Cal.isSet(this, "boost")) return null
        val p = Cal.get(this, "boost")
        val x = p.x * sw(); val y = p.y * sh()
        return if (blocked(x, y) != null) null else Pair(x, y)
    }

    private fun boostReady(): Boolean {
        if (boostPt() == null) return false
        val p = Cal.get(this, "boost")
        if (!Cfg.bool(this, "bCol", false) || p.color == 0) return true
        val b = shot() ?: return false
        val ok = Vision.has(b, p)
        b.recycle()
        return ok
    }

    private fun scheduleBoost(now: Long) {
        nextBoost = now + (Cfg.int(this, "bInt", 5) * 1000L * Random.nextDouble(0.95, 1.05)).toLong()
    }

    // ───────── ULTIMA: прыжки + монеты + ускорение одним потоком жестов ─────────
    private fun ultimaStep(bmp: Bitmap?) {
        if (bmp != null) {
            val c = Cal.get(this, "coin")
            coinTargets = Vision.find(bmp, Cal.COIN_AREA, c.color, Cal.TOL, 8).filter { blocked(it.first, it.second) == null }
        }
        val hold = Cfg.int(this, "uHold", 20).toLong()
        val gap = Cfg.int(this, "uGap", 8).toLong()
        val (x, y) = jumpPoint()
        val maxS = minOf(GestureDescription.getMaxStrokeCount(), 10)
        val g = GestureDescription.Builder()
        var t = 0L
        var n = 0
        val now = SystemClock.uptimeMillis()
        if (now >= nextBoost) {
            if (boostReady()) {
                boostPt()?.let { g.addStroke(stroke(it.first, it.second, t, 45, 6)); t += 45 + gap; n++ }
                scheduleBoost(now)
            } else nextBoost = now + 600
        }
        val coins = coinTargets
        coinTargets = emptyList()
        for ((cx, cy) in coins.take(3)) {
            if (n >= maxS - 2) break
            g.addStroke(stroke(cx, cy, t, hold, 8)); t += hold + gap; n++
        }
        while (n < maxS) { g.addStroke(stroke(x, y, t, hold, 6)); t += hold + gap; n++ }
        send(g.build(), t)
    }

    // ───────── скриншоты ─────────
    @Synchronized
    private fun shot(): Bitmap? {
        val wait = 360 - (SystemClock.uptimeMillis() - lastShot)
        if (wait > 0) Thread.sleep(wait)
        lastShot = SystemClock.uptimeMillis()
        val latch = CountDownLatch(1)
        var out: Bitmap? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                out = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                latch.countDown()
            }
            override fun onFailure(errorCode: Int) { latch.countDown() }
        })
        latch.await(2, TimeUnit.SECONDS)
        out?.let { lastW = it.width; lastH = it.height }
        return out
    }

    /** Снимок «в фоне»: цикл не ждёт скриншот, результат забирается на следующем проходе. */
    private fun shotAsync() {
        val now = SystemClock.uptimeMillis()
        if (asyncBusy && now - asyncStart < 3000) return
        asyncBusy = true; asyncStart = now; lastShot = now
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                val bm = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                if (bm != null) { lastW = bm.width; lastH = bm.height }
                asyncBmp = bm
                asyncBusy = false
            }
            override fun onFailure(errorCode: Int) { asyncBusy = false }
        })
    }

    // ───────── основной цикл бота ─────────
    private fun loop() {
        var lastBeat = 0L
        var lastPoll = 0L
        while (alive) {
            try {
                val wall = System.currentTimeMillis()
                if (wall - lastPoll > 500) {          // какое приложение сейчас на экране
                    lastPoll = wall
                    rootInActiveWindow?.packageName?.let { setInGame(it.toString() == Cal.GAME_PKG) }
                }
                if (wall - lastBeat > 1000) {
                    lastBeat = wall
                    val m = mods.filter { on[it.key] == true }.values.toMutableList()
                    if (on["ultima"] == true) m.add(0, "ULTIMA")
                    if (huntScene) m.add("Охота")
                    Status.beat(this, inGame, m.joinToString(", "))
                }
                val ultima = on["ultima"] == true
                if (calIdx >= 0 || !inGame || (!ultima && mods.keys.none { on[it] == true })) { Thread.sleep(300); continue }
                // пока пользователь трогает наше меню — свои жесты не шлём (они бы отменили его касание)
                if (fingerDown || SystemClock.uptimeMillis() - userTouch < 700) { Thread.sleep(15); continue }

                val chestWatch = Cfg.bool(this, "autoHunt", true) && Cal.get(this, "chest").color != 0
                val needVision = ultima || on["coin"] == true || on["pandora"] == true || chestWatch
                var bmp: Bitmap? = null
                if (needVision) {
                    bmp = asyncBmp
                    if (bmp != null) asyncBmp = null
                    else if (SystemClock.uptimeMillis() - lastShot > 380) shotAsync()
                }
                if (bmp != null && huntTick(bmp)) { bmp.recycle(); Thread.sleep(30); continue }
                if (huntScene) { bmp?.recycle(); Thread.sleep(30); continue }   // охота идёт, ждём следующий кадр

                if (ultima) { ultimaStep(bmp); bmp?.recycle(); continue }

                val now = SystemClock.uptimeMillis()
                if (on["boost"] == true && now >= nextBoost) {
                    if (boostReady()) {
                        boostPt()?.let { tapPx(it.first, it.second, rnd(40, 80), 6) }
                        scheduleBoost(SystemClock.uptimeMillis())
                    } else nextBoost = now + 600
                }
                if (on["jump"] == true && SystemClock.uptimeMillis() >= nextJump) {
                    jumpCycle()
                    val p = Cfg.int(this, "pause", 700)
                    var d = if (p >= 100) (p * Random.nextDouble(0.9, 1.1)).toLong() else p.toLong()
                    if (p >= 300 && Random.nextInt(100) < 2) d += rnd(1500, 4000)
                    nextJump = SystemClock.uptimeMillis() + d
                }
                if (bmp != null) {
                    if (!(on["pandora"] == true && pandora(bmp)) && on["coin"] == true) coins(bmp)
                    bmp.recycle()
                }
                Thread.sleep(2)
            } catch (e: InterruptedException) {
                return
            } catch (e: Throwable) {
                CrashLog.save(this, e)
                Thread.sleep(1000)
            }
        }
    }

    private fun pandora(b: Bitmap): Boolean {
        val c = Cal.get(this, "pandora")
        if (c.color == 0 || SystemClock.uptimeMillis() < pandoraUntil) return false
        val pl = Cal.get(this, "player")
        val dist = Cfg.int(this, "pDist", 12) / 100f
        val area = Area((pl.x - 0.02f).coerceAtLeast(0f), 0.03f, (pl.x + dist).coerceAtMost(0.99f), pl.y.coerceAtLeast(0.2f))
        if (Vision.find(b, area, c.color, Cal.TOL, 10).isEmpty()) return false
        val ms = if (Cfg.bool(this, "pUp", false)) 2000L else 500L
        jumpTap((ms * Random.nextDouble(0.96, 1.04)).toLong())
        val now = SystemClock.uptimeMillis()
        pandoraUntil = now + 700
        nextJump = now + 500
        return true
    }

    private fun coins(b: Bitmap) {
        val c = Cal.get(this, "coin")
        val hits = Vision.find(b, Cal.COIN_AREA, c.color, Cal.TOL, 8).filter { blocked(it.first, it.second) == null }
        for ((x, y) in hits.shuffled().take(2)) { tapPx(x, y); Thread.sleep(rnd(40, 100)) }
    }
}
