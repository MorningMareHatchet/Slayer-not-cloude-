package com.slayerbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.random.Random

class BotService : AccessibilityService() {
    private class Step(val key: String, val label: String, val def: Int, val min: Int,
                       val max: Int, val step: Int, val unit: String)

    private val stepsJ = listOf(
        Step("taps", "Тапов за прыжок", 3, 1, 8, 1, ""),
        Step("tapHold", "Длительность тапа", 30, 10, 100, 5, " мс"),
        Step("tapMs", "Интервал тапов", 140, 5, 600, 5, " мс"),
        Step("pause", "Пауза между прыжками", 700, 0, 3000, 10, " мс")
    )
    private val stepsB = listOf(Step("bInt", "Нажимать ускорение раз в", 5, 1, 120, 1, " с"))
    private val stepsU = listOf(
        Step("uHold", "Длительность тапа", 20, 10, 100, 5, " мс"),
        Step("uGap", "Интервал тапов", 8, 0, 200, 2, " мс")
    )
    private val stepsP = listOf(Step("pDist", "Дистанция до ящика", 12, 3, 40, 1, " %"))
    private val stepsM = listOf(
        Step("menuScale", "Размер меню", 100, 60, 200, 10, " %"),
        Step("menuAlpha", "Прозрачность меню", 80, 30, 100, 5, " %")
    )
    private val mods = linkedMapOf("jump" to "⚔ Прыжки", "coin" to "🪙 Монеты", "pandora" to "🎁 Пандора", "boost" to "🚀 Ускорение")

    private val on = ConcurrentHashMap<String, Boolean>()
    private val btns = HashMap<String, Button>()
    private val offBg = HashMap<String, Drawable>()
    private val onBg = HashMap<String, Drawable>()
    private var master: Button? = null
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val rects = ConcurrentHashMap<String, Rect>()   // занятые нашими окнами места — туда бот не тапает

    private var menu: View? = null
    private var menuX = 0
    private var menuY = 0
    private var menuExpanded = true
    private var btnIdx = 0
    private var settingsView: View? = null
    private var panel: LinearLayout? = null
    private var panelTxt: TextView? = null
    private var capView: View? = null
    private var frozen: Bitmap? = null

    private var huntPanel: View? = null
    private var huntInfo: TextView? = null
    private var huntAutoBtn: Button? = null
    private var markView: MarkView? = null
    private val session = ArrayList<Slot>()
    @Volatile private var mimicsLeft = 4
    @Volatile private var lastOpened: Slot? = null
    @Volatile private var markShown = true
    @Volatile private var huntOpen = false
    @Volatile private var huntAuto = false
    @Volatile private var huntBusy = false

    @Volatile private var calIdx = -1
    @Volatile private var calBusy = false
    @Volatile private var alive = true
    @Volatile private var inGame = false
    @Volatile private var nextJump = 0L
    @Volatile private var pandoraUntil = 0L
    @Volatile private var nextBoost = 0L
    @Volatile private var asyncBmp: Bitmap? = null
    @Volatile private var asyncBusy = false
    @Volatile private var asyncStart = 0L
    @Volatile private var coinTargets: List<Pair<Float, Float>> = emptyList()
    @Volatile private var lastW = 0
    @Volatile private var lastH = 0
    private var lastShot = 0L

    // настройки оформления меняются в приложении — перестраиваем меню на лету
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            "menuTheme", "menuAlpha", "menuScale", "neon" -> ui.post { buildMenu() }
            "menuHidden" -> ui.post { applyHidden() }
        }
    }

    // ───────── жизненный цикл ─────────
    override fun onServiceConnected() {
        CrashLog.install(this)
        HuntMem.load(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        menuX = dp(4); menuY = dp(12)
        getSharedPreferences("set", MODE_PRIVATE).registerOnSharedPreferenceChangeListener(prefListener)
        buildMenu()
        thread(isDaemon = true) { loop() }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {}

    /** Громкость вниз — аварийный СТОП, громкость вверх — показать/скрыть меню. */
    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || event.keyCode == KeyEvent.KEYCODE_VOLUME_UP
        when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_DOWN -> ui.post {
                for (k in mods.keys) on[k] = false
                on["ultima"] = false; huntAuto = false
                paint(); toast("СТОП: все режимы выключены")
            }
            KeyEvent.KEYCODE_VOLUME_UP -> ui.post { setHidden(!Cfg.bool(this, "menuHidden", false)) }
            else -> return false
        }
        return true
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        alive = false; huntAuto = false
        getSharedPreferences("set", MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(prefListener)
        for (v in listOf(menu, settingsView, huntPanel, markView, panel)) v?.let { runCatching { wm.removeView(it) } }
        closeCapture()
        super.onDestroy()
    }

    // ───────── общие помощники окон ─────────
    private fun dp(v: Int) = Ui.dp(this, v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun row() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) }
    private fun text(s: String, size: Float = 13f, color: Int = Ui.CREAM) = Ui.text(this, s, size, color)

    private fun pal() = Ui.pal(this, true)
    private fun neon() = Ui.neonOn(this)
    private fun sc() = Cfg.int(this, "menuScale", 100) / 100f
    private fun md(v: Int) = (dp(v) * sc()).toInt()
    private fun panelAlpha() = Ui.alpha(pal().panel, Cfg.int(this, "menuAlpha", 80) * 255 / 100)
    private fun defFill() = Ui.alpha(Ui.mix(pal().panel, Color.WHITE, 0.14f), 0xDD)

    private fun mkBtn(label: String, size: Float = 14f, fill: Int = 0, edge: Int = 0, click: () -> Unit): Button {
        val f = if (fill == 0) defFill() else fill
        val e = if (edge == 0) Ui.accent(pal(), btnIdx++) else edge
        return Button(this).apply {
            text = label; textSize = size; isAllCaps = false; setTextColor(Ui.CREAM); typeface = Ui.font
            minHeight = dp(42); minimumHeight = dp(42)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            background = Ui.bg(this@BotService, f, e, neon())
            setOnClickListener {
                CrashLog.note(this@BotService, "click: $label")
                try { click() } catch (t: Throwable) {
                    CrashLog.save(this@BotService, t); toast("Ошибка: $t")
                }
            }
        }
    }

    private fun small(t: String, c: () -> Unit) = mkBtn(t, 18f, 0, 0, c).apply {
        gravity = Gravity.CENTER; minWidth = dp(46); minimumWidth = dp(46); setPadding(0, 0, 0, 0)
    }

    private fun pair(a: View, b: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(3) })
        addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(3) })
    }

    private fun panelBox() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.bg(this@BotService, panelAlpha(), pal().accent, neon(), 4)
        setPadding(dp(12), dp(10), dp(12), dp(12))
    }

    private fun wlp(w: Int, h: Int, full: Boolean) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            (if (full) WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS else 0),
        PixelFormat.TRANSLUCENT
    ).apply {
        if (full) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(8) }
    }

    private fun panelLp(x: Int, y: Int, w: Int) = WindowManager.LayoutParams(
        w, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun markLp() = WindowManager.LayoutParams(
        -1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS }

    /** Запоминаем, где на экране наше окно, чтобы бот туда не тапал. */
    private fun refreshRect(v: View, key: String) {
        val loc = IntArray(2); v.getLocationOnScreen(loc)
        rects[key] = Rect(loc[0], loc[1], loc[0] + v.width, loc[1] + v.height)
    }

    private fun track(v: View, key: String) {
        v.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> if (v.visibility == View.VISIBLE) refreshRect(v, key) }
    }

    private fun untrack(key: String) { rects.remove(key) }

    private fun blocked(x: Float, y: Float): Rect? {
        val m = dp(14)
        for (r in rects.values) if (x >= r.left - m && x <= r.right + m && y >= r.top - m && y <= r.bottom + m) return r
        return null
    }

    /** Если точка попала под наше окно — сдвигаем вправо за его край. */
    private fun safePt(px: Float, py: Float): Pair<Float, Float> {
        var x = px
        repeat(4) { val r = blocked(x, py) ?: return Pair(x, py); x = r.right + dp(30).toFloat() }
        return Pair(x.coerceAtMost(sw() - 2f), py)
    }

    private fun drag(handle: View, win: View, lp: WindowManager.LayoutParams, key: String,
                     onMove: ((Int, Int) -> Unit)? = null, onClick: (() -> Unit)? = null) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) + abs(dy) > 12) moved = true
                    lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt()
                    wm.updateViewLayout(win, lp)
                    onMove?.invoke(lp.x, lp.y)
                    win.postDelayed({ refreshRect(win, key) }, 120)
                }
                MotionEvent.ACTION_UP -> if (!moved) onClick?.invoke()
            }
            true
        }
    }

    // ───────── плавающее меню ─────────
    private fun menuBtn(label: String, fill: Int = 0, edge: Int = 0, click: () -> Unit) =
        mkBtn(label, 12f * sc(), fill, edge, click).apply {
            minHeight = md(36); minimumHeight = md(36); setPadding(md(6), md(2), md(6), md(2)); gravity = Gravity.CENTER
        }

    private fun sizeBtn(t: String, d: Int) = mkBtn(t, 14f * sc(), 0, 0) {
        Cfg.setInt(this, "menuScale", (Cfg.int(this, "menuScale", 100) + d).coerceIn(60, 200))
    }.apply { minWidth = md(30); minimumWidth = md(30); minHeight = md(30); minimumHeight = md(30); setPadding(0, 0, 0, 0); gravity = Gravity.CENTER }

    /** (Пере)собирает меню: тема, размер и прозрачность берутся из настроек. */
    private fun buildMenu() {
        menu?.let { runCatching { wm.removeView(it) } }
        untrack("menu"); btns.clear(); offBg.clear(); onBg.clear(); btnIdx = 0
        val p = pal()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(md(6), md(4), md(6), md(6)) }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val extras = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val lp = panelLp(menuX, menuY, md(230))

        fun restyle() {
            body.visibility = if (menuExpanded) View.VISIBLE else View.GONE
            extras.visibility = body.visibility
            box.background = if (menuExpanded) Ui.bg(this, panelAlpha(), p.accent, neon(), 4) else null
            lp.width = if (menuExpanded) md(230) else WindowManager.LayoutParams.WRAP_CONTENT
        }
        restyle()

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(PortalView(this).apply { frame = p.accent }, LinearLayout.LayoutParams(md(46), md(46)))
        extras.addView(text("IDLE ULTIMA", 12f * sc(), p.accent).apply { setPadding(md(8), 0, md(4), 0) },
            LinearLayout.LayoutParams(0, -2, 1f))
        extras.addView(sizeBtn("−", -10)); extras.addView(sizeBtn("+", 10))
        head.addView(extras, LinearLayout.LayoutParams(0, -2, 1f))
        drag(head, box, lp, "menu", onMove = { x, y -> menuX = x; menuY = y }, onClick = {
            menuExpanded = !menuExpanded
            restyle(); wm.updateViewLayout(box, lp)
            box.postDelayed({ refreshRect(box, "menu") }, 120)
        })
        box.addView(head); box.addView(body)

        fun reg(k: String, b: Button): Button {
            offBg[k] = b.background
            val ult = k == "ultima"
            onBg[k] = Ui.bg(this, if (ult) Ui.BTN_TURBO else Ui.BTN_ON, if (ult) Ui.GOLD else Ui.BTN_ON_EDGE, neon())
            btns[k] = b
            return b
        }
        fun mb(k: String): Button = reg(k, menuBtn(mods[k]!!) { setOn(k, on[k] != true); paint() })

        master = reg("ultima", menuBtn("🔥 ULTIMA") { setOn("ultima", on["ultima"] != true); paint() })
        body.addView(master, row())
        body.addView(pair(mb("jump"), mb("coin")), row())
        body.addView(pair(mb("pandora"), mb("boost")), row())
        body.addView(pair(menuBtn("📦 Охота", Ui.BTN_BLUE) { openHunt() }, menuBtn("⚙ Настройки") { openSettings() }), row())
        body.addView(menuBtn("🙈 Скрыть меню") { setHidden(true); toast("Меню скрыто. Показать: громкость + или кнопка в приложении") }, row())
        body.addView(text("Громкость −: СТОП  ·  +: меню", 9f * sc(), Ui.MUTED).apply { gravity = Gravity.CENTER }, row())
        wm.addView(box, lp)
        menu = box; track(box, "menu")
        paint()
        applyHidden()
    }

    private fun applyHidden() {
        val h = Cfg.bool(this, "menuHidden", false)
        menu?.visibility = if (h) View.GONE else View.VISIBLE
        if (h) { untrack("menu"); closeSettings() }
        else menu?.postDelayed({ menu?.let { refreshRect(it, "menu") } }, 150)
    }

    private fun setHidden(v: Boolean) { Cfg.setBool(this, "menuHidden", v); applyHidden() }

    /** ULTIMA и остальные режимы взаимоисключающие: оба шлют жесты и перебивали бы друг друга. */
    private fun setOn(k: String, v: Boolean) {
        if (v) {
            if (k == "ultima") mods.keys.forEach { on[it] = false } else on["ultima"] = false
            if ((k == "boost" || k == "ultima") && !Cal.isSet(this, "boost"))
                toast("Ускорение: сначала откалибруй кнопку в игре (⚙ Настройки → Калибровка)")
            if (k == "pandora" && Cal.get(this, "pandora").color == 0)
                toast("Пандора: сначала откалибруй цвет ящика (⚙ Настройки → Калибровка)")
        }
        on[k] = v
    }

    private fun paint() {
        for (k in btns.keys) btns[k]?.background = if (on[k] == true) onBg[k] else offBg[k]
        master?.text = if (on["ultima"] == true) "■ STOP ULTIMA" else "🔥 ULTIMA"
    }

    // ───────── настройки ─────────
    private fun stepperRow(st: Step): View {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val name = text(st.label, 13f, Ui.CREAM)
        val value = text("", 14f, pal().accent).apply { gravity = Gravity.CENTER; minWidth = dp(76) }
        fun upd() { value.text = "${Cfg.int(this, st.key, st.def)}${st.unit}" }
        fun chg(d: Int) {
            Cfg.setInt(this, st.key, (Cfg.int(this, st.key, st.def) + d).coerceIn(st.min, st.max)); upd()
        }
        upd()
        r.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(small("−") { chg(-st.step) })
        r.addView(value)
        r.addView(small("+") { chg(st.step) })
        return r
    }

    private fun toggleBtn(key: String, def: Boolean, onText: String, offText: String): Button {
        var b: Button? = null
        fun t() = if (Cfg.bool(this, key, def)) onText else offText
        b = mkBtn(t(), 13f) { Cfg.setBool(this, key, !Cfg.bool(this, key, def)); b?.text = t() }
        return b!!
    }

    private fun openSettings() {
        if (settingsView != null) { closeSettings(); return }
        val col = panelBox()
        col.addView(text("⚙ НАСТРОЙКИ", 16f, pal().accent))
        fun section(t: String) = col.addView(text(t, 12f, pal().accent), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        section("— ПРЫЖКИ И ЛУК —")
        for (st in stepsJ) col.addView(stepperRow(st), row())
        section("— УСКОРЕНИЕ (кнопка в игре) —")
        for (st in stepsB) col.addView(stepperRow(st), row())
        col.addView(toggleBtn("bCol", false, "Жать только когда кнопка готова (по цвету)", "Жать по таймеру (без проверки цвета)"), row())
        section("— 🔥 ULTIMA (мин. интервал) —")
        for (st in stepsU) col.addView(stepperRow(st), row())
        section("— ПАНДОРА —")
        for (st in stepsP) col.addView(stepperRow(st), row())
        col.addView(toggleBtn("pUp", false, "🎁 Ящик: С ПРОКАЧКОЙ (тап 2 с)", "🎁 Ящик: обычный (тап 0,5 с)"), row())
        section("— ВИД МЕНЮ —")
        for (st in stepsM) col.addView(stepperRow(st), row())
        col.addView(toggleBtn("neon", true, "✨ Неоновые обводки: ВКЛ", "✨ Неоновые обводки: выкл"), row())
        col.addView(mkBtn("🎯 Калибровка точек и цветов", 13f, Ui.BTN_BLUE) { closeSettings(); startCal() }, row())
        col.addView(mkBtn("✖ Закрыть", 13f) { closeSettings() }, row())
        val sv = ScrollView(this).apply { addView(col) }
        settingsView = sv
        wm.addView(sv, panelLp(dp(240), dp(8), dp(390)))
        track(sv, "set")
    }

    private fun closeSettings() {
        settingsView?.let { runCatching { wm.removeView(it) } }
        settingsView = null; untrack("set")
    }

    // ───────── калибровка: снимок экрана → тап по снимку ─────────
    private fun startCal() {
        if (panel != null) { toast("Калибровка уже идёт"); return }
        calIdx = 0
        val p = panelBox()
        val t = text("", 13f)
        p.addView(t)
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val m = { LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6); topMargin = dp(8) } }
        r.addView(mkBtn("📷 Выбрать точку", 13f) { beginPick() }, m())
        r.addView(mkBtn("⏭ Пропуск", 13f) { nextCal() }, m())
        r.addView(mkBtn("✖ Выход", 13f) { stopCal() }, m())
        p.addView(r)
        panel = p; panelTxt = t
        wm.addView(p, wlp(-2, -2, false))
        track(p, "cal")
        showHint()
    }

    private fun showHint() {
        val it = Cal.items[calIdx]
        panelTxt?.text = "(${calIdx + 1}/${Cal.items.size}) ${it.hint}\nОткрой в игре нужный экран → «Выбрать точку»"
    }

    private fun nextCal() {
        closeCapture()
        calIdx++
        if (calIdx >= Cal.items.size) stopCal() else showHint()
    }

    private fun beginPick() {
        if (capView != null) { closeCapture(); showHint(); return }
        if (calBusy) return
        calBusy = true
        panel?.visibility = View.INVISIBLE
        menu?.visibility = View.INVISIBLE
        thread {
            Thread.sleep(250)
            val b = shot()
            ui.post {
                panel?.visibility = View.VISIBLE
                menu?.visibility = View.VISIBLE
                calBusy = false
                if (b == null) toast("Снимок экрана не получился, попробуй ещё раз") else showCapture(b)
            }
        }
    }

    private fun showCapture(b: Bitmap) {
        frozen = b
        val iv = ImageView(this).apply { setImageBitmap(b); scaleType = ImageView.ScaleType.FIT_XY }
        iv.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP && calIdx >= 0) {
                val fx = (e.x / v.width).coerceIn(0f, 1f)
                val fy = (e.y / v.height).coerceIn(0f, 1f)
                val item = Cal.items[calIdx]
                val col = if (item.needColor) b.getPixel((fx * (b.width - 1)).toInt(), (fy * (b.height - 1)).toInt()) else 0
                Cal.set(this@BotService, item.key, Pt(fx, fy, col))
                toast("Сохранено ✔")
                nextCal()
            }
            true
        }
        capView = iv
        wm.addView(iv, wlp(-1, -1, true))
        panel?.let { runCatching { wm.removeView(it) }; wm.addView(it, wlp(-2, -2, false)) }
        panelTxt?.text = "Тапни точно по нужному месту на снимке.\n(«Выбрать точку» ещё раз — отмена)"
    }

    private fun closeCapture() {
        capView?.let { runCatching { wm.removeView(it) } }
        capView = null
        frozen?.recycle(); frozen = null
    }

    private fun stopCal() {
        closeCapture()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null; panelTxt = null; calIdx = -1; untrack("cal")
        toast("Калибровка завершена")
    }

    // ───────── вкладка «Охота за сокровищами» ─────────
    private fun openHunt() {
        if (huntPanel != null) { closeHunt(); return }
        closeSettings()
        huntOpen = true
        markView = MarkView(this).also { wm.addView(it, markLp()) }
        val col = panelBox()
        val head = text("≡ 📦 ОХОТА ЗА СОКРОВИЩАМИ", 14f, Ui.GOLD).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, dp(6)) }
        col.addView(head)
        huntInfo = text("", 12f).also { col.addView(it) }
        col.addView(pair(mkBtn("🔍 Скан", 13f) { runScan() }, mkBtn("👁 Цвета", 13f) { toggleMarks() }), row())
        huntAutoBtn = mkBtn("🤖 Авто: выкл", 13f) { toggleAuto() }
        col.addView(pair(mkBtn("👆 Открыть лучший", 12f) { openBestOnce() }, huntAutoBtn!!), row())
        col.addView(pair(mkBtn("💰 Награда", 13f) { fixLast(false) }, mkBtn("👹 Мимик", 13f) { fixLast(true) }), row())

        val mr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val mv = text("", 14f, Ui.GOLD).apply { gravity = Gravity.CENTER; minWidth = dp(50) }
        fun upd() { mv.text = "$mimicsLeft" }
        fun chg(d: Int) { mimicsLeft = (mimicsLeft + d).coerceIn(0, 4); upd(); recompute(); refreshHuntUi() }
        upd()
        mr.addView(text("Мимиков осталось", 12f), LinearLayout.LayoutParams(0, -2, 1f))
        mr.addView(small("−") { chg(-1) }); mr.addView(mv); mr.addView(small("+") { chg(1) })
        col.addView(mr, row())

        col.addView(pair(mkBtn("🆕 Новая охота", 12f) { newHunt() },
            mkBtn("🗑 Память", 13f, Ui.BTN_RED) { HuntMem.reset(this); recompute(); refreshHuntUi(); toast("Память очищена") }), row())
        col.addView(mkBtn("✖ Закрыть", 13f) { closeHunt() }, row())

        val sv = ScrollView(this).apply { addView(col) }
        val w = dp(340)
        val lp = panelLp(resources.displayMetrics.widthPixels - w - dp(8), dp(8), w)
        drag(head, sv, lp, "hunt")
        wm.addView(sv, lp)
        huntPanel = sv; track(sv, "hunt")
        refreshHuntUi()
    }

    private fun closeHunt() {
        huntAuto = false; huntOpen = false
        huntPanel?.let { runCatching { wm.removeView(it) } }
        markView?.let { runCatching { wm.removeView(it) } }
        huntPanel = null; markView = null; huntInfo = null; huntAutoBtn = null; untrack("hunt")
    }

    private fun toggleMarks() {
        markShown = !markShown
        markView?.visibility = if (markShown) View.VISIBLE else View.INVISIBLE
    }

    private fun paintHunt() {
        huntAutoBtn?.apply {
            text = if (huntAuto) "🤖 Авто: ВКЛ" else "🤖 Авто: выкл"
            background = Ui.box(this@BotService, if (huntAuto) Ui.BTN_ON else Ui.BTN, if (huntAuto) Ui.BTN_ON_EDGE else Ui.EDGE)
        }
    }

    private fun recompute() {
        synchronized(session) { HuntMem.compute(session.filter { it.state == 0 }, mimicsLeft) }
    }

    /** Красим сундуки: красный — рискованнее среднего, зелёный — безопаснее, жёлтый — как у всех. */
    private fun refreshHuntUi() {
        val W = sw().toFloat(); val H = sh().toFloat()
        val marks = ArrayList<MarkView.Mark>()
        var closedN = 0
        var base = 0f
        var informative = false
        synchronized(session) {
            val closed = session.filter { it.state == 0 }
            closedN = closed.size
            base = if (closedN > 0) (mimicsLeft.toFloat() / closedN).coerceIn(0f, 1f) else 0f
            informative = HuntMem.informative(closed)
            for (s in session) {
                if (s.state == 0) {
                    val ratio = if (base > 0f) s.p / base else 1f
                    val col = when { ratio > 1.25f -> Ui.RED; ratio < 0.8f -> Ui.GREEN; else -> Ui.AMBER }
                    marks.add(MarkView.Mark(s.x * W, s.y * H, s.r * 0.9f, col, "${(s.p * 100).toInt()}%"))
                } else if (s.state == 2) marks.add(MarkView.Mark(s.x * W, s.y * H, s.r * 0.9f, Ui.RED, "✖"))
            }
        }
        markView?.marks = marks
        markView?.invalidate()
        huntInfo?.text = "Закрыто: $closedN   Мимиков осталось: $mimicsLeft\n" +
            "Шанс мимика у сундука: ${(base * 100).toInt()}%\n" +
            "Память: ${HuntMem.hunts} охот, ${HuntMem.opens()} открытий\n" +
            (if (informative) "Цвета учитывают статистику по местам." else "Данных мало — все сундуки равновероятны (жёлтые).")
    }

    private fun runScan() {
        if (huntBusy) return
        huntBusy = true
        thread { try { scanOnce() } catch (t: Throwable) { CrashLog.save(this, t) } finally { huntBusy = false } }
    }

    /** Снимок → поиск закрытых сундуков → обновление поля, памяти и вероятностей. */
    private fun scanOnce(): Boolean {
        val c = Cal.get(this, "chest")
        if (c.color == 0) { ui.post { toast("Сначала откалибруй цвет сундука (⚙ → Калибровка)") }; return false }
        ui.post { huntPanel?.visibility = View.INVISIBLE; menu?.visibility = View.INVISIBLE; markView?.visibility = View.INVISIBLE }
        Thread.sleep(220)
        val b = shot()
        ui.post {
            huntPanel?.visibility = View.VISIBLE; menu?.visibility = View.VISIBLE
            markView?.visibility = if (markShown) View.VISIBLE else View.INVISIBLE
        }
        if (b == null) { ui.post { toast("Снимок не получился") }; return false }
        val W = b.width.toFloat(); val H = b.height.toFloat()
        var blobs = Vision.components(b, Cal.CHEST_AREA, c.color, Cal.TOL, 6, 14)
        val areas = blobs.map { it.w.toLong() * it.h }.sorted()
        val med = if (areas.isEmpty()) 0L else areas[areas.size / 2]
        blobs = blobs.filter { it.w.toLong() * it.h >= med * 0.35 }
        val mc = Cal.get(this, "mimic")
        val mimics = if (mc.color != 0) Vision.components(b, Cal.CHEST_AREA, mc.color, Cal.TOL, 4, 14) else emptyList()
        b.recycle()
        if (blobs.size < 3) { ui.post { toast("Сундуки не найдены. Проверь калибровку цвета") }; return false }

        val det = blobs.map { Triple(it.cx / W, it.cy / H, maxOf(it.w, it.h) / 2f) }
        synchronized(session) {
            val still = session.filter { it.state == 0 }
            if (session.isEmpty() || det.size > still.size + 3) {          // новая доска
                session.clear(); mimicsLeft = 4; lastOpened = null
                HuntMem.hunts++; HuntMem.save(this)
                det.forEach { session.add(Slot(it.first, it.second, it.third)) }
            } else {
                for (s in still) {
                    val d = det.minByOrNull { hypot(it.first - s.x, it.second - s.y) }
                    if (d != null && hypot(d.first - s.x, d.second - s.y) < 0.03f) s.r = d.third
                    else {                                                   // сундук открыт
                        val isMimic = mimics.any { hypot(it.cx / W - s.x, it.cy / H - s.y) < 0.08f }
                        s.state = if (isMimic) 2 else 1
                        if (isMimic) mimicsLeft = maxOf(0, mimicsLeft - 1)
                        HuntMem.record(this, s.x, s.y, isMimic)
                        lastOpened = s
                    }
                }
            }
            HuntMem.compute(session.filter { it.state == 0 }, mimicsLeft)
        }
        ui.post { refreshHuntUi() }
        return true
    }

    private fun openBest(): Boolean {
        val cand = synchronized(session) {
            session.filter { it.state == 0 && blocked(it.x * sw(), it.y * sh()) == null }
        }
        if (cand.isEmpty()) return false
        val minP = cand.minOf { it.p }
        val s = cand.filter { it.p <= minP + 0.005f }.random()
        tapPx(s.x * sw(), s.y * sh(), jit = 12)
        return true
    }

    private fun openBestOnce() {
        if (huntBusy) return
        huntBusy = true
        thread {
            try {
                if (synchronized(session) { session.none { it.state == 0 } }) scanOnce()
                if (!openBest()) ui.post { toast("Нет доступных сундуков. Нажми «Скан»") }
                else { Thread.sleep(rnd(1100, 1600)); scanOnce() }
            } catch (t: Throwable) { CrashLog.save(this, t) } finally { huntBusy = false }
        }
    }

    private fun toggleAuto() {
        if (huntAuto) { huntAuto = false; paintHunt(); return }
        if (huntBusy) return
        huntAuto = true; huntBusy = true; paintHunt()
        thread {
            try {
                while (alive && huntOpen && huntAuto) {
                    if (!scanOnce()) { Thread.sleep(1500); continue }
                    if (synchronized(session) { session.none { it.state == 0 } }) break
                    if (!openBest()) { Thread.sleep(1000); continue }
                    Thread.sleep(rnd(1100, 1700))
                }
            } catch (t: Throwable) { CrashLog.save(this, t) } finally {
                huntAuto = false; huntBusy = false; ui.post { paintHunt() }
            }
        }
    }

    private fun fixLast(toMimic: Boolean) {
        val s = lastOpened ?: run { toast("Пока нет открытых сундуков"); return }
        synchronized(session) {
            if (toMimic && s.state == 1) { s.state = 2; mimicsLeft = maxOf(0, mimicsLeft - 1); HuntMem.fix(this, s.x, s.y, true) }
            else if (!toMimic && s.state == 2) { s.state = 1; mimicsLeft = minOf(4, mimicsLeft + 1); HuntMem.fix(this, s.x, s.y, false) }
            HuntMem.compute(session.filter { it.state == 0 }, mimicsLeft)
        }
        refreshHuntUi()
    }

    private fun newHunt() {
        synchronized(session) { session.clear() }
        mimicsLeft = 4; lastOpened = null
        HuntMem.hunts++; HuntMem.save(this)
        refreshHuntUi()
    }

    // ───────── ввод и экран ─────────
    private fun rnd(a: Int, b: Int) = Random.nextLong(a.toLong(), b.toLong())
    private fun sw() = if (lastW > 0) lastW else resources.displayMetrics.widthPixels
    private fun sh() = if (lastH > 0) lastH else resources.displayMetrics.heightPixels

    private fun send(g: GestureDescription, waitMs: Long) {
        val latch = CountDownLatch(1)
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        latch.await(waitMs + 1500, TimeUnit.MILLISECONDS)
    }

    private fun stroke(x: Float, y: Float, start: Long, hold: Long, jit: Int): GestureDescription.StrokeDescription {
        val px = (x + Random.nextInt(-jit, jit + 1)).coerceIn(1f, sw() - 1f)
        val py = (y + Random.nextInt(-jit, jit + 1)).coerceIn(1f, sh() - 1f)
        return GestureDescription.StrokeDescription(Path().apply { moveTo(px, py) }, start, hold)
    }

    private fun tapPx(x: Float, y: Float, hold: Long = rnd(35, 90), jit: Int = 9) {
        send(GestureDescription.Builder().addStroke(stroke(x, y, 0, hold, jit)).build(), hold)
    }

    /** Серия тапов ОДНИМ жестом: интервалы точные и не зависят от задержек Android. */
    private fun burst(x: Float, y: Float, taps: Int, gapMs: Int, hold0: Long) {
        val n = minOf(taps.coerceIn(1, 8), GestureDescription.getMaxStrokeCount())
        val g = GestureDescription.Builder()
        var t = 0L
        for (i in 0 until n) {
            val hold = hold0 + rnd(0, 8)
            g.addStroke(stroke(x, y, t, hold, 8))
            t += hold + (gapMs * Random.nextDouble(0.9, 1.1)).toLong().coerceAtLeast(5L)
        }
        send(g.build(), t)
    }

    private fun jumpPoint(): Pair<Float, Float> {
        val p = Cal.get(this, "jump")
        return safePt(p.x * sw(), p.y * sh())
    }

    private fun jumpTap(hold: Long) { val (x, y) = jumpPoint(); tapPx(x, y, hold) }

    /** Серия тапов за прыжок: 1-й — прыжок, остальные — выстрелы из лука. */
    private fun jumpCycle() {
        val (x, y) = jumpPoint()
        burst(x, y, Cfg.int(this, "taps", 3), Cfg.int(this, "tapMs", 140), Cfg.int(this, "tapHold", 30).toLong())
    }

    // ───────── кнопка ускорения в игре ─────────
    private fun boostPt(): Pair<Float, Float>? {
        if (!Cal.isSet(this, "boost")) return null
        val p = Cal.get(this, "boost")
        val x = p.x * sw(); val y = p.y * sh()
        return if (blocked(x, y) != null) null else Pair(x, y)
    }

    /** Готова ли кнопка: если включена проверка цвета — сверяем пиксели на экране. */
    private fun boostReady(): Boolean {
        if (boostPt() == null) return false
        val p = Cal.get(this, "boost")
        if (!Cfg.bool(this, "bCol", false) || p.color == 0) return true
        val b = shot() ?: return false
        val ok = Vision.has(b, p)
        b.recycle()
        return ok
    }

    private fun scheduleBoost(now: Long) {
        nextBoost = now + (Cfg.int(this, "bInt", 5) * 1000L * Random.nextDouble(0.95, 1.05)).toLong()
    }

    // ───────── 🔥 ULTIMA: прыжки + монеты + ускорение одним потоком жестов ─────────
    private fun ultimaStep() {
        // фоновый снимок → координаты монет для следующего жеста
        val bmp = asyncBmp
        if (bmp != null) {
            asyncBmp = null
            val c = Cal.get(this, "coin")
            coinTargets = Vision.find(bmp, Cal.COIN_AREA, c.color, Cal.TOL, 8).filter { blocked(it.first, it.second) == null }
            bmp.recycle()
        } else if (SystemClock.uptimeMillis() - lastShot > 380) shotAsync()

        val hold = Cfg.int(this, "uHold", 20).toLong()
        val gap = Cfg.int(this, "uGap", 8).toLong()
        val (x, y) = jumpPoint()
        val maxS = minOf(GestureDescription.getMaxStrokeCount(), 10)
        val g = GestureDescription.Builder()
        var t = 0L
        var n = 0
        val now = SystemClock.uptimeMillis()
        if (now >= nextBoost) {                                   // 🚀 ускорение
            if (boostReady()) {
                boostPt()?.let { g.addStroke(stroke(it.first, it.second, t, 45, 6)); t += 45 + gap; n++ }
                scheduleBoost(now)
            } else nextBoost = now + 600
        }
        val coins = coinTargets
        coinTargets = emptyList()
        for ((cx, cy) in coins.take(3)) {                         // 🪙 монеты
            if (n >= maxS - 2) break
            g.addStroke(stroke(cx, cy, t, hold, 8)); t += hold + gap; n++
        }
        while (n < maxS) { g.addStroke(stroke(x, y, t, hold, 6)); t += hold + gap; n++ }   // ⚔ прыжки
        send(g.build(), t)
    }

    // ───────── скриншоты ─────────
    /** Скриншот через AccessibilityService (Android 11+). Интервал ≥ ~350 мс. */
    @Synchronized
    private fun shot(): Bitmap? {
        val wait = 360 - (SystemClock.uptimeMillis() - lastShot)
        if (wait > 0) Thread.sleep(wait)
        lastShot = SystemClock.uptimeMillis()
        val latch = CountDownLatch(1)
        var out: Bitmap? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                out = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                latch.countDown()
            }
            override fun onFailure(errorCode: Int) { latch.countDown() }
        })
        latch.await(2, TimeUnit.SECONDS)
        out?.let { lastW = it.width; lastH = it.height }
        return out
    }

    /** Снимок «в фоне»: цикл прыжков не ждёт скриншот, результат забирается при следующем проходе. */
    private fun shotAsync() {
        val now = SystemClock.uptimeMillis()
        if (asyncBusy && now - asyncStart < 3000) return
        asyncBusy = true; asyncStart = now; lastShot = now
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                val bm = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                if (bm != null) { lastW = bm.width; lastH = bm.height }
                asyncBmp = bm
                asyncBusy = false
            }
            override fun onFailure(errorCode: Int) { asyncBusy = false }
        })
    }

    // ───────── основной цикл бота ─────────
    private fun loop() {
        var lastBeat = 0L
        var lastPoll = 0L
        while (alive) {
            try {
                val wall = System.currentTimeMillis()
                if (wall - lastPoll > 1000) {
                    lastPoll = wall
                    rootInActiveWindow?.packageName?.let { inGame = it.toString() == Cal.GAME_PKG }
                }
                if (wall - lastBeat > 1000) {
                    lastBeat = wall
                    val m = mods.filter { on[it.key] == true }.values.toMutableList()
                    if (on["ultima"] == true) m.add(0, "🔥 ULTIMA")
                    if (huntOpen) m.add("📦 Охота")
                    Status.beat(this, inGame, m.joinToString(", "))
                }
                if (calIdx >= 0 || huntOpen || !inGame || (on["ultima"] != true && mods.keys.none { on[it] == true })) {
                    Thread.sleep(300); continue
                }
                if (on["ultima"] == true) { ultimaStep(); continue }

                val now = SystemClock.uptimeMillis()
                if (on["boost"] == true && now >= nextBoost) {
                    if (boostReady()) {
                        boostPt()?.let { tapPx(it.first, it.second, rnd(40, 80), 6) }
                        scheduleBoost(SystemClock.uptimeMillis())
                    } else nextBoost = now + 600
                }
                if (on["jump"] == true && SystemClock.uptimeMillis() >= nextJump) {
                    jumpCycle()
                    val p = Cfg.int(this, "pause", 700)
                    var d = if (p >= 100) (p * Random.nextDouble(0.9, 1.1)).toLong() else p.toLong()
                    if (p >= 300 && Random.nextInt(100) < 2) d += rnd(1500, 4000)   // «человеческая» пауза
                    nextJump = SystemClock.uptimeMillis() + d
                }
                if (on["coin"] == true || on["pandora"] == true) {
                    val bmp = asyncBmp
                    if (bmp != null) {
                        asyncBmp = null
                        if (!(on["pandora"] == true && pandora(bmp)) && on["coin"] == true) coins(bmp)
                        bmp.recycle()
                    } else if (SystemClock.uptimeMillis() - lastShot > 380) shotAsync()
                }
                Thread.sleep(2)
            } catch (e: InterruptedException) {
                return
            } catch (e: Throwable) {
                CrashLog.save(this, e)
                Thread.sleep(1000)
            }
        }
    }

    /** Ящик Пандоры в зоне перед персонажем → долгий тап (0,5 с или 2 с с прокачкой). */
    private fun pandora(b: Bitmap): Boolean {
        val c = Cal.get(this, "pandora")
        if (c.color == 0 || SystemClock.uptimeMillis() < pandoraUntil) return false
        val pl = Cal.get(this, "player")
        val dist = Cfg.int(this, "pDist", 12) / 100f
        val area = Area((pl.x - 0.02f).coerceAtLeast(0f), 0.03f, (pl.x + dist).coerceAtMost(0.99f), pl.y.coerceAtLeast(0.2f))
        if (Vision.find(b, area, c.color, Cal.TOL, 10).isEmpty()) return false
        val ms = if (Cfg.bool(this, "pUp", false)) 2000L else 500L
        jumpTap((ms * Random.nextDouble(0.96, 1.04)).toLong())
        val now = SystemClock.uptimeMillis()
        pandoraUntil = now + 700
        nextJump = now + 500
        return true
    }

    private fun coins(b: Bitmap) {
        val c = Cal.get(this, "coin")
        val hits = Vision.find(b, Cal.COIN_AREA, c.color, Cal.TOL, 8).filter { blocked(it.first, it.second) == null }
        for ((x, y) in hits.shuffled().take(2)) { tapPx(x, y); Thread.sleep(rnd(40, 100)) }
    }
}
