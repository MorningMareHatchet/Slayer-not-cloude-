package com.slayerbot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Пиксельно-RPG оформление с неоновыми обводками и сменой тем. */
object Ui {
    private fun h(v: Long) = v.toInt()

    // статичные цвета (кнопки состояний)
    val PANEL = h(0xCC181629)
    val GOLD = h(0xFFE0A93B)
    val EDGE = h(0xFF7A72A8)
    val CREAM = h(0xFFFFF1D0)
    val MUTED = h(0xFFB7AEDB)
    val BTN = h(0xCC3A3458)
    val BTN_ON = h(0xCC2E8B3A)
    val BTN_ON_EDGE = h(0xFF7DFF8F)
    val BTN_TURBO = h(0xCCD9741A)
    val BTN_BLUE = h(0xCC2F5FB3)
    val BTN_RED = h(0xCCB03A2E)
    val GREEN = h(0xFF43A047)
    val AMBER = h(0xFFFFB300)
    val RED = h(0xFFE53935)
    val font: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    class Pal(val name: String, val accent: Int, val bg: Int, val panel: Int, val edge: Int, val rainbow: Boolean = false)

    val pals = listOf(
        Pal("Золото", h(0xFFE0A93B), h(0xFF120F20), h(0xFF181629), h(0xFF7A72A8)),
        Pal("Циан", h(0xFF18E4FF), h(0xFF07131C), h(0xFF0B1E2B), h(0xFF1B6F86)),
        Pal("Маджента", h(0xFFFF3DDB), h(0xFF160A1E), h(0xFF22102E), h(0xFF8A2C85)),
        Pal("Изумруд", h(0xFF3DFF9A), h(0xFF08150F), h(0xFF0F2218), h(0xFF1F7A4D)),
        Pal("Огонь", h(0xFFFF8A2B), h(0xFF1A0D08), h(0xFF28140C), h(0xFF8A4A22)),
        Pal("Радуга", h(0xFFB388FF), h(0xFF0F0F1E), h(0xFF171729), h(0xFF5C5C99), true)
    )
    private val cycle = intArrayOf(h(0xFF18E4FF), h(0xFFFF3DDB), h(0xFF3DFF9A), h(0xFFFFB02E), h(0xFF8C7BFF))

    fun pal(c: Context, menu: Boolean): Pal =
        pals[Cfg.int(c, if (menu) "menuTheme" else "appTheme", 0).coerceIn(0, pals.size - 1)]

    fun neonOn(c: Context) = Cfg.bool(c, "neon", true)
    fun accent(p: Pal, i: Int) = if (p.rainbow) cycle[i % cycle.size] else p.accent
    fun alpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    fun mix(a: Int, b: Int, t: Float): Int {
        fun ch(x: Int, y: Int) = (x + (y - x) * t).toInt().coerceIn(0, 255)
        return Color.rgb(ch(Color.red(a), Color.red(b)), ch(Color.green(a), Color.green(b)), ch(Color.blue(a), Color.blue(b)))
    }

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun box(c: Context, fill: Int, border: Int, r: Int = 3, w: Int = 2) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(c, r).toFloat(); setStroke(dp(c, w), border)
    }

    /** Плашка/кнопка: заливка + яркая рамка; при neon — ещё и мягкое свечение вокруг. */
    fun bg(c: Context, fill: Int, edge: Int, neon: Boolean, r: Int = 4): Drawable {
        val inner = box(c, fill, edge, r, 2)
        if (!neon) return inner
        val glow = GradientDrawable().apply {
            setColor(Color.TRANSPARENT); cornerRadius = dp(c, r + 2).toFloat(); setStroke(dp(c, 5), alpha(edge, 80))
        }
        return LayerDrawable(arrayOf(glow, inner)).apply { setLayerInset(1, dp(c, 2), dp(c, 2), dp(c, 2), dp(c, 2)) }
    }

    fun text(c: Context, s: String, size: Float, color: Int = CREAM) = TextView(c).apply {
        text = s; textSize = size; setTextColor(color); typeface = font
    }

    fun stepper(c: Context, label: String, key: String, def: Int, min: Int, max: Int, step: Int, unit: String, p: Pal): View {
        val r = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val v = text(c, "", 14f, p.accent).apply { gravity = Gravity.CENTER; minWidth = dp(c, 76) }
        fun upd() { v.text = "${Cfg.int(c, key, def)}$unit" }
        fun mini(t: String, d: Int) = Button(c).apply {
            text = t; textSize = 18f; setTextColor(CREAM); typeface = font
            minWidth = dp(c, 46); minimumWidth = dp(c, 46); minHeight = dp(c, 40); minimumHeight = dp(c, 40)
            setPadding(0, 0, 0, 0)
            background = bg(c, alpha(mix(p.panel, Color.WHITE, 0.14f), 0xDD), p.accent, neonOn(c))
            setOnClickListener { Cfg.setInt(c, key, (Cfg.int(c, key, def) + d).coerceIn(min, max)); upd() }
        }
        upd()
        r.addView(text(c, label, 13f), LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(mini("−", -step)); r.addView(v); r.addView(mini("+", step))
        return r
    }
}

/** Портал из игры: тёмный квадрат с вращающимися сине-фиолетовыми кольцами. */
class PortalView(c: Context) : View(c) {
    var frame = 0xFFE0A93B.toInt()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val cy = h / 2; val r = minOf(w, h) / 2
        p.shader = null; p.style = Paint.Style.FILL; p.color = 0xFF0A0716.toInt()
        cv.drawRoundRect(0f, 0f, w, h, r * 0.2f, r * 0.2f, p)
        p.shader = RadialGradient(
            cx, cy, r * 0.95f,
            intArrayOf(0xFFD9F7FF.toInt(), 0xFF3B8BFF.toInt(), 0xFF6A2CD8.toInt(), 0x00000000),
            floatArrayOf(0f, 0.25f, 0.6f, 1f), Shader.TileMode.CLAMP
        )
        cv.drawCircle(cx, cy, r * 0.95f, p)
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        val t = SystemClock.uptimeMillis() / 10f
        val rect = RectF()
        for (i in 0 until 3) {
            val rr = r * (0.28f + 0.2f * i)
            rect.set(cx - rr, cy - rr, cx + rr, cy + rr)
            p.strokeWidth = r * 0.08f
            p.color = if (i % 2 == 0) 0xFFCFF2FF.toInt() else 0xFFE0C8FF.toInt()
            val a = (t * (1f + i * 0.45f) * (if (i % 2 == 0) 1f else -1f)) % 360f
            cv.drawArc(rect, a, 100f, false, p)
            cv.drawArc(rect, a + 180f, 100f, false, p)
        }
        p.color = frame; p.strokeWidth = r * 0.07f
        cv.drawRoundRect(r * 0.04f, r * 0.04f, w - r * 0.04f, h - r * 0.04f, r * 0.2f, r * 0.2f, p)
        postInvalidateDelayed(40)
    }
}
