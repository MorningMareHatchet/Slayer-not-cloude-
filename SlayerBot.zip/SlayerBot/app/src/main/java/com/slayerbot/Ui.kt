package com.slayerbot

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

/** Спокойное тёмное оформление: графит, тонкие рамки, один приглушённый акцент. */
object Ui {
    private fun h(v: Long) = v.toInt()

    val CREAM = h(0xFFE4E7EB)
    val MUTED = h(0xFF8B93A0)
    val GREEN = h(0xFF6FAF7C)
    val AMBER = h(0xFFC9A66B)
    val RED = h(0xFFC27373)
    // цвета подсветки сундуков (должны читаться на любом фоне)
    val MK_RED = h(0xFFE05555)
    val MK_GREEN = h(0xFF5FBF7F)
    val MK_AMBER = h(0xFFE0B04A)
    val font: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    class Pal(val name: String, val accent: Int, val bg: Int, val panel: Int, val edge: Int)

    val pals = listOf(
        Pal("Графит", h(0xFF8FA6BF), h(0xFF111316), h(0xFF1A1D22), h(0xFF343A43)),
        Pal("Янтарь", h(0xFFC4A265), h(0xFF13110E), h(0xFF1C1914), h(0xFF3E372B)),
        Pal("Лес", h(0xFF86A98A), h(0xFF101311), h(0xFF171B18), h(0xFF303A33)),
        Pal("Бордо", h(0xFFB08585), h(0xFF131010), h(0xFF1C1617), h(0xFF3E3031)),
        Pal("Лёд", h(0xFF9CC3D5), h(0xFF0E1317), h(0xFF151B21), h(0xFF2E3A44))
    )

    fun pal(c: Context, menu: Boolean): Pal =
        pals[Cfg.int(c, if (menu) "menuTheme" else "appTheme", 0).coerceIn(0, pals.size - 1)]

    fun neonOn(c: Context) = Cfg.bool(c, "neon", false)
    fun alpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    fun mix(a: Int, b: Int, t: Float): Int {
        fun ch(x: Int, y: Int) = (x + (y - x) * t).toInt().coerceIn(0, 255)
        return Color.rgb(ch(Color.red(a), Color.red(b)), ch(Color.green(a), Color.green(b)), ch(Color.blue(a), Color.blue(b)))
    }

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun box(c: Context, fill: Int, border: Int, r: Int = 6, w: Int = 1) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(c, r).toFloat(); setStroke(dp(c, w), border)
    }

    /** Плашка с тонкой рамкой; при neon — едва заметное свечение. */
    fun bg(c: Context, fill: Int, edge: Int, neon: Boolean, r: Int = 6): Drawable {
        val inner = box(c, fill, edge, r, 1)
        if (!neon) return inner
        val glow = GradientDrawable().apply {
            setColor(Color.TRANSPARENT); cornerRadius = dp(c, r + 2).toFloat(); setStroke(dp(c, 3), alpha(edge, 55))
        }
        return LayerDrawable(arrayOf(glow, inner)).apply { setLayerInset(1, dp(c, 1), dp(c, 1), dp(c, 1), dp(c, 1)) }
    }

    /** kind: 0 обычная, 1 выбранная/главная, 2 осторожная (сброс). */
    fun btnBg(c: Context, p: Pal, neon: Boolean, kind: Int): Drawable {
        val fill: Int
        val edge: Int
        when (kind) {
            1 -> { fill = alpha(mix(p.panel, p.accent, 0.20f), 0xF0); edge = p.accent }
            2 -> { fill = alpha(h(0xFF3A2626), 0xF0); edge = h(0xFF7A4A4A) }
            else -> { fill = alpha(mix(p.panel, Color.WHITE, 0.07f), 0xE6); edge = p.edge }
        }
        return bg(c, fill, edge, neon)
    }

    fun text(c: Context, s: String, size: Float, color: Int = CREAM) = TextView(c).apply {
        text = s; textSize = size; setTextColor(color); typeface = font
    }

    /** Плавный ползунок. onRelease=true — значение применяется, когда палец отпущен (для настроек, перестраивающих меню). */
    fun slider(c: Context, label: String, key: String, def: Int, min: Int, max: Int, step: Int, unit: String,
               p: Pal, onRelease: Boolean = false): View {
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val v = text(c, "", 13f, p.accent)
        head.addView(text(c, label, 13f), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(v)
        val sb = SeekBar(c)
        sb.max = ((max - min) / step).coerceAtLeast(1)
        val cur = Cfg.int(c, key, def).coerceIn(min, max)
        sb.progress = (cur - min) / step
        v.text = "$cur$unit"
        sb.progressTintList = ColorStateList.valueOf(p.accent)
        sb.thumbTintList = ColorStateList.valueOf(p.accent)
        sb.progressBackgroundTintList = ColorStateList.valueOf(p.edge)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, pr: Int, fromUser: Boolean) {
                val value = min + pr * step
                v.text = "$value$unit"
                if (fromUser && !onRelease) Cfg.setInt(c, key, value)
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) { if (onRelease) Cfg.setInt(c, key, min + s.progress * step) }
        })
        col.addView(head)
        col.addView(sb, LinearLayout.LayoutParams(-1, dp(c, 34)))
        return col
    }

    fun stepper(c: Context, label: String, key: String, def: Int, min: Int, max: Int, step: Int, unit: String, p: Pal): View {
        val r = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val v = text(c, "", 14f, p.accent).apply { gravity = Gravity.CENTER; minWidth = dp(c, 76) }
        fun upd() { v.text = "${Cfg.int(c, key, def)}$unit" }
        fun mini(t: String, d: Int) = Button(c).apply {
            text = t; textSize = 18f; setTextColor(CREAM); typeface = font
            minWidth = dp(c, 46); minimumWidth = dp(c, 46); minHeight = dp(c, 40); minimumHeight = dp(c, 40)
            setPadding(0, 0, 0, 0)
            background = btnBg(c, p, neonOn(c), 0)
            setOnClickListener { Cfg.setInt(c, key, (Cfg.int(c, key, def) + d).coerceIn(min, max)); upd() }
        }
        upd()
        r.addView(text(c, label, 13f), LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(mini("−", -step)); r.addView(v); r.addView(mini("+", step))
        return r
    }
}

/** Контейнеры, которые сообщают о касаниях пользователя: пока палец на меню, бот не шлёт свои жесты. */
class WatchLinear(c: Context, private val cb: (MotionEvent) -> Unit) : LinearLayout(c) {
    override fun dispatchTouchEvent(e: MotionEvent): Boolean { cb(e); return super.dispatchTouchEvent(e) }
}

class WatchScroll(c: Context, private val cb: (MotionEvent) -> Unit) : ScrollView(c) {
    override fun dispatchTouchEvent(e: MotionEvent): Boolean { cb(e); return super.dispatchTouchEvent(e) }
}

/** Портал из игры — спокойная статичная иконка (без анимации). */
class PortalView(c: Context) : View(c) {
    var frame = 0xFF8FA6BF.toInt()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val cy = h / 2; val r = minOf(w, h) / 2
        p.shader = null; p.style = Paint.Style.FILL; p.color = 0xFF0B0E14.toInt()
        cv.drawRoundRect(0f, 0f, w, h, r * 0.18f, r * 0.18f, p)
        p.shader = RadialGradient(
            cx, cy, r * 0.92f,
            intArrayOf(0xFFBBD6F5.toInt(), 0xFF4E72C8.toInt(), 0xFF2B2A6E.toInt(), 0x00000000),
            floatArrayOf(0f, 0.26f, 0.62f, 1f), Shader.TileMode.CLAMP
        )
        cv.drawCircle(cx, cy, r * 0.92f, p)
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        val rect = RectF()
        for (i in 0 until 3) {
            val rr = r * (0.28f + 0.2f * i)
            rect.set(cx - rr, cy - rr, cx + rr, cy + rr)
            p.strokeWidth = r * 0.07f
            p.color = if (i % 2 == 0) 0xCCD5E6FA.toInt() else 0xCCC9BCF0.toInt()
            val a = 25f + 55f * i
            cv.drawArc(rect, a, 110f, false, p)
            cv.drawArc(rect, a + 180f, 110f, false, p)
        }
        p.color = frame; p.strokeWidth = r * 0.05f
        cv.drawRoundRect(r * 0.03f, r * 0.03f, w - r * 0.03f, h - r * 0.03f, r * 0.18f, r * 0.18f, p)
    }
}
