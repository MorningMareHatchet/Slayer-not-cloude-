package com.slayerbot

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.TextView

/** Пиксельно-RPG оформление: тёмно-фиолетовые полупрозрачные панели, золотая рамка, моно-шрифт. */
object Ui {
    val PANEL = 0xCC181629.toInt()
    val GOLD = 0xFFE0A93B.toInt()
    val EDGE = 0xFF7A72A8.toInt()
    val CREAM = 0xFFFFF1D0.toInt()
    val MUTED = 0xFFB7AEDB.toInt()
    val BTN = 0xCC3A3458.toInt()
    val BTN_ON = 0xCC3C8E40.toInt()
    val BTN_ON_EDGE = 0xFFB7F5A0.toInt()
    val BTN_TURBO = 0xCCD9741A.toInt()
    val BTN_BLUE = 0xCC2F5FB3.toInt()
    val BTN_RED = 0xCCB03A2E.toInt()
    val GREEN = 0xFF43A047.toInt()
    val AMBER = 0xFFFFB300.toInt()
    val RED = 0xFFE53935.toInt()
    val font: Typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun box(c: Context, fill: Int, border: Int, r: Int = 3, w: Int = 2) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(c, r).toFloat(); setStroke(dp(c, w), border)
    }

    fun text(c: Context, s: String, size: Float, color: Int = CREAM) = TextView(c).apply {
        text = s; textSize = size; setTextColor(color); typeface = font
    }
}
