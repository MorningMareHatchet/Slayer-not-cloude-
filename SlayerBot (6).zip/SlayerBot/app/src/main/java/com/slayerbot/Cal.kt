package com.slayerbot

import android.content.Context

class Pt(val x: Float, val y: Float, val color: Int = 0)
class Area(val l: Float, val t: Float, val r: Float, val b: Float)

/** Координаты — ДОЛИ экрана (0..1), поэтому не зависят от разрешения.
 *  Точные значения задаются в меню: ⚙ Настройки → 🎯 Калибровка. */
object Cal {
    const val GAME_PKG = "com.pabloleban.IdleSlayer"
    const val TOL = 40   // допуск по цвету (на канал RGB)

    val COIN_AREA = Area(0.26f, 0.22f, 0.98f, 0.85f)
    val CHEST_AREA = Area(0.03f, 0.12f, 0.97f, 0.92f)

    class Item(val key: String, val hint: String, val dx: Float, val dy: Float,
               val needColor: Boolean = false, val dc: Int = 0)

    val items = listOf(
        Item("jump", "ТОЧКА ПРЫЖКА: куда бот будет тапать (справа от персонажа)", .40f, .60f),
        Item("player", "ПЕРСОНАЖ: тапни по самому Slayer", .20f, .62f),
        Item("pandora", "ЦВЕТ ЯЩИКА ПАНДОРЫ: тапни по ящику", .50f, .30f, true),
        Item("coin", "ЦВЕТ МОНЕТЫ: тапни по монете", .60f, .45f, true, 0xFFFFC800.toInt()),
        Item("chest", "ОХОТА: ЦВЕТ ЗАКРЫТОГО СУНДУКА (основной цвет крышки)", .50f, .50f, true),
        Item("mimic", "ОХОТА (по желанию): ЦВЕТ МИМИКА, когда он раскрылся. Можно пропустить", .50f, .50f, true)
    )

    private fun prefs(c: Context) = c.getSharedPreferences("cal", Context.MODE_PRIVATE)

    fun get(c: Context, key: String): Pt {
        val item = items.first { i -> i.key == key }
        val s = prefs(c).getString(key, null)?.split(",")
        return if (s != null && s.size == 3) Pt(s[0].toFloat(), s[1].toFloat(), s[2].toInt())
        else Pt(item.dx, item.dy, item.dc)
    }

    fun set(c: Context, key: String, p: Pt) {
        prefs(c).edit().putString(key, "${p.x},${p.y},${p.color}").apply()
    }
}
