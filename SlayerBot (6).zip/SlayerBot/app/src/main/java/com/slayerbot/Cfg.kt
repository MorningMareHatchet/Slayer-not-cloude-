package com.slayerbot

import android.content.Context

/** Настройки скорости и режимов (меняются в плавающем меню → ⚙ Настройки). */
object Cfg {
    private fun p(c: Context) = c.getSharedPreferences("set", Context.MODE_PRIVATE)
    fun int(c: Context, k: String, d: Int) = p(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) = p(c).edit().putInt(k, v).apply()
    fun bool(c: Context, k: String, d: Boolean) = p(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = p(c).edit().putBoolean(k, v).apply()
}

class Snap(val hb: Long, val game: Boolean, val modes: String)

/** Сервис раз в секунду пишет «пульс», приложение по нему показывает статус. */
object Status {
    private fun p(c: Context) = c.getSharedPreferences("status", Context.MODE_PRIVATE)
    fun beat(c: Context, game: Boolean, modes: String) {
        p(c).edit().putLong("hb", System.currentTimeMillis())
            .putBoolean("game", game).putString("modes", modes).apply()
    }
    fun read(c: Context): Snap {
        val s = p(c)
        return Snap(s.getLong("hb", 0L), s.getBoolean("game", false), s.getString("modes", "") ?: "")
    }
}
