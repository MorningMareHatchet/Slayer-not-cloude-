package com.slayerbot

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var big: TextView
    private lateinit var l1: TextView
    private lateinit var l2: TextView
    private lateinit var l3: TextView
    private lateinit var card: LinearLayout
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun tv(t: String, size: Float, color: Int = Ui.CREAM) = Ui.text(this, t, size, color)
    private fun lp() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.box(this@MainActivity, 0xFF1C1930.toInt(), Ui.EDGE)
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }
    private fun btn(t: String, fill: Int, click: () -> Unit) = Button(this).apply {
        text = t; textSize = 14f; isAllCaps = false; setTextColor(Ui.CREAM); typeface = Ui.font
        background = Ui.box(this@MainActivity, fill, Ui.GOLD)
        minHeight = dp(52); minimumHeight = dp(52)
        setOnClickListener { try { click() } catch (e: Throwable) { CrashLog.save(this@MainActivity, e) } }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        CrashLog.install(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(28), dp(18), dp(24))
            setBackgroundColor(0xFF120F20.toInt())
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_sword_fg)
            background = Ui.box(this@MainActivity, 0xFF241F36.toInt(), Ui.GOLD, 6, 2)
        }, LinearLayout.LayoutParams(dp(76), dp(76)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
        titles.addView(tv("idle ULTIMA", 26f, Ui.GOLD))
        titles.addView(tv("автопомощник для Idle Slayer", 12f, Ui.MUTED))
        head.addView(titles)
        root.addView(head)

        card = card()
        big = tv("", 22f)
        l1 = tv("", 13f, Ui.MUTED); l2 = tv("", 13f, Ui.MUTED); l3 = tv("", 13f, Ui.MUTED)
        card.addView(tv("СТАТУС", 11f, Ui.MUTED))
        card.addView(big)
        for (v in listOf(l1, l2, l3)) card.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(card, lp())

        root.addView(btn("⚙  Открыть спец. возможности", Ui.BTN_BLUE) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, lp())
        root.addView(btn("🔓  Ограниченные настройки (сведения)", Ui.BTN) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, lp())

        val info = card()
        info.addView(tv("КАК ПОЛЬЗОВАТЬСЯ", 13f, Ui.GOLD))
        info.addView(tv(
            "1. «Сведения» → ⋮ → «Разрешить ограниченные настройки».\n" +
            "2. «Спец. возможности» → idle ULTIMA → включить.\n" +
            "3. Открой Idle Slayer в горизонтали: слева появится меню.\n" +
            "4. ⚙ Настройки → 🎯 Калибровка, потом включай режимы или FULL AFK.\n" +
            "5. 📦 Охота — отдельная вкладка для охоты за сокровищами.", 12f, Ui.CREAM),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(info, lp())

        val log = CrashLog.read(this)
        if (log != null) {
            val box = card().apply { background = Ui.box(this@MainActivity, 0xFF2A1B1B.toInt(), 0xFFFF8A65.toInt()) }
            box.addView(tv("Журнал (скопируй и пришли, если что-то сломалось)", 12f, 0xFFFFAB91.toInt()))
            val t = tv(log.takeLast(3000), 10f).apply { setTextIsSelectable(true) }
            box.addView(t)
            box.addView(btn("Очистить журнал", Ui.BTN_RED) { CrashLog.clear(this); t.text = ""; box.visibility = View.GONE }, lp())
            root.addView(box, lp())
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF120F20.toInt()); addView(root) })
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun enabled(): Boolean {
        val cn = ComponentName(this, BotService::class.java)
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.split(':').any { ComponentName.unflattenFromString(it) == cn }
    }

    private fun refresh() {
        val en = enabled()
        val st = Status.read(this)
        val alive = en && System.currentTimeMillis() - st.hb < 6000
        val (txt, col) = when {
            alive -> "●  АКТИВНА" to Ui.GREEN
            en -> "●  ВКЛЮЧЕНА, НЕТ ОТВЕТА" to Ui.AMBER
            else -> "●  НЕ АКТИВНА" to Ui.RED
        }
        big.text = txt; big.setTextColor(col)
        card.background = Ui.box(this, 0xFF1C1930.toInt(), col)
        l1.text = "Служба спец. возможностей: " + if (en) "включена ✔" else "выключена ✖"
        l2.text = "Режимы: " + if (!alive) "—" else if (st.modes.isEmpty()) "не выбраны" else st.modes
        l3.text = "Idle Slayer на экране: " + if (!alive) "—" else if (st.game) "да" else "нет (бот на паузе)"
    }
}
