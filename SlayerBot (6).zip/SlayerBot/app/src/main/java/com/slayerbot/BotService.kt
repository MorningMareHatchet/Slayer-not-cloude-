package com.slayerbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.random.Random

class BotService : AccessibilityService() {
    private class Step(val key: String, val label: String, val def: Int, val min: Int,
                       val max: Int, val step: Int, val unit: String)

    private val stepsN = listOf(
        Step("taps", "Тапов за прыжок", 3, 1, 8, 1, ""),
        Step("tapMs", "Интервал тапов", 140, 20, 600, 10, " мс"),
        Step("pause", "Пауза между прыжками", 700, 150, 3000, 50, " мс"),
        Step("pDist", "Дистанция до ящика", 12, 3, 40, 1, " %")
    )
    private val stepsT = listOf(
        Step("taps", "Тапов за прыжок", 3, 1, 8, 1, ""),
        Step("tGap", "⚡ Интервал тапов", 50, 10, 400, 5, " мс"),
        Step("tPause", "⚡ Пауза между прыжками", 350, 80, 2000, 10, " мс")
    )
    private val mods = linkedMapOf("jump" to "⚔  Прыжки и лук", "coin" to "🪙  Монеты", "pandora" to "🎁  Пандора")

    private val on = ConcurrentHashMap<String, Boolean>()
    private val btns = HashMap<String, Button>()
    private var master: Button? = null
    private var turboBtn: Button? = null
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val rects = ConcurrentHashMap<String, Rect>()   // занятые нашими окнами места — туда бот не тапает

    private var menu: View? = null
    private var settingsView: View? = null
    private var turboView: View? = null
    private var panel: LinearLayout? = null
    private var panelTxt: TextView? = null
    private var capView: View? = null
    private var frozen: Bitmap? = null

    private var huntPanel: View? = null
    private var huntInfo: TextView? = null
    private var huntAutoBtn: Button? = null
    private var markView: MarkView? = null
    private val session = ArrayList<Slot>()
    @Volatile private var mimicsLeft = 4
    @Volatile private var lastOpened: Slot? = null
    @Volatile private var markShown = true
    @Volatile private var huntOpen = false
    @Volatile private var huntAuto = false
    @Volatile private var huntBusy = false

    @Volatile private var calIdx = -1
    @Volatile private var calBusy = false
    @Volatile private var testing = false
    @Volatile private var alive = true
    @Volatile private var inGame = false
    @Volatile private var nextJump = 0L
    @Volatile private var pandoraUntil = 0L
    @Volatile private var lastW = 0
    @Volatile private var lastH = 0
    private var lastShot = 0L

    // ───────── жизненный цикл ─────────
    override fun onServiceConnected() {
        CrashLog.install(this)
        HuntMem.load(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildMenu()
        thread(isDaemon = true) { loop() }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        alive = false; huntAuto = false
        for (v in listOf(menu, settingsView, turboView, huntPanel, markView, panel)) v?.let { runCatching { wm.removeView(it) } }
        closeCapture()
        super.onDestroy()
    }

    // ───────── общие помощники окон ─────────
    private fun dp(v: Int) = Ui.dp(this, v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun row() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) }
    private fun text(s: String, size: Float = 13f, color: Int = Ui.CREAM) = Ui.text(this, s, size, color)

    private fun mkBtn(label: String, size: Float = 14f, fill: Int = Ui.BTN, click: () -> Unit) = Button(this).apply {
        text = label; textSize = size; isAllCaps = false; setTextColor(Ui.CREAM); typeface = Ui.font
        minHeight = dp(42); minimumHeight = dp(42)
        setPadding(dp(10), dp(6), dp(10), dp(6))
        gravity = Gravity.CENTER_VERTICAL or Gravity.START
        background = Ui.box(this@BotService, fill, Ui.EDGE)
        setOnClickListener {
            CrashLog.note(this@BotService, "click: $label")
            try { click() } catch (t: Throwable) {
                CrashLog.save(this@BotService, t); toast("Ошибка: $t")
            }
        }
    }

    private fun small(t: String, c: () -> Unit) = mkBtn(t, 18f, Ui.BTN, c).apply {
        gravity = Gravity.CENTER; minWidth = dp(46); minimumWidth = dp(46); setPadding(0, 0, 0, 0)
    }

    private fun pair(a: View, b: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(3) })
        addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(3) })
    }

    private fun panelBox() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.box(this@BotService, Ui.PANEL, Ui.GOLD)
        setPadding(dp(12), dp(10), dp(12), dp(12))
    }

    private fun wlp(w: Int, h: Int, full: Boolean) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            (if (full) WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS else 0),
        PixelFormat.TRANSLUCENT
    ).apply {
        if (full) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(8) }
    }

    private fun panelLp(x: Int, y: Int, w: Int) = WindowManager.LayoutParams(
        w, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun markLp() = WindowManager.LayoutParams(
        -1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS }

    /** Запоминаем, где на экране наше окно, чтобы бот туда не тапал. */
    private fun refreshRect(v: View, key: String) {
        val loc = IntArray(2); v.getLocationOnScreen(loc)
        rects[key] = Rect(loc[0], loc[1], loc[0] + v.width, loc[1] + v.height)
    }

    private fun track(v: View, key: String) {
        v.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> refreshRect(v, key) }
    }

    private fun untrack(key: String) { rects.remove(key) }

    private fun blocked(x: Float, y: Float): Rect? {
        val m = dp(14)
        for (r in rects.values) if (x >= r.left - m && x <= r.right + m && y >= r.top - m && y <= r.bottom + m) return r
        return null
    }

    /** Если точка попала под наше окно — сдвигаем вправо за его край. */
    private fun safePt(px: Float, py: Float): Pair<Float, Float> {
        var x = px
        repeat(4) { val r = blocked(x, py) ?: return Pair(x, py); x = r.right + dp(30).toFloat() }
        return Pair(x.coerceAtMost(sw() - 2f), py)
    }

    private fun drag(handle: View, win: View, lp: WindowManager.LayoutParams, key: String, onClick: (() -> Unit)? = null) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) + abs(dy) > 12) moved = true
                    lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt()
                    wm.updateViewLayout(win, lp)
                    win.postDelayed({ refreshRect(win, key) }, 120)
                }
                MotionEvent.ACTION_UP -> if (!moved) onClick?.invoke()
            }
            true
        }
    }

    // ───────── плавающее меню ─────────
    private fun buildMenu() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.box(this@BotService, Ui.PANEL, Ui.GOLD)
            setPadding(dp(8), dp(4), dp(8), dp(8))
        }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val lp = panelLp(dp(4), dp(12), dp(200))
        val head = text("≡ IDLE ULTIMA", 14f, Ui.GOLD).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(6)) }
        drag(head, box, lp, "menu") { body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        box.addView(head); box.addView(body)

        master = mkBtn("▶  FULL AFK", 16f) { toggleAll() }.apply { gravity = Gravity.CENTER }
        body.addView(master, row())
        for ((k, label) in mods) {
            val b = mkBtn(label) { setOn(k, on[k] != true); paint() }
            btns[k] = b
            body.addView(b, row())
        }
        turboBtn = mkBtn("⚡  Ускорение") { on["turbo"] = on["turbo"] != true; paint() }
        body.addView(turboBtn, row())
        body.addView(mkBtn("📦  Охота за сокровищами", 13f, Ui.BTN_BLUE) { openHunt() }, row())
        body.addView(mkBtn("⚙  Настройки") { openSettings() }, row())
        paint()
        wm.addView(box, lp)
        menu = box; track(box, "menu")
    }

    private fun toggleAll() {
        val all = mods.keys.all { on[it] == true }
        mods.keys.forEach { setOn(it, !all) }
        paint()
    }

    private fun setOn(k: String, v: Boolean) {
        on[k] = v
        if (v && k == "pandora" && Cal.get(this, "pandora").color == 0)
            toast("Пандора: сначала откалибруй цвет ящика (⚙ Настройки → Калибровка)")
    }

    private fun paint() {
        for ((k, label) in mods) btns[k]?.apply {
            val a = on[k] == true
            background = Ui.box(this@BotService, if (a) Ui.BTN_ON else Ui.BTN, if (a) Ui.BTN_ON_EDGE else Ui.EDGE)
            text = if (a) "$label  ✔" else label
        }
        turboBtn?.apply {
            val a = on["turbo"] == true
            background = Ui.box(this@BotService, if (a) Ui.BTN_TURBO else Ui.BTN, if (a) Ui.GOLD else Ui.EDGE)
            text = if (a) "⚡  Ускорение  ✔" else "⚡  Ускорение"
        }
        val all = mods.keys.all { on[it] == true }
        master?.background = Ui.box(this, if (all) Ui.BTN_RED else Ui.BTN_BLUE, Ui.GOLD)
        master?.text = if (all) "■  STOP" else "▶  FULL AFK"
    }

    // ───────── настройки и калибровка ускорения ─────────
    private fun stepperRow(st: Step): View {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val name = text(st.label, 13f, Ui.CREAM)
        val value = text("", 14f, Ui.GOLD).apply { gravity = Gravity.CENTER; minWidth = dp(76) }
        fun upd() { value.text = "${Cfg.int(this, st.key, st.def)}${st.unit}" }
        fun chg(d: Int) {
            Cfg.setInt(this, st.key, (Cfg.int(this, st.key, st.def) + d).coerceIn(st.min, st.max)); upd()
        }
        upd()
        r.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(small("−") { chg(-st.step) })
        r.addView(value)
        r.addView(small("+") { chg(st.step) })
        return r
    }

    private fun openSettings() {
        if (settingsView != null) { closeSettings(); return }
        val col = panelBox()
        col.addView(text("⚙ НАСТРОЙКИ", 16f, Ui.GOLD))
        for (st in stepsN) col.addView(stepperRow(st), row())
        fun pText() = if (Cfg.bool(this, "pUp", false)) "🎁 Ящик: С ПРОКАЧКОЙ (тап 2 с)" else "🎁 Ящик: обычный (тап 0,5 с)"
        var pBtn: Button? = null
        pBtn = mkBtn(pText(), 13f) {
            Cfg.setBool(this, "pUp", !Cfg.bool(this, "pUp", false)); pBtn?.text = pText()
        }
        col.addView(pBtn!!, row())
        col.addView(mkBtn("⚡ Калибровка ускорения", 13f, Ui.BTN_TURBO) { closeSettings(); openTurbo() }, row())
        col.addView(mkBtn("🎯 Калибровка точек и цветов", 13f, Ui.BTN_BLUE) { closeSettings(); startCal() }, row())
        col.addView(mkBtn("✖ Закрыть", 13f) { closeSettings() }, row())
        val sv = ScrollView(this).apply { addView(col) }
        settingsView = sv
        wm.addView(sv, panelLp(dp(210), dp(8), dp(380)))
        track(sv, "set")
    }

    private fun closeSettings() {
        settingsView?.let { runCatching { wm.removeView(it) } }
        settingsView = null; untrack("set")
    }

    private fun openTurbo() {
        if (turboView != null) { closeTurbo(); return }
        val col = panelBox()
        col.addView(text("⚡ КАЛИБРОВКА УСКОРЕНИЯ", 16f, Ui.GOLD))
        col.addView(text("Подбери интервал так, чтобы лук стрелял нужное число раз за один прыжок. «Тест» делает 5 прыжков в ускоренном режиме.", 11f, Ui.MUTED), row())
        for (st in stepsT) col.addView(stepperRow(st), row())
        col.addView(mkBtn("▶ Тест: 5 прыжков", 13f, Ui.BTN_ON) { runTurboTest() }, row())
        col.addView(mkBtn("✖ Закрыть", 13f) { closeTurbo() }, row())
        val sv = ScrollView(this).apply { addView(col) }
        turboView = sv
        wm.addView(sv, panelLp(dp(210), dp(8), dp(380)))
        track(sv, "turbo")
    }

    private fun closeTurbo() {
        turboView?.let { runCatching { wm.removeView(it) } }
        turboView = null; untrack("turbo")
    }

    private fun runTurboTest() {
        if (testing) return
        testing = true
        toast("Тест: 5 прыжков в ускоренном режиме")
        thread {
            try {
                repeat(5) {
                    jumpCycle(true)
                    Thread.sleep(Cfg.int(this, "tPause", 350).toLong())
                }
            } catch (t: Throwable) { CrashLog.save(this, t) } finally { testing = false }
        }
    }

    // ───────── калибровка: снимок экрана → тап по снимку ─────────
    private fun startCal() {
        if (panel != null) { toast("Калибровка уже идёт"); return }
        calIdx = 0
        val p = panelBox()
        val t = text("", 13f)
        p.addView(t)
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val m = { LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6); topMargin = dp(8) } }
        r.addView(mkBtn("📷 Выбрать точку", 13f) { beginPick() }, m())
        r.addView(mkBtn("⏭ Пропуск", 13f) { nextCal() }, m())
        r.addView(mkBtn("✖ Выход", 13f) { stopCal() }, m())
        p.addView(r)
        panel = p; panelTxt = t
        wm.addView(p, wlp(-2, -2, false))
        track(p, "cal")
        showHint()
    }

    private fun showHint() {
        val it = Cal.items[calIdx]
        panelTxt?.text = "(${calIdx + 1}/${Cal.items.size}) ${it.hint}\nОткрой в игре нужный экран → «Выбрать точку»"
    }

    private fun nextCal() {
        closeCapture()
        calIdx++
        if (calIdx >= Cal.items.size) stopCal() else showHint()
    }

    private fun beginPick() {
        if (capView != null) { closeCapture(); showHint(); return }
        if (calBusy) return
        calBusy = true
        panel?.visibility = View.INVISIBLE
        menu?.visibility = View.INVISIBLE
        thread {
            Thread.sleep(250)
            val b = shot()
            ui.post {
                panel?.visibility = View.VISIBLE
                menu?.visibility = View.VISIBLE
                calBusy = false
                if (b == null) toast("Снимок экрана не получился, попробуй ещё раз") else showCapture(b)
            }
        }
    }

    private fun showCapture(b: Bitmap) {
        frozen = b
        val iv = ImageView(this).apply { setImageBitmap(b); scaleType = ImageView.ScaleType.FIT_XY }
        iv.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP && calIdx >= 0) {
                val fx = (e.x / v.width).coerceIn(0f, 1f)
                val fy = (e.y / v.height).coerceIn(0f, 1f)
                val item = Cal.items[calIdx]
                val col = if (item.needColor) b.getPixel((fx * (b.width - 1)).toInt(), (fy * (b.height - 1)).toInt()) else 0
                Cal.set(this@BotService, item.key, Pt(fx, fy, col))
                toast("Сохранено ✔")
                nextCal()
            }
            true
        }
        capView = iv
        wm.addView(iv, wlp(-1, -1, true))
        panel?.let { runCatching { wm.removeView(it) }; wm.addView(it, wlp(-2, -2, false)) }
        panelTxt?.text = "Тапни точно по нужному месту на снимке.\n(«Выбрать точку» ещё раз — отмена)"
    }

    private fun closeCapture() {
        capView?.let { runCatching { wm.removeView(it) } }
        capView = null
        frozen?.recycle(); frozen = null
    }

    private fun stopCal() {
        closeCapture()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null; panelTxt = null; calIdx = -1; untrack("cal")
        toast("Калибровка завершена")
    }

    // ───────── вкладка «Охота за сокровищами» ─────────
    private fun openHunt() {
        if (huntPanel != null) { closeHunt(); return }
        closeSettings(); closeTurbo()
        huntOpen = true
        markView = MarkView(this).also { wm.addView(it, markLp()) }
        val col = panelBox()
        val head = text("≡ 📦 ОХОТА ЗА СОКРОВИЩАМИ", 14f, Ui.GOLD).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, dp(6)) }
        col.addView(head)
        huntInfo = text("", 12f).also { col.addView(it) }
        col.addView(pair(mkBtn("🔍 Скан", 13f) { runScan() }, mkBtn("👁 Цвета", 13f) { toggleMarks() }), row())
        huntAutoBtn = mkBtn("🤖 Авто: выкл", 13f) { toggleAuto() }
        col.addView(pair(mkBtn("👆 Открыть лучший", 12f) { openBestOnce() }, huntAutoBtn!!), row())
        col.addView(pair(mkBtn("💰 Награда", 13f) { fixLast(false) }, mkBtn("👹 Мимик", 13f) { fixLast(true) }), row())

        val mr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val mv = text("", 14f, Ui.GOLD).apply { gravity = Gravity.CENTER; minWidth = dp(50) }
        fun upd() { mv.text = "$mimicsLeft" }
        fun chg(d: Int) { mimicsLeft = (mimicsLeft + d).coerceIn(0, 4); upd(); recompute(); refreshHuntUi() }
        upd()
        mr.addView(text("Мимиков осталось", 12f), LinearLayout.LayoutParams(0, -2, 1f))
        mr.addView(small("−") { chg(-1) }); mr.addView(mv); mr.addView(small("+") { chg(1) })
        col.addView(mr, row())

        col.addView(pair(mkBtn("🆕 Новая охота", 12f) { newHunt() },
            mkBtn("🗑 Память", 13f, Ui.BTN_RED) { HuntMem.reset(this); recompute(); refreshHuntUi(); toast("Память очищена") }), row())
        col.addView(mkBtn("✖ Закрыть", 13f) { closeHunt() }, row())

        val sv = ScrollView(this).apply { addView(col) }
        val w = dp(340)
        val lp = panelLp(resources.displayMetrics.widthPixels - w - dp(8), dp(8), w)
        drag(head, sv, lp, "hunt")
        wm.addView(sv, lp)
        huntPanel = sv; track(sv, "hunt")
        refreshHuntUi()
    }

    private fun closeHunt() {
        huntAuto = false; huntOpen = false
        huntPanel?.let { runCatching { wm.removeView(it) } }
        markView?.let { runCatching { wm.removeView(it) } }
        huntPanel = null; markView = null; huntInfo = null; huntAutoBtn = null; untrack("hunt")
    }

    private fun toggleMarks() {
        markShown = !markShown
        markView?.visibility = if (markShown) View.VISIBLE else View.INVISIBLE
    }

    private fun paintHunt() {
        huntAutoBtn?.apply {
            text = if (huntAuto) "🤖 Авто: ВКЛ" else "🤖 Авто: выкл"
            background = Ui.box(this@BotService, if (huntAuto) Ui.BTN_ON else Ui.BTN, if (huntAuto) Ui.BTN_ON_EDGE else Ui.EDGE)
        }
    }

    private fun recompute() {
        synchronized(session) { HuntMem.compute(session.filter { it.state == 0 }, mimicsLeft) }
    }

    /** Красим сундуки: красный — рискованнее среднего, зелёный — безопаснее, жёлтый — как у всех. */
    private fun refreshHuntUi() {
        val W = sw().toFloat(); val H = sh().toFloat()
        val marks = ArrayList<MarkView.Mark>()
        var closedN = 0
        var base = 0f
        var informative = false
        synchronized(session) {
            val closed = session.filter { it.state == 0 }
            closedN = closed.size
            base = if (closedN > 0) (mimicsLeft.toFloat() / closedN).coerceIn(0f, 1f) else 0f
            informative = HuntMem.informative(closed)
            for (s in session) {
                if (s.state == 0) {
                    val ratio = if (base > 0f) s.p / base else 1f
                    val col = when { ratio > 1.25f -> Ui.RED; ratio < 0.8f -> Ui.GREEN; else -> Ui.AMBER }
                    marks.add(MarkView.Mark(s.x * W, s.y * H, s.r * 0.9f, col, "${(s.p * 100).toInt()}%"))
                } else if (s.state == 2) marks.add(MarkView.Mark(s.x * W, s.y * H, s.r * 0.9f, Ui.RED, "✖"))
            }
        }
        markView?.marks = marks
        markView?.invalidate()
        huntInfo?.text = "Закрыто: $closedN   Мимиков осталось: $mimicsLeft\n" +
            "Шанс мимика у сундука: ${(base * 100).toInt()}%\n" +
            "Память: ${HuntMem.hunts} охот, ${HuntMem.opens()} открытий\n" +
            (if (informative) "Цвета учитывают статистику по местам." else "Данных мало — все сундуки равновероятны (жёлтые).")
    }

    private fun runScan() {
        if (huntBusy) return
        huntBusy = true
        thread { try { scanOnce() } catch (t: Throwable) { CrashLog.save(this, t) } finally { huntBusy = false } }
    }

    /** Снимок → поиск закрытых сундуков → обновление поля, памяти и вероятностей. */
    private fun scanOnce(): Boolean {
        val c = Cal.get(this, "chest")
        if (c.color == 0) { ui.post { toast("Сначала откалибруй цвет сундука (⚙ → Калибровка)") }; return false }
        ui.post { huntPanel?.visibility = View.INVISIBLE; menu?.visibility = View.INVISIBLE; markView?.visibility = View.INVISIBLE }
        Thread.sleep(220)
        val b = shot()
        ui.post {
            huntPanel?.visibility = View.VISIBLE; menu?.visibility = View.VISIBLE
            markView?.visibility = if (markShown) View.VISIBLE else View.INVISIBLE
        }
        if (b == null) { ui.post { toast("Снимок не получился") }; return false }
        val W = b.width.toFloat(); val H = b.height.toFloat()
        var blobs = Vision.components(b, Cal.CHEST_AREA, c.color, Cal.TOL, 6, 14)
        val areas = blobs.map { it.w.toLong() * it.h }.sorted()
        val med = if (areas.isEmpty()) 0L else areas[areas.size / 2]
        blobs = blobs.filter { it.w.toLong() * it.h >= med * 0.35 }
        val mc = Cal.get(this, "mimic")
        val mimics = if (mc.color != 0) Vision.components(b, Cal.CHEST_AREA, mc.color, Cal.TOL, 4, 14) else emptyList()
        b.recycle()
        if (blobs.size < 3) { ui.post { toast("Сундуки не найдены. Проверь калибровку цвета") }; return false }

        val det = blobs.map { Triple(it.cx / W, it.cy / H, maxOf(it.w, it.h) / 2f) }
        synchronized(session) {
            val still = session.filter { it.state == 0 }
            if (session.isEmpty() || det.size > still.size + 3) {          // новая доска
                session.clear(); mimicsLeft = 4; lastOpened = null
                HuntMem.hunts++; HuntMem.save(this)
                det.forEach { session.add(Slot(it.first, it.second, it.third)) }
            } else {
                for (s in still) {
                    val d = det.minByOrNull { hypot(it.first - s.x, it.second - s.y) }
                    if (d != null && hypot(d.first - s.x, d.second - s.y) < 0.03f) s.r = d.third
                    else {                                                   // сундук открыт
                        val isMimic = mimics.any { hypot(it.cx / W - s.x, it.cy / H - s.y) < 0.08f }
                        s.state = if (isMimic) 2 else 1
                        if (isMimic) mimicsLeft = maxOf(0, mimicsLeft - 1)
                        HuntMem.record(this, s.x, s.y, isMimic)
                        lastOpened = s
                    }
                }
            }
            HuntMem.compute(session.filter { it.state == 0 }, mimicsLeft)
        }
        ui.post { refreshHuntUi() }
        return true
    }

    private fun openBest(): Boolean {
        val cand = synchronized(session) {
            session.filter { it.state == 0 && blocked(it.x * sw(), it.y * sh()) == null }
        }
        if (cand.isEmpty()) return false
        val minP = cand.minOf { it.p }
        val s = cand.filter { it.p <= minP + 0.005f }.random()
        tapPx(s.x * sw(), s.y * sh(), jit = 12)
        return true
    }

    private fun openBestOnce() {
        if (huntBusy) return
        huntBusy = true
        thread {
            try {
                if (synchronized(session) { session.none { it.state == 0 } }) scanOnce()
                if (!openBest()) ui.post { toast("Нет доступных сундуков. Нажми «Скан»") }
                else { Thread.sleep(rnd(1100, 1600)); scanOnce() }
            } catch (t: Throwable) { CrashLog.save(this, t) } finally { huntBusy = false }
        }
    }

    private fun toggleAuto() {
        if (huntAuto) { huntAuto = false; paintHunt(); return }
        if (huntBusy) return
        huntAuto = true; huntBusy = true; paintHunt()
        thread {
            try {
                while (alive && huntOpen && huntAuto) {
                    if (!scanOnce()) { Thread.sleep(1500); continue }
                    if (synchronized(session) { session.none { it.state == 0 } }) break
                    if (!openBest()) { Thread.sleep(1000); continue }
                    Thread.sleep(rnd(1100, 1700))
                }
            } catch (t: Throwable) { CrashLog.save(this, t) } finally {
                huntAuto = false; huntBusy = false; ui.post { paintHunt() }
            }
        }
    }

    private fun fixLast(toMimic: Boolean) {
        val s = lastOpened ?: run { toast("Пока нет открытых сундуков"); return }
        synchronized(session) {
            if (toMimic && s.state == 1) { s.state = 2; mimicsLeft = maxOf(0, mimicsLeft - 1); HuntMem.fix(this, s.x, s.y, true) }
            else if (!toMimic && s.state == 2) { s.state = 1; mimicsLeft = minOf(4, mimicsLeft + 1); HuntMem.fix(this, s.x, s.y, false) }
            HuntMem.compute(session.filter { it.state == 0 }, mimicsLeft)
        }
        refreshHuntUi()
    }

    private fun newHunt() {
        synchronized(session) { session.clear() }
        mimicsLeft = 4; lastOpened = null
        HuntMem.hunts++; HuntMem.save(this)
        refreshHuntUi()
    }

    // ───────── ввод и экран ─────────
    private fun rnd(a: Int, b: Int) = Random.nextLong(a.toLong(), b.toLong())
    private fun nap(a: Int, b: Int) = Thread.sleep(rnd(a, b))
    private fun sw() = if (lastW > 0) lastW else resources.displayMetrics.widthPixels
    private fun sh() = if (lastH > 0) lastH else resources.displayMetrics.heightPixels

    private fun send(g: GestureDescription, waitMs: Long) {
        val latch = CountDownLatch(1)
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        latch.await(waitMs + 1500, TimeUnit.MILLISECONDS)
    }

    private fun tapPx(x: Float, y: Float, hold: Long = rnd(35, 90), jit: Int = 9) {
        val px = (x + Random.nextInt(-jit, jit + 1)).coerceIn(1f, sw() - 1f)
        val py = (y + Random.nextInt(-jit, jit + 1)).coerceIn(1f, sh() - 1f)
        val path = Path().apply { moveTo(px, py) }
        send(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, hold)).build(), hold)
    }

    /** Серия тапов ОДНИМ жестом: интервалы точные и не зависят от задержек Android. */
    private fun burst(x: Float, y: Float, taps: Int, gapMs: Int) {
        val n = taps.coerceIn(1, 8)
        val g = GestureDescription.Builder()
        var t = 0L
        for (i in 0 until n) {
            val hold = if (i == 0) rnd(35, 70) else rnd(25, 45)
            val px = (x + Random.nextInt(-8, 9)).coerceIn(1f, sw() - 1f)
            val py = (y + Random.nextInt(-8, 9)).coerceIn(1f, sh() - 1f)
            g.addStroke(GestureDescription.StrokeDescription(Path().apply { moveTo(px, py) }, t, hold))
            t += hold + (gapMs * Random.nextDouble(0.85, 1.15)).toLong().coerceAtLeast(10L)
        }
        send(g.build(), t)
    }

    private fun jumpPoint(): Pair<Float, Float> {
        val p = Cal.get(this, "jump")
        return safePt(p.x * sw(), p.y * sh())
    }

    private fun jumpTap(hold: Long) { val (x, y) = jumpPoint(); tapPx(x, y, hold) }

    /** Серия тапов за прыжок: 1-й — прыжок, остальные — выстрелы из лука. */
    private fun jumpCycle(turbo: Boolean) {
        val taps = Cfg.int(this, "taps", 3)
        val gap = if (turbo) Cfg.int(this, "tGap", 50) else Cfg.int(this, "tapMs", 140)
        val (x, y) = jumpPoint()
        burst(x, y, taps, gap)
    }

    /** Скриншот через AccessibilityService (Android 11+). Интервал ≥ ~350 мс. */
    @Synchronized
    private fun shot(): Bitmap? {
        val wait = 360 - (SystemClock.uptimeMillis() - lastShot)
        if (wait > 0) Thread.sleep(wait)
        lastShot = SystemClock.uptimeMillis()
        val latch = CountDownLatch(1)
        var out: Bitmap? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                out = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                latch.countDown()
            }
            override fun onFailure(errorCode: Int) { latch.countDown() }
        })
        latch.await(2, TimeUnit.SECONDS)
        out?.let { lastW = it.width; lastH = it.height }
        return out
    }

    // ───────── основной цикл бота ─────────
    private fun loop() {
        var lastBeat = 0L
        var lastPoll = 0L
        while (alive) {
            try {
                val wall = System.currentTimeMillis()
                if (wall - lastPoll > 1000) {
                    lastPoll = wall
                    rootInActiveWindow?.packageName?.let { inGame = it.toString() == Cal.GAME_PKG }
                }
                if (wall - lastBeat > 1000) {
                    lastBeat = wall
                    val m = mods.filter { on[it.key] == true }.values.map { it.trim() }.toMutableList()
                    if (huntOpen) m.add("📦 Охота")
                    Status.beat(this, inGame, m.joinToString(", "))
                }
                if (calIdx >= 0 || huntOpen || testing || !inGame || mods.keys.none { on[it] == true }) {
                    Thread.sleep(300); continue
                }
                val turbo = on["turbo"] == true

                if (on["jump"] == true && SystemClock.uptimeMillis() >= nextJump) {
                    jumpCycle(turbo)
                    val pause = if (turbo) Cfg.int(this, "tPause", 350) else Cfg.int(this, "pause", 700)
                    nextJump = SystemClock.uptimeMillis() + (pause * Random.nextDouble(0.9, 1.1)).toLong()
                }
                if (on["coin"] == true || on["pandora"] == true) {
                    val bmp = shot()
                    if (bmp != null) {
                        if (!(on["pandora"] == true && pandora(bmp)) && on["coin"] == true) coins(bmp)
                        bmp.recycle()
                    }
                }
                if (!turbo && Random.nextInt(100) < 2) nap(1500, 4000)   // «человеческая» пауза
                Thread.sleep(if (turbo) rnd(20, 60) else rnd(60, 160))
            } catch (e: InterruptedException) {
                return
            } catch (e: Throwable) {
                CrashLog.save(this, e)
                Thread.sleep(1000)
            }
        }
    }

    /** Ящик Пандоры в зоне перед персонажем → долгий тап (0,5 с или 2 с с прокачкой). */
    private fun pandora(b: Bitmap): Boolean {
        val c = Cal.get(this, "pandora")
        if (c.color == 0 || SystemClock.uptimeMillis() < pandoraUntil) return false
        val pl = Cal.get(this, "player")
        val dist = Cfg.int(this, "pDist", 12) / 100f
        val area = Area((pl.x - 0.02f).coerceAtLeast(0f), 0.03f, (pl.x + dist).coerceAtMost(0.99f), pl.y.coerceAtLeast(0.2f))
        if (Vision.find(b, area, c.color, Cal.TOL, 10).isEmpty()) return false
        val ms = if (Cfg.bool(this, "pUp", false)) 2000L else 500L
        jumpTap((ms * Random.nextDouble(0.96, 1.04)).toLong())
        val now = SystemClock.uptimeMillis()
        pandoraUntil = now + 700
        nextJump = now + 500
        return true
    }

    private fun coins(b: Bitmap) {
        val c = Cal.get(this, "coin")
        val hits = Vision.find(b, Cal.COIN_AREA, c.color, Cal.TOL, 8).filter { blocked(it.first, it.second) == null }
        for ((x, y) in hits.shuffled().take(2)) { tapPx(x, y); nap(40, 100) }
    }
}
