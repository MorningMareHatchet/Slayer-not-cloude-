package com.slayerbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.random.Random

class BotService : AccessibilityService() {
    private val names = linkedMapOf(
        "jump" to "Прыжки/мобы", "coin" to "Монеты", "chest" to "Сундуки",
        "bonus" to "Бонус-уровни", "shop" to "Прокачка", "asc" to "Перерождение"
    )
    private val on = ConcurrentHashMap<String, Boolean>()
    private val btns = HashMap<String, Button>()
    private var master: Button? = null
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var menu: View? = null
    private var panel: LinearLayout? = null
    private var panelTxt: TextView? = null
    private var capView: View? = null
    private var frozen: Bitmap? = null
    @Volatile private var calIdx = -1
    @Volatile private var calBusy = false
    @Volatile private var alive = true
    @Volatile private var inGame = false
    @Volatile private var nextAsc = 0L
    @Volatile private var nextShop = 0L
    @Volatile private var lastW = 0
    @Volatile private var lastH = 0
    private var lastShot = 0L
    private val recent = ArrayList<Triple<Float, Float, Long>>()

    // ───────── жизненный цикл ─────────
    override fun onServiceConnected() {
        CrashLog.install(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildMenu()
        thread(isDaemon = true) { loop() }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val p = e.packageName?.toString() ?: return
        if (p == "com.android.systemui" || p == packageName) return
        inGame = p == Cal.GAME_PKG   // вне игры бот сам замолкает
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        alive = false
        menu?.let { runCatching { wm.removeView(it) } }
        closeCapture()
        panel?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }

    // ───────── плавающее меню ─────────
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun mkBtn(label: String, click: () -> Unit) = Button(this).apply {
        text = label; textSize = 11f; isAllCaps = false
        minHeight = 0; minimumHeight = 0
        setPadding(dp(8), dp(4), dp(8), dp(4)); setTextColor(Color.WHITE)
        setOnClickListener {
            CrashLog.note(this@BotService, "click: $label")
            try { click() } catch (t: Throwable) {
                CrashLog.save(this@BotService, t)
                toast("Ошибка: $t")
            }
        }
    }

    private fun buildMenu() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC202020.toInt()); setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = dp(24) }

        val head = TextView(this).apply {
            text = "≡ BOT"; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(4))
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        head.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) + abs(dy) > 12) moved = true
                    lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt()
                    wm.updateViewLayout(box, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved)
                    body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
            true
        }
        val row = { LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) } }
        box.addView(head)
        box.addView(body)

        master = mkBtn("▶ FULL AFK") {
            val all = names.keys.all { on[it] == true }
            names.keys.forEach { setOn(it, !all) }
            paint()
        }
        body.addView(master, row())
        for ((k, label) in names) {
            val b = mkBtn(label) { setOn(k, on[k] != true); paint() }
            btns[k] = b
            body.addView(b, row())
        }
        body.addView(mkBtn("⚙ Калибровка") { startCal() }.apply { setBackgroundColor(0xFF6A1B9A.toInt()) }, row())
        paint()
        wm.addView(box, lp)
        menu = box
    }

    private fun setOn(k: String, v: Boolean) {
        on[k] = v
        val now = SystemClock.uptimeMillis()
        if (v && k == "asc") nextAsc = now + Cal.ASC_EVERY_MIN * 60_000L
        if (v && k == "shop") nextShop = now + 5_000
    }

    private fun paint() {
        for ((k, b) in btns) b.setBackgroundColor(if (on[k] == true) 0xFF2E7D32.toInt() else 0xFF555555.toInt())
        val all = names.keys.all { on[it] == true }
        master?.setBackgroundColor(if (all) 0xFFC62828.toInt() else 0xFF1565C0.toInt())
        master?.text = if (all) "■ STOP" else "▶ FULL AFK"
    }

    // ───────── калибровка: снимок экрана → тап по снимку ─────────
    private fun wlp(w: Int, h: Int, full: Boolean) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            (if (full) WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS else 0),
        PixelFormat.TRANSLUCENT
    ).apply {
        if (full) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(8) }
    }

    private fun gb(label: String, c: () -> Unit) = mkBtn(label, c).apply { setBackgroundColor(0xFF444444.toInt()) }

    private fun startCal() {
        if (panel != null) { toast("Калибровка уже идёт"); return }
        calIdx = 0
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xEE000000.toInt()); setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        val t = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f }
        p.addView(t)
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val m = { LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6); topMargin = dp(6) } }
        r.addView(gb("📷 Выбрать точку") { beginPick() }, m())
        r.addView(gb("⏭ Пропуск") { nextCal() }, m())
        r.addView(gb("✖ Выход") { stopCal() }, m())
        p.addView(r)
        panel = p; panelTxt = t
        wm.addView(p, wlp(-2, -2, false))
        showHint()
    }

    private fun showHint() {
        val it = Cal.items[calIdx]
        panelTxt?.text = "(${calIdx + 1}/${Cal.items.size}) ${it.hint}\nОткрой в игре нужный экран → «Выбрать точку»"
    }

    private fun nextCal() {
        closeCapture()
        calIdx++
        if (calIdx >= Cal.items.size) stopCal() else showHint()
    }

    private fun beginPick() {
        if (capView != null) { closeCapture(); showHint(); return }   // повторное нажатие = отмена
        if (calBusy) return
        calBusy = true
        panel?.visibility = View.INVISIBLE
        menu?.visibility = View.INVISIBLE
        thread {
            Thread.sleep(250)
            val b = shot()
            ui.post {
                panel?.visibility = View.VISIBLE
                menu?.visibility = View.VISIBLE
                calBusy = false
                if (b == null) toast("Снимок экрана не получился, попробуй ещё раз") else showCapture(b)
            }
        }
    }

    private fun showCapture(b: Bitmap) {
        frozen = b
        val iv = ImageView(this).apply { setImageBitmap(b); scaleType = ImageView.ScaleType.FIT_XY }
        iv.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP && calIdx >= 0) {
                val fx = (e.x / v.width).coerceIn(0f, 1f)
                val fy = (e.y / v.height).coerceIn(0f, 1f)
                val item = Cal.items[calIdx]
                val col = if (item.needColor)
                    b.getPixel((fx * (b.width - 1)).toInt(), (fy * (b.height - 1)).toInt()) else 0
                Cal.set(this@BotService, item.key, Pt(fx, fy, col))
                toast("Сохранено: ${item.key}")
                nextCal()
            }
            true
        }
        capView = iv
        wm.addView(iv, wlp(-1, -1, true))
        panel?.let { runCatching { wm.removeView(it) }; wm.addView(it, wlp(-2, -2, false)) }  // панель поверх снимка
        panelTxt?.text = "Тапни точно по нужному месту на снимке.\n(«Выбрать точку» ещё раз — отмена)"
    }

    private fun closeCapture() {
        capView?.let { runCatching { wm.removeView(it) } }
        capView = null
        frozen?.recycle(); frozen = null
    }

    private fun stopCal() {
        closeCapture()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null; panelTxt = null; calIdx = -1
        toast("Калибровка завершена")
    }

    // ───────── ввод и экран ─────────
    private fun rnd(a: Int, b: Int) = Random.nextLong(a.toLong(), b.toLong())
    private fun nap(a: Int, b: Int) = Thread.sleep(rnd(a, b))
    private fun sw() = if (lastW > 0) lastW else resources.displayMetrics.widthPixels
    private fun sh() = if (lastH > 0) lastH else resources.displayMetrics.heightPixels

    private fun tapPx(x: Float, y: Float, hold: Long = rnd(35, 90), jit: Int = 9) {
        val px = (x + Random.nextInt(-jit, jit + 1)).coerceIn(1f, sw() - 1f)
        val py = (y + Random.nextInt(-jit, jit + 1)).coerceIn(1f, sh() - 1f)
        val path = Path().apply { moveTo(px, py) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, hold)).build()
        val latch = CountDownLatch(1)
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        latch.await(1, TimeUnit.SECONDS)
    }

    private fun tap(p: Pt, hold: Long = rnd(35, 90)) = tapPx(p.x * sw(), p.y * sh(), hold)
    private fun tap(key: String, hold: Long = rnd(35, 90)) = tap(Cal.get(this, key), hold)

    /** Скриншот через AccessibilityService (Android 11+), без MediaProjection. Интервал ≥ ~350 мс. */
    @Synchronized
    private fun shot(): Bitmap? {
        val wait = 360 - (SystemClock.uptimeMillis() - lastShot)
        if (wait > 0) Thread.sleep(wait)
        lastShot = SystemClock.uptimeMillis()
        val latch = CountDownLatch(1)
        var out: Bitmap? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                out = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                latch.countDown()
            }
            override fun onFailure(errorCode: Int) { latch.countDown() }
        })
        latch.await(2, TimeUnit.SECONDS)
        out?.let { lastW = it.width; lastH = it.height }
        return out
    }

    // ───────── основной цикл бота ─────────
    private fun loop() {
        val t0 = SystemClock.uptimeMillis()
        nextShop = t0 + 20_000
        nextAsc = t0 + Cal.ASC_EVERY_MIN * 60_000L
        var nextJump = 0L
        while (alive) {
            try {
                if (calIdx >= 0 || !inGame || on.values.none { it }) { Thread.sleep(300); continue }
                var busy = false
                if (on["coin"] == true || on["chest"] == true || on["bonus"] == true) {
                    val bmp = shot()
                    if (bmp != null) { busy = scene(bmp); bmp.recycle() }
                }
                val t = SystemClock.uptimeMillis()
                if (!busy) {
                    if (on["jump"] == true && t >= nextJump) {
                        jump(); nextJump = SystemClock.uptimeMillis() + rnd(450, 1500)
                    }
                    if (on["shop"] == true && t >= nextShop) {
                        shopRound(); nextShop = SystemClock.uptimeMillis() + Cal.SHOP_EVERY_SEC * 1000L
                    }
                    if (on["asc"] == true && t >= nextAsc) {
                        ascend(); nextAsc = SystemClock.uptimeMillis() + Cal.ASC_EVERY_MIN * 60_000L
                    }
                }
                if (Random.nextInt(100) < 2) nap(1500, 4000)   // «человеческая» пауза
                nap(80, 200)
            } catch (e: InterruptedException) {
                return
            } catch (e: Throwable) {
                CrashLog.save(this, e)
                Thread.sleep(1000)
            }
        }
    }

    /** true — если мы на спец-сцене (сундуки/бонус) и обычные действия надо пропустить. */
    private fun scene(b: Bitmap): Boolean {
        val cm = Cal.get(this, "chestMark")
        val bm = Cal.get(this, "bonusMark")
        if (on["chest"] == true && cm.color != 0 && Vision.has(b, cm)) { chests(b); return true }
        if (on["bonus"] == true && bm.color != 0 && Vision.has(b, bm)) {
            tap("jump", rnd(30, 70)); nap(110, 220); tap("jump", rnd(30, 70)); return true
        }
        if (on["coin"] == true) coins(b)
        return false
    }

    private fun coins(b: Bitmap) {
        val c = Cal.get(this, "coin")
        for ((x, y) in Vision.find(b, Cal.COIN_AREA, c.color, Cal.TOL, 8).shuffled().take(2)) {
            tapPx(x, y); nap(40, 100)
        }
    }

    private fun chests(b: Bitmap) {
        val c = Cal.get(this, "chest")
        if (c.color == 0) return
        val now = SystemClock.uptimeMillis()
        recent.removeAll { now - it.third > 4000 }
        val hit = Vision.find(b, Cal.CHEST_AREA, c.color, Cal.TOL, 15)
            .filter { h -> recent.none { abs(it.first - h.first) < 90 && abs(it.second - h.second) < 90 } }
            .randomOrNull() ?: return
        recent.add(Triple(hit.first, hit.second, now))
        tapPx(hit.first, hit.second, jit = 14)
    }

    private fun jump() {
        tap("jump", rnd(40, 220))
        if (Random.nextInt(100) < 15) { nap(80, 160); tap("jump", rnd(40, 120)) }
    }

    private fun shopRound() {
        tap("shop"); nap(700, 1000)
        for (i in 0..3) repeat(Cal.BUY_REPEAT) { tap("buy$i"); nap(120, 260) }
        tap("shopClose"); nap(500, 800)
    }

    private fun ascend() {
        tap("asc"); nap(800, 1100)
        tap("ascOk"); nap(800, 1100)
        tap("ascOk"); nap(2500, 3500)
    }
}
