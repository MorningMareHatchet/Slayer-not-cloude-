package com.slayerbot

import android.content.Context
import android.util.Log
import java.io.File

object CrashLog {
    private fun f(c: Context) = File(c.filesDir, "crash.txt")

    fun save(c: Context, e: Throwable) {
        runCatching { f(c).appendText(Log.getStackTraceString(e) + "\n----\n") }
    }

    fun note(c: Context, m: String) {
        runCatching { f(c).appendText(java.text.SimpleDateFormat("HH:mm:ss").format(java.util.Date()) + " " + m + "\n") }
    }

    fun install(c: Context) {
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            save(c, e)
            old?.uncaughtException(t, e)
        }
    }

    fun read(c: Context): String? = runCatching { f(c).takeIf { it.exists() }?.readText() }.getOrNull()
    fun clear(c: Context) { runCatching { f(c).delete() } }
}
