package com.slayerbot

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs

object Vision {
    fun near(p: Int, c: Int, t: Int) =
        abs(Color.red(p) - Color.red(c)) < t &&
        abs(Color.green(p) - Color.green(c)) < t &&
        abs(Color.blue(p) - Color.blue(c)) < t

    /** Есть ли в окрестности точки p цвет p.color (для маркеров сцен). */
    fun has(b: Bitmap, p: Pt, tol: Int = Cal.TOL): Boolean {
        val cx = (p.x * b.width).toInt()
        val cy = (p.y * b.height).toInt()
        for (dy in -6..6 step 3) for (dx in -6..6 step 3) {
            val x = (cx + dx).coerceIn(0, b.width - 1)
            val y = (cy + dy).coerceIn(0, b.height - 1)
            if (near(b.getPixel(x, y), p.color, tol)) return true
        }
        return false
    }

    /** Центры скоплений пикселей заданного цвета в области (в пикселях экрана). */
    fun find(b: Bitmap, a: Area, color: Int, tol: Int, minHits: Int): List<Pair<Float, Float>> {
        val x0 = (a.l * b.width).toInt()
        val y0 = (a.t * b.height).toInt()
        val w = (a.r * b.width).toInt() - x0
        val h = (a.b * b.height).toInt() - y0
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, x0, y0, w, h)
        val cell = 64
        val cols = w / cell + 1
        val acc = HashMap<Int, IntArray>()
        for (y in 0 until h step 3) for (x in 0 until w step 3) {
            if (near(px[y * w + x], color, tol)) {
                val e = acc.getOrPut((y / cell) * cols + x / cell) { IntArray(3) }
                e[0]++; e[1] += x; e[2] += y
            }
        }
        return acc.values.filter { it[0] >= minHits }
            .map { Pair(x0 + it[1].toFloat() / it[0], y0 + it[2].toFloat() / it[0]) }
    }
}
