package com.slayerbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.random.Random

class BotService : AccessibilityService() {
    private class Step(val key: String, val label: String, val def: Int, val min: Int,
                       val max: Int, val step: Int, val unit: String)

    private val steps = listOf(
        Step("taps", "Тапов за прыжок", 3, 1, 6, 1, ""),
        Step("tapMs", "Интервал тапов", 140, 40, 600, 10, " мс"),
        Step("pause", "Пауза между прыжками", 700, 150, 3000, 50, " мс"),
        Step("pDist", "Дистанция до ящика", 12, 3, 40, 1, " %")
    )
    private val mods = linkedMapOf(
        "jump" to "⚔  Прыжки и лук", "coin" to "🪙  Монеты",
        "chest" to "📦  Сундуки", "pandora" to "🎁  Пандора"
    )
    private val on = ConcurrentHashMap<String, Boolean>()
    private val btns = HashMap<String, Button>()
    private var master: Button? = null
    private var turboBtn: Button? = null
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var menu: View? = null
    private var settingsView: View? = null
    private var panel: LinearLayout? = null
    private var panelTxt: TextView? = null
    private var capView: View? = null
    private var frozen: Bitmap? = null
    @Volatile private var calIdx = -1
    @Volatile private var calBusy = false
    @Volatile private var alive = true
    @Volatile private var inGame = false
    @Volatile private var nextJump = 0L
    @Volatile private var pandoraUntil = 0L
    @Volatile private var lastW = 0
    @Volatile private var lastH = 0
    private var lastShot = 0L
    private val recent = ArrayList<Triple<Float, Float, Long>>()

    // ───────── жизненный цикл ─────────
    override fun onServiceConnected() {
        CrashLog.install(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildMenu()
        thread(isDaemon = true) { loop() }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        alive = false
        menu?.let { runCatching { wm.removeView(it) } }
        settingsView?.let { runCatching { wm.removeView(it) } }
        closeCapture()
        panel?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }

    // ───────── оформление ─────────
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun bg(c: Int, r: Int = 14) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun row() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) }

    private fun mkBtn(label: String, size: Float = 15f, click: () -> Unit) = Button(this).apply {
        text = label; textSize = size; isAllCaps = false; setTextColor(Color.WHITE)
        minHeight = dp(46); minimumHeight = dp(46)
        setPadding(dp(12), dp(8), dp(12), dp(8))
        gravity = Gravity.CENTER_VERTICAL or Gravity.START
        background = bg(0xFF3A404C.toInt())
        setOnClickListener {
            CrashLog.note(this@BotService, "click: $label")
            try { click() } catch (t: Throwable) {
                CrashLog.save(this@BotService, t)
                toast("Ошибка: $t")
            }
        }
    }

    private fun gray(label: String, click: () -> Unit) = mkBtn(label, 14f, click)

    // ───────── плавающее меню ─────────
    private fun buildMenu() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(0xE61B1F27.toInt(), 20); setPadding(dp(8), dp(6), dp(8), dp(8))
        }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val lp = WindowManager.LayoutParams(
            dp(190), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(4); y = dp(16) }

        val head = TextView(this).apply {
            text = "≡  SLAYER BOT"; setTextColor(0xFFB0BEC5.toInt()); textSize = 14f
            setTypeface(null, Typeface.BOLD); gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(6))
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        head.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) + abs(dy) > 12) moved = true
                    lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt()
                    wm.updateViewLayout(box, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved)
                    body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
            true
        }
        box.addView(head)
        box.addView(body)

        master = mkBtn("▶  FULL AFK", 17f) { toggleAll() }.apply { gravity = Gravity.CENTER }
        body.addView(master, row())
        for ((k, label) in mods) {
            val b = mkBtn(label) { setOn(k, on[k] != true); paint() }
            btns[k] = b
            body.addView(b, row())
        }
        turboBtn = mkBtn("⚡  Ускорение") { on["turbo"] = on["turbo"] != true; paint() }
        body.addView(turboBtn, row())
        body.addView(gray("⚙  Настройки") { openSettings() }, row())
        paint()
        wm.addView(box, lp)
        menu = box
    }

    private fun toggleAll() {
        val all = mods.keys.all { on[it] == true }
        mods.keys.forEach { setOn(it, !all) }
        paint()
    }

    private fun setOn(k: String, v: Boolean) {
        on[k] = v
        if (!v) return
        if (k == "pandora" && Cal.get(this, "pandora").color == 0)
            toast("Пандора: сначала откалибруй цвет ящика (⚙ Настройки → Калибровка)")
        if (k == "chest" && (Cal.get(this, "chestMark").color == 0 || Cal.get(this, "chest").color == 0))
            toast("Сундуки: сначала откалибруй маркер и цвет сундука")
    }

    private fun paint() {
        for ((k, label) in mods) btns[k]?.apply {
            val a = on[k] == true
            background = bg(if (a) 0xFF2E7D32.toInt() else 0xFF3A404C.toInt())
            text = if (a) "$label   ✔" else label
        }
        turboBtn?.apply {
            val a = on["turbo"] == true
            background = bg(if (a) 0xFFEF6C00.toInt() else 0xFF3A404C.toInt())
            text = if (a) "⚡  Ускорение   ✔" else "⚡  Ускорение"
        }
        val all = mods.keys.all { on[it] == true }
        master?.background = bg(if (all) 0xFFC62828.toInt() else 0xFF1565C0.toInt(), 16)
        master?.text = if (all) "■  STOP" else "▶  FULL AFK"
    }

    // ───────── окно настроек ─────────
    private fun openSettings() {
        if (settingsView != null) { closeSettings(); return }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(0xF01B1F27.toInt(), 20); setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        col.addView(TextView(this).apply {
            text = "⚙  Настройки"; textSize = 17f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
        })
        for (st in steps) col.addView(stepperRow(st), row())

        fun pText() = if (Cfg.bool(this, "pUp", false)) "🎁  Ящик Пандоры: С ПРОКАЧКОЙ (тап 2 с)"
        else "🎁  Ящик Пандоры: обычный (тап 0,5 с)"
        var pBtn: Button? = null
        pBtn = mkBtn(pText(), 14f) {
            Cfg.setBool(this, "pUp", !Cfg.bool(this, "pUp", false))
            pBtn?.text = pText()
        }
        col.addView(pBtn!!, row())
        col.addView(gray("🎯  Калибровка") { closeSettings(); startCal() }, row())
        col.addView(gray("✖  Закрыть") { closeSettings() }, row())

        val sv = ScrollView(this).apply { addView(col) }
        settingsView = sv
        wm.addView(sv, wlp(dp(370), WindowManager.LayoutParams.WRAP_CONTENT, false))
    }

    private fun closeSettings() {
        settingsView?.let { runCatching { wm.removeView(it) } }
        settingsView = null
    }

    private fun stepperRow(st: Step): View {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val name = TextView(this).apply { text = st.label; setTextColor(0xFFE0E0E0.toInt()); textSize = 14f }
        val value = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER
            minWidth = dp(76); setTypeface(null, Typeface.BOLD)
        }
        fun upd() { value.text = "${Cfg.int(this, st.key, st.def)}${st.unit}" }
        fun chg(d: Int) {
            Cfg.setInt(this, st.key, (Cfg.int(this, st.key, st.def) + d).coerceIn(st.min, st.max)); upd()
        }
        upd()
        fun small(t: String, c: () -> Unit) = mkBtn(t, 18f, c).apply {
            gravity = Gravity.CENTER; minWidth = dp(46); minimumWidth = dp(46); setPadding(0, 0, 0, 0)
        }
        r.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(small("−") { chg(-st.step) })
        r.addView(value)
        r.addView(small("+") { chg(st.step) })
        return r
    }

    // ───────── калибровка: снимок экрана → тап по снимку ─────────
    private fun wlp(w: Int, h: Int, full: Boolean) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            (if (full) WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS else 0),
        PixelFormat.TRANSLUCENT
    ).apply {
        if (full) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(8) }
    }

    private fun startCal() {
        if (panel != null) { toast("Калибровка уже идёт"); return }
        calIdx = 0
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(0xEE000000.toInt(), 16); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val t = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f }
        p.addView(t)
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val m = { LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6); topMargin = dp(8) } }
        r.addView(gray("📷 Выбрать точку") { beginPick() }, m())
        r.addView(gray("⏭ Пропуск") { nextCal() }, m())
        r.addView(gray("✖ Выход") { stopCal() }, m())
        p.addView(r)
        panel = p; panelTxt = t
        wm.addView(p, wlp(-2, -2, false))
        showHint()
    }

    private fun showHint() {
        val it = Cal.items[calIdx]
        panelTxt?.text = "(${calIdx + 1}/${Cal.items.size}) ${it.hint}\nОткрой в игре нужный экран → «Выбрать точку»"
    }

    private fun nextCal() {
        closeCapture()
        calIdx++
        if (calIdx >= Cal.items.size) stopCal() else showHint()
    }

    private fun beginPick() {
        if (capView != null) { closeCapture(); showHint(); return }   // повторное нажатие = отмена
        if (calBusy) return
        calBusy = true
        panel?.visibility = View.INVISIBLE
        menu?.visibility = View.INVISIBLE
        thread {
            Thread.sleep(250)
            val b = shot()
            ui.post {
                panel?.visibility = View.VISIBLE
                menu?.visibility = View.VISIBLE
                calBusy = false
                if (b == null) toast("Снимок экрана не получился, попробуй ещё раз") else showCapture(b)
            }
        }
    }

    private fun showCapture(b: Bitmap) {
        frozen = b
        val iv = ImageView(this).apply { setImageBitmap(b); scaleType = ImageView.ScaleType.FIT_XY }
        iv.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP && calIdx >= 0) {
                val fx = (e.x / v.width).coerceIn(0f, 1f)
                val fy = (e.y / v.height).coerceIn(0f, 1f)
                val item = Cal.items[calIdx]
                val col = if (item.needColor)
                    b.getPixel((fx * (b.width - 1)).toInt(), (fy * (b.height - 1)).toInt()) else 0
                Cal.set(this@BotService, item.key, Pt(fx, fy, col))
                toast("Сохранено ✔")
                nextCal()
            }
            true
        }
        capView = iv
        wm.addView(iv, wlp(-1, -1, true))
        panel?.let { runCatching { wm.removeView(it) }; wm.addView(it, wlp(-2, -2, false)) }  // панель поверх снимка
        panelTxt?.text = "Тапни точно по нужному месту на снимке.\n(«Выбрать точку» ещё раз — отмена)"
    }

    private fun closeCapture() {
        capView?.let { runCatching { wm.removeView(it) } }
        capView = null
        frozen?.recycle(); frozen = null
    }

    private fun stopCal() {
        closeCapture()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null; panelTxt = null; calIdx = -1
        toast("Калибровка завершена")
    }

    // ───────── ввод и экран ─────────
    private fun rnd(a: Int, b: Int) = Random.nextLong(a.toLong(), b.toLong())
    private fun nap(a: Int, b: Int) = Thread.sleep(rnd(a, b))
    private fun sw() = if (lastW > 0) lastW else resources.displayMetrics.widthPixels
    private fun sh() = if (lastH > 0) lastH else resources.displayMetrics.heightPixels

    private fun tapPx(x: Float, y: Float, hold: Long = rnd(35, 90), jit: Int = 9) {
        val px = (x + Random.nextInt(-jit, jit + 1)).coerceIn(1f, sw() - 1f)
        val py = (y + Random.nextInt(-jit, jit + 1)).coerceIn(1f, sh() - 1f)
        val path = Path().apply { moveTo(px, py) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, hold)).build()
        val latch = CountDownLatch(1)
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        latch.await(hold + 1500, TimeUnit.MILLISECONDS)
    }

    private fun tap(p: Pt, hold: Long = rnd(35, 90)) = tapPx(p.x * sw(), p.y * sh(), hold)
    private fun tap(key: String, hold: Long = rnd(35, 90)) = tap(Cal.get(this, key), hold)

    /** Скриншот через AccessibilityService (Android 11+). Интервал ≥ ~350 мс. */
    @Synchronized
    private fun shot(): Bitmap? {
        val wait = 360 - (SystemClock.uptimeMillis() - lastShot)
        if (wait > 0) Thread.sleep(wait)
        lastShot = SystemClock.uptimeMillis()
        val latch = CountDownLatch(1)
        var out: Bitmap? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                out = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                latch.countDown()
            }
            override fun onFailure(errorCode: Int) { latch.countDown() }
        })
        latch.await(2, TimeUnit.SECONDS)
        out?.let { lastW = it.width; lastH = it.height }
        return out
    }

    // ───────── основной цикл бота ─────────
    private fun loop() {
        var lastBeat = 0L
        var lastPoll = 0L
        while (alive) {
            try {
                val wall = System.currentTimeMillis()
                if (wall - lastPoll > 1000) {   // какое приложение сейчас на экране
                    lastPoll = wall
                    rootInActiveWindow?.packageName?.let { inGame = it.toString() == Cal.GAME_PKG }
                }
                if (wall - lastBeat > 1000) {   // «пульс» для статуса в приложении
                    lastBeat = wall
                    Status.beat(this, inGame, mods.filter { on[it.key] == true }.values.joinToString(", ") { it.trim() })
                }
                if (calIdx >= 0 || !inGame || mods.keys.none { on[it] == true }) { Thread.sleep(300); continue }

                val f = if (on["turbo"] == true) 0.6 else 1.0
                var busy = false
                if (on["coin"] == true || on["chest"] == true || on["pandora"] == true) {
                    val bmp = shot()
                    if (bmp != null) { busy = scene(bmp); bmp.recycle() }
                }
                if (!busy && on["jump"] == true && SystemClock.uptimeMillis() >= nextJump) {
                    jump(f)
                    nextJump = SystemClock.uptimeMillis() +
                        (Cfg.int(this, "pause", 700) * f * Random.nextDouble(0.85, 1.15)).toLong()
                }
                if (f == 1.0 && Random.nextInt(100) < 2) nap(1500, 4000)   // «человеческая» пауза
                Thread.sleep((Random.nextLong(60, 160) * f).toLong())
            } catch (e: InterruptedException) {
                return
            } catch (e: Throwable) {
                CrashLog.save(this, e)
                Thread.sleep(1000)
            }
        }
    }

    /** true — если сработала спец-сцена и обычный прыжок в этом проходе пропускаем. */
    private fun scene(b: Bitmap): Boolean {
        val cm = Cal.get(this, "chestMark")
        if (on["chest"] == true && cm.color != 0 && Vision.has(b, cm)) { chests(b); return true }
        if (on["pandora"] == true && pandora(b)) return true
        if (on["coin"] == true) coins(b)
        return false
    }

    /** Серия тапов за один прыжок: 1-й — прыжок, остальные — выстрелы из лука. */
    private fun jump(f: Double) {
        val taps = Cfg.int(this, "taps", 3)
        val gap = Cfg.int(this, "tapMs", 140)
        for (i in 0 until taps) {
            tap("jump", rnd(35, 80))
            if (i < taps - 1) Thread.sleep(maxOf(20L, (gap * f * Random.nextDouble(0.85, 1.15)).toLong()))
        }
    }

    /** Ящик Пандоры в зоне перед персонажем → долгий тап (0,5 с или 2 с с прокачкой). */
    private fun pandora(b: Bitmap): Boolean {
        val c = Cal.get(this, "pandora")
        if (c.color == 0 || SystemClock.uptimeMillis() < pandoraUntil) return false
        val pl = Cal.get(this, "player")
        val dist = Cfg.int(this, "pDist", 12) / 100f
        val area = Area((pl.x - 0.02f).coerceAtLeast(0f), 0.03f,
            (pl.x + dist).coerceAtMost(0.99f), pl.y.coerceAtLeast(0.2f))
        if (Vision.find(b, area, c.color, Cal.TOL, 10).isEmpty()) return false
        val ms = if (Cfg.bool(this, "pUp", false)) 2000L else 500L
        tap("jump", (ms * Random.nextDouble(0.96, 1.04)).toLong())
        val now = SystemClock.uptimeMillis()
        pandoraUntil = now + 700
        nextJump = now + 500
        return true
    }

    private fun coins(b: Bitmap) {
        val c = Cal.get(this, "coin")
        for ((x, y) in Vision.find(b, Cal.COIN_AREA, c.color, Cal.TOL, 8).shuffled().take(2)) {
            tapPx(x, y); nap(40, 100)
        }
    }

    private fun chests(b: Bitmap) {
        val c = Cal.get(this, "chest")
        if (c.color == 0) return
        val now = SystemClock.uptimeMillis()
        recent.removeAll { now - it.third > 4000 }
        val hit = Vision.find(b, Cal.CHEST_AREA, c.color, Cal.TOL, 15)
            .filter { h -> recent.none { abs(it.first - h.first) < 90 && abs(it.second - h.second) < 90 } }
            .randomOrNull() ?: return
        recent.add(Triple(hit.first, hit.second, now))
        tapPx(hit.first, hit.second, jit = 14)
    }
}
