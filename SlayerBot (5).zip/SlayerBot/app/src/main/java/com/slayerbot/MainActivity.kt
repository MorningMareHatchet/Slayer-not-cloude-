package com.slayerbot

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var big: TextView
    private lateinit var l1: TextView
    private lateinit var l2: TextView
    private lateinit var l3: TextView
    private lateinit var card: LinearLayout
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(c: Int, r: Int = 16) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun btn(t: String, c: Int, click: () -> Unit) = Button(this).apply {
        text = t; textSize = 15f; isAllCaps = false; setTextColor(Color.WHITE)
        background = bg(c); minHeight = dp(52); minimumHeight = dp(52)
        setOnClickListener {
            try { click() } catch (e: Throwable) { CrashLog.save(this@MainActivity, e) }
        }
    }
    private fun lp() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        CrashLog.install(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(28), dp(18), dp(24))
            setBackgroundColor(0xFF0F1218.toInt())
        }
        root.addView(tv("⚔  Slayer Bot", 26f, bold = true))
        root.addView(tv("автоклик для Idle Slayer", 13f, 0xFF90A4AE.toInt()))

        card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)) }
        big = tv("", 22f, bold = true)
        l1 = tv("", 14f, 0xFFCFD8DC.toInt()); l2 = tv("", 14f, 0xFFCFD8DC.toInt()); l3 = tv("", 14f, 0xFFCFD8DC.toInt())
        card.addView(tv("СТАТУС", 11f, 0xFF90A4AE.toInt()))
        card.addView(big)
        for (v in listOf(l1, l2, l3)) card.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(card, lp())

        root.addView(btn("⚙  Открыть спец. возможности", 0xFF1565C0.toInt()) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, lp())
        root.addView(btn("🔓  Сведения о приложении (ограниченные настройки)", 0xFF37474F.toInt()) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, lp())

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = bg(0xFF1B1F27.toInt()); setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        info.addView(tv("Как пользоваться", 15f, bold = true))
        info.addView(tv(
            "1. В «Сведениях о приложении»: ⋮ → «Разрешить ограниченные настройки».\n" +
            "2. «Открыть спец. возможности» → Slayer Bot → включить.\n" +
            "3. Открой Idle Slayer в горизонтали: слева появится меню.\n" +
            "4. ⚙ Настройки → 🎯 Калибровка, затем включай режимы или FULL AFK.", 13f, 0xFFB0BEC5.toInt()),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(info, lp())

        val log = CrashLog.read(this)
        if (log != null) {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(0xFF2A1B1B.toInt()); setPadding(dp(14), dp(12), dp(14), dp(12)) }
            box.addView(tv("Журнал (скопируй и пришли, если что-то сломалось)", 13f, 0xFFFFAB91.toInt(), true))
            val t = tv(log.takeLast(3000), 10f, 0xFFEEEEEE.toInt()).apply { setTextIsSelectable(true) }
            box.addView(t)
            box.addView(btn("Очистить журнал", 0xFF5D4037.toInt()) { CrashLog.clear(this); t.text = ""; box.visibility = View.GONE }, lp())
            root.addView(box, lp())
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF0F1218.toInt()); addView(root) })
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun enabled(): Boolean {
        val cn = ComponentName(this, BotService::class.java)
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.split(':').any { ComponentName.unflattenFromString(it) == cn }
    }

    private fun refresh() {
        val en = enabled()
        val st = Status.read(this)
        val alive = en && System.currentTimeMillis() - st.hb < 6000
        val (txt, col) = when {
            alive -> "●  АКТИВНА" to 0xFF43A047.toInt()
            en -> "●  ВКЛЮЧЕНА, НЕТ ОТВЕТА" to 0xFFFB8C00.toInt()
            else -> "●  НЕ АКТИВНА" to 0xFFE53935.toInt()
        }
        big.text = txt; big.setTextColor(col)
        card.background = bg(0xFF1B1F27.toInt())
        l1.text = "Служба спец. возможностей: " + if (en) "включена ✔" else "выключена ✖"
        l2.text = "Режимы: " + if (!alive) "—" else if (st.modes.isEmpty()) "не выбраны" else st.modes
        l3.text = "Idle Slayer на экране: " + if (!alive) "—" else if (st.game) "да" else "нет (бот на паузе)"
    }
}
