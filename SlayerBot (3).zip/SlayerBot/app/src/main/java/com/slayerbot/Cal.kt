package com.slayerbot

import android.content.Context

class Pt(val x: Float, val y: Float, val color: Int = 0)
class Area(val l: Float, val t: Float, val r: Float, val b: Float)

/** Все координаты — ДОЛИ экрана (0..1), поэтому не зависят от разрешения.
 *  Nothing Phone 2 в горизонтали: 2412x1080. Значения ниже — стартовые догадки,
 *  точные задаются кнопкой «Калибровка» в плавающем меню (хранятся в SharedPreferences). */
object Cal {
    const val GAME_PKG = "com.pabloleban.IdleSlayer"
    const val TOL = 40            // допуск по цвету (на канал RGB)
    const val SHOP_EVERY_SEC = 90 // как часто заходить в прокачку
    const val BUY_REPEAT = 3      // сколько раз жать каждую кнопку «купить»
    const val ASC_EVERY_MIN = 45  // как часто делать перерождение

    // области поиска (доли экрана)
    val COIN_AREA = Area(0.20f, 0.22f, 0.98f, 0.85f)   // без HUD слева сверху
    val CHEST_AREA = Area(0.03f, 0.12f, 0.97f, 0.92f)

    class Item(val key: String, val hint: String, val dx: Float, val dy: Float,
               val needColor: Boolean = false, val dc: Int = 0)

    val items = listOf(
        Item("jump", "ПРЫЖОК: куда тапать в обычной игре", .30f, .60f),
        Item("coin", "ЦВЕТ МОНЕТЫ: тапни по монете", .60f, .45f, true, 0xFFFFC800.toInt()),
        Item("chestMark", "МАРКЕР охоты за сокровищами: элемент интерфейса, видный только на этом уровне", .50f, .08f, true),
        Item("chest", "ЦВЕТ СУНДУКА: тапни по настоящему сундуку (не мимику)", .50f, .50f, true),
        Item("bonusMark", "МАРКЕР бонус-уровня: элемент интерфейса, видный только на нём", .50f, .08f, true),
        Item("shop", "КНОПКА открытия магазина / улучшений", .95f, .90f),
        Item("buy0", "Улучшение №1 (кнопка «купить»)", .80f, .30f),
        Item("buy1", "Улучшение №2", .80f, .45f),
        Item("buy2", "Улучшение №3", .80f, .60f),
        Item("buy3", "Улучшение №4", .80f, .75f),
        Item("shopClose", "ЗАКРЫТЬ магазин", .95f, .08f),
        Item("asc", "Кнопка ПЕРЕРОЖДЕНИЯ (Ascension)", .50f, .50f),
        Item("ascOk", "ПОДТВЕРДИТЬ перерождение", .60f, .70f)
    )

    private fun prefs(c: Context) = c.getSharedPreferences("cal", Context.MODE_PRIVATE)

    fun get(c: Context, key: String): Pt {
        val it = items.first { i -> i.key == key }
        val s = prefs(c).getString(key, null)?.split(",")
        return if (s != null && s.size == 3) Pt(s[0].toFloat(), s[1].toFloat(), s[2].toInt())
        else Pt(it.dx, it.dy, it.dc)
    }

    fun set(c: Context, key: String, p: Pt) {
        prefs(c).edit().putString(key, "${p.x},${p.y},${p.color}").apply()
    }
}
